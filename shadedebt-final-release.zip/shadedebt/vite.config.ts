import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

/** Development-only dataset endpoint. There is deliberately no production asset
 * or module reference to the Kaggle-derived database while upstream rights remain
 * unverified. Production builds work using Custom Site mode.
 */
function localStopsDevOnly(): Plugin {
  return {
    name: 'shadedebt-local-stops-dev-only',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use('/__shadedebt_local_stops.json', async (_req,res) => {
        try {
          const content = await readFile(resolve(process.cwd(),'local-data/stops.json'),'utf8');
          res.setHeader('Content-Type','application/json; charset=utf-8');
          res.setHeader('Cache-Control','no-store');
          res.end(content);
        } catch { res.statusCode=404;res.end('Local catalogue not installed'); }
      });
    }
  };
}
export default defineConfig({ plugins:[react(),localStopsDevOnly()] });
