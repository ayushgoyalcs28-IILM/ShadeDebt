import {useState} from 'react';
import {ArrowLeft,Sun} from 'lucide-react';
import {fromCustom,type SelectedSite} from './data/siteIdentity';
import Welcome from './components/Welcome';
import ShadeStudio from './components/ShadeStudio';
export default function App(){
 const [page,setPage]=useState<'welcome'|'studio'>('welcome');
 const [site,setSite]=useState<SelectedSite>(()=>fromCustom('Delhi concept site',28.6139,77.2090));
 return <div className="sd-app">
  <header className="sd-header"><button className="sd-brand" onClick={()=>setPage('welcome')} aria-label="ShadeDebt home"><span className="sd-brandmark"><Sun size={19}/></span><strong>shadedebt<span>.</span></strong></button><div className="sd-header-end"><span>BUILD BETTER PUBLIC SPACES</span>{page==='studio'?<button onClick={()=>setPage('welcome')} className="sd-header-button"><ArrowLeft size={16}/> About the project</button>:<button onClick={()=>setPage('studio')} className="sd-header-button">Enter the lab ↗</button>}</div></header>
  {page==='welcome'?<Welcome enter={()=>setPage('studio')}/>:<ShadeStudio key={site.key} site={site} chooseSite={setSite}/>}
  <footer className="sd-footer"><span>ShadeDebt · An experiment in more useful shade.</span><span>Direct-sun geometry only · Not a construction or thermal safety certification.</span></footer>
 </div>;
}
