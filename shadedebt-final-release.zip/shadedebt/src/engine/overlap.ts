import * as clippingModule from 'polygon-clipping';
import type { Polygon as ClipperPolygon, MultiPolygon as ClipperMultiPolygon, Pair as ClipperPair } from 'polygon-clipping';
// The package's ESM build exposes a default object, while its .d.ts declares named exports.
// Resolve either packaging form without guessing which one Vite/Node will select.
const polygonClipping = (clippingModule as unknown as { default?: typeof clippingModule }).default ?? clippingModule;
import type { Polygon, Vec2 } from '../types/domain';
import { polygonArea } from './geometry';
import { assertPolygon } from './validation';

// GeoJSON-style MultiPolygon: list of polygons, each containing an exterior ring and optional holes.
export type MultiPolygonCoords = ClipperMultiPolygon;
const ring = (polygon: Polygon): ClipperPair[] => polygon.map(([x,y])=>[x,y]);
const toInput = (polygon: Polygon): ClipperPolygon => [ring(polygon)];

/** Return no geometry for an empty input, rather than invoking the clipping library with zero arguments. */
export function unionPolygons(polygons: readonly Polygon[]): MultiPolygonCoords {
  if (!polygons.length) return [];
  polygons.forEach((p,i)=>assertPolygon(p,`union input ${i}`));
  const [first,...rest] = polygons.map(toInput);
  return polygonClipping.union(first,...rest) as MultiPolygonCoords;
}
export function clippedToWaiting(shadows: MultiPolygonCoords, waitingArea: Polygon): MultiPolygonCoords {
  if (shadows.length === 0) return [];
  return polygonClipping.intersection(shadows,toInput(waitingArea)) as MultiPolygonCoords;
}
export function multiPolygonArea(multi: MultiPolygonCoords): number {
  let area=0;
  for (const polygon of multi) {
    if (!polygon.length) continue;
    const signed = (r: number[][]): number => {
      let sum=0;
      for(let i=0;i<r.length;i++) {
        const p=r[i], q=r[(i+1)%r.length];
        sum+=p[0]*q[1]-q[0]*p[1];
      }
      return Math.abs(sum)/2;
    };
    area+=signed(polygon[0]);
    for (const hole of polygon.slice(1)) area-=signed(hole);
  }
  if (!Number.isFinite(area) || area < -1e-7) throw new Error('Clipping returned an invalid shaded area');
  return Math.max(0,area);
}
export interface CoverageGeometry {
  shadedAreaM2: number;
  coverage: number;
  /** Clipped to waiting area; holes are preserved for SVG evenodd rendering. */
  shadedWithinWaiting: MultiPolygonCoords;
}
export function measureShade(waitingArea: Polygon, shadowPolygons: readonly Polygon[]): CoverageGeometry {
  assertPolygon(waitingArea,'waitingArea');
  const waitingM2=polygonArea(waitingArea);
  const clipped=clippedToWaiting(unionPolygons(shadowPolygons),waitingArea);
  const shadeM2=multiPolygonArea(clipped);
  const tolerance=Math.max(1e-7,waitingM2*1e-7);
  if (shadeM2 > waitingM2+tolerance) throw new Error('Clipped shade unexpectedly larger than waiting zone');
  const clamped=Math.max(0,Math.min(shadeM2,waitingM2));
  return {shadedAreaM2:clamped,coverage:clamped/waitingM2,shadedWithinWaiting:clipped};
}

/** Coordinates for visualizing a clipping result; holes remain as separate rings. */
export function multiPolygonRings(multi: MultiPolygonCoords): Polygon[] {
  return multi.flatMap(poly=>poly.map(r=>r.map(([x,y])=>[x,y] as Vec2)));
}
