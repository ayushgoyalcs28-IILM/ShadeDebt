import * as SunCalc from 'suncalc';
import { parseClockMinutes } from './validation';
import { validLatLon } from './geometry';

export interface SunPosition {
  altitudeDeg: number;
  azimuthDeg: number; // clockwise from TRUE north: N=0, E=90, S=180, W=270
}

/** Delhi time is UTC+05:30 throughout supported 2000–2100 date range. Do not use host timezone. */
export const DELHI_UTC_OFFSET_MINUTES = 330;
export function istInstant(dateISO: string, minutesSinceMidnight: number): Date {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateISO) || !Number.isFinite(minutesSinceMidnight) || minutesSinceMidnight<0 || minutesSinceMidnight>1440) {
    throw new Error('Invalid local date or minute offset');
  }
  const [y,m,d] = dateISO.split('-').map(Number);
  const t = Date.UTC(y,m-1,d);
  const check = new Date(t);
  if (check.getUTCFullYear() !== y || check.getUTCMonth()+1 !== m || check.getUTCDate()!==d) throw new Error('Invalid local calendar date');
  return new Date(t + (minutesSinceMidnight - DELHI_UTC_OFFSET_MINUTES)*60_000);
}
export function istFromClock(dateISO: string, timeIST: string): Date {
  return istInstant(dateISO,parseClockMinutes(timeIST));
}
/** SunCalc v2.0.2 uses degrees and north-clockwise azimuth; v1 uses a different convention! */
export function sunPosition(date: Date, latitude: number, longitude: number): SunPosition {
  if (!Number.isFinite(date.getTime()) || !validLatLon(latitude,longitude)) throw new Error('Invalid sun-position input');
  const {altitude,azimuth} = SunCalc.getPosition(date,latitude,longitude);
  if (![altitude,azimuth].every(Number.isFinite)) throw new Error('Solar library returned invalid coordinates');
  return {altitudeDeg:altitude,azimuthDeg:((azimuth%360)+360)%360};
}
