import type { Polygon } from '../types/domain';

/** Shoelace polygon area, square metres for local x-east/y-north coordinates. */
export function polygonArea(polygon: Polygon): number {
  if (polygon.length < 3) return 0;
  let twiceArea = 0;
  for (let i = 0; i < polygon.length; i++) {
    const [x1, y1] = polygon[i];
    const [x2, y2] = polygon[(i + 1) % polygon.length];
    twiceArea += x1 * y2 - x2 * y1;
  }
  return Math.abs(twiceArea) / 2;
}

/** Approximate a horizontal circular canopy outline with a polygon. */
export function circlePolygon(radiusM: number, steps = 96): Polygon {
  if (!(radiusM > 0) || !Number.isFinite(radiusM)) throw new Error('radiusM must be positive');
  if (!Number.isInteger(steps) || steps < 12 || steps > 1024) throw new Error('Invalid step count');
  return Array.from({length: steps}, (_, i) => {
    const angle = 2 * Math.PI * i / steps;
    return [radiusM * Math.cos(angle), radiusM * Math.sin(angle)] as const;
  });
}

export function validLatLon(latitude: number, longitude: number): boolean {
  return Number.isFinite(latitude) && Number.isFinite(longitude) && Math.abs(latitude) <= 90 && Math.abs(longitude) <= 180;
}
