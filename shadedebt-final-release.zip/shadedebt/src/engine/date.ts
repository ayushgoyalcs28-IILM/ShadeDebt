/** Date of the instant on the device, expressed as Delhi's local calendar date.
 * Never use the browser's local calendar components for Delhi solar calculations.
 */
export function todayInDelhi(at: Date = new Date()): string {
  if (!Number.isFinite(at.getTime())) throw new Error('Invalid device date');
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(at);
  const get = (type: string) => parts.find(part => part.type === type)?.value;
  const year=get('year'),month=get('month'),day=get('day');
  if (!year || !month || !day) throw new Error('Unable to determine Delhi calendar date');
  return `${year}-${month}-${day}`;
}
