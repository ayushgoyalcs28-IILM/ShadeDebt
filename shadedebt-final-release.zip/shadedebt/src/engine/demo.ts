import type { InterventionScenario } from '../types/domain';
import { rectangle, circle } from './shapes';
/** Disclosed ILLUSTRATIVE physical geometry, not measured at any Delhi transit stop. */
export function exampleScenario(latitude=28.6139,longitude=77.2090):InterventionScenario {
  return {
    id:'delhi-example-phase1',
    site:{
      schemaVersion:1,name:'Illustrative Delhi bus shelter',latitude,longitude,measurementMode:'concept',
      waitingArea:rectangle(8,3,[0,0]),
      baselineCanopies:[{id:'existing-roof',shape:'rectangle',footprint:rectangle(4,2,[-1,0.5]),heightM:3,opaque:true}],
      buildings:[],
      allowedConstructionZone:rectangle(14,8,[0,0]),
      exclusionZones:[],
      measurementNotes:'Illustrative 8×3m waiting zone and 4×2m existing canopy; not a physical site survey.'
    },
    mode:'add',
    proposedCanopies:[{id:'proposed-circle',shape:'circle',footprint:circle(1.8,[1.5,-0.2]),heightM:3.1,opaque:true}],
    dateISO:'2026-05-15',startTimeIST:'12:00',endTimeIST:'17:00',sampleMinutes:15
  };
}
