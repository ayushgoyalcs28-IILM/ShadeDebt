import type { Canopy, Polygon, SiteModel, Vec2, InterventionScenario } from '../types/domain';
import { polygonArea, validLatLon } from './geometry';

export class GeometryInputError extends Error {
  constructor(message: string) { super(message); this.name = 'GeometryInputError'; }
}
const EPS = 1e-9;
const finite = (v: number): boolean => Number.isFinite(v);
const cross = (a: Vec2, b: Vec2, c: Vec2): number =>
  (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
const near = (a: Vec2, b: Vec2): boolean => Math.abs(a[0] - b[0]) < EPS && Math.abs(a[1] - b[1]) < EPS;
function onSegment(a: Vec2, b: Vec2, p: Vec2): boolean {
  return Math.abs(cross(a, b, p)) < EPS &&
    p[0] >= Math.min(a[0], b[0]) - EPS && p[0] <= Math.max(a[0], b[0]) + EPS &&
    p[1] >= Math.min(a[1], b[1]) - EPS && p[1] <= Math.max(a[1], b[1]) + EPS;
}
function intersects(a: Vec2, b: Vec2, c: Vec2, d: Vec2): boolean {
  const c1 = cross(a,b,c), c2 = cross(a,b,d), c3 = cross(c,d,a), c4 = cross(c,d,b);
  if (((c1 > EPS && c2 < -EPS) || (c1 < -EPS && c2 > EPS)) &&
      ((c3 > EPS && c4 < -EPS) || (c3 < -EPS && c4 > EPS))) return true;
  return (Math.abs(c1) <= EPS && onSegment(a,b,c)) ||
    (Math.abs(c2) <= EPS && onSegment(a,b,d)) ||
    (Math.abs(c3) <= EPS && onSegment(c,d,a)) ||
    (Math.abs(c4) <= EPS && onSegment(c,d,b));
}
/** Polygons use metres east/north, non-self-intersecting; the caller never supplies holes. */
export function assertPolygon(polygon: Polygon, label = 'polygon'): void {
  if (!Array.isArray(polygon) || polygon.length < 3 || polygon.length > 128) {
    throw new GeometryInputError(`${label}: expected 3–128 vertices`);
  }
  for (const point of polygon) {
    if (!Array.isArray(point) || point.length !== 2 || !point.every(finite)) {
      throw new GeometryInputError(`${label}: all coordinates must be finite [east, north] pairs`);
    }
    if (point.some(v => Math.abs(v) > 10000)) throw new GeometryInputError(`${label}: coordinate exceeds 10 km local model limit`);
  }
  const n = polygon.length;
  for (let i=0; i<n; i++) {
    if (near(polygon[i], polygon[(i+1)%n])) throw new GeometryInputError(`${label}: duplicate/zero-length edge`);
    for (let j=i+1; j<n; j++) {
      if (near(polygon[i], polygon[j])) throw new GeometryInputError(`${label}: repeated vertex`);
    }
  }
  for (let i=0; i<n; i++) {
    for (let j=i+1; j<n; j++) {
      // Adjacent polygon edges share a single endpoint; that is allowed.
      if (j === i+1 || (i===0 && j===n-1)) continue;
      if (intersects(polygon[i], polygon[(i+1)%n], polygon[j], polygon[(j+1)%n])) {
        throw new GeometryInputError(`${label}: self-intersecting or self-touching outline`);
      }
    }
  }
  if (polygonArea(polygon) <= 1e-7) throw new GeometryInputError(`${label}: area too small`);
}

/** Convexity is required for the current solid-prism shadow model. */
export function assertConvexPolygon(polygon: Polygon, label: string): void {
  assertPolygon(polygon,label);
  let sign = 0;
  for (let i=0;i<polygon.length;i++) {
    const k = cross(polygon[i], polygon[(i+1)%polygon.length], polygon[(i+2)%polygon.length]);
    if (Math.abs(k) <= EPS) continue;
    const next = Math.sign(k);
    if (sign && next !== sign) throw new GeometryInputError(`${label}: only convex building footprints are supported`);
    sign = next;
  }
}

function assertHeight(heightM: number, max: number, label: string): void {
  if (!finite(heightM) || heightM < 0.3 || heightM > max) {
    throw new GeometryInputError(`${label}: height must be between 0.3 and ${max} metres`);
  }
}
function assertCanopy(canopy: Canopy, label: string): void {
  if (!canopy.id || !canopy.shape || canopy.opaque !== true) throw new GeometryInputError(`${label}: opaque canopy metadata required`);
  assertPolygon(canopy.footprint,`${label}.footprint`);
  assertHeight(canopy.heightM,30,`${label}.heightM`);
}
export function assertSite(site: SiteModel): void {
  if (site.schemaVersion !== 1 || !validLatLon(site.latitude,site.longitude)) throw new GeometryInputError('Site requires valid schema version and latitude/longitude');
  assertPolygon(site.waitingArea,'waitingArea');
  assertPolygon(site.allowedConstructionZone,'allowedConstructionZone');
  if (site.baselineCanopies.length > 15 || site.buildings.length > 10 || site.exclusionZones.length > 20) {
    throw new GeometryInputError('Too many geometry objects for an interactive site');
  }
  site.baselineCanopies.forEach((c,i)=>assertCanopy(c,`baselineCanopies[${i}]`));
  site.buildings.forEach((b,i)=>{
    if (!b.id) throw new GeometryInputError(`buildings[${i}]: missing id`);
    assertConvexPolygon(b.footprint,`buildings[${i}].footprint`);
    assertHeight(b.heightM,250,`buildings[${i}].heightM`);
  });
  site.exclusionZones.forEach((p,i)=>assertPolygon(p,`exclusionZones[${i}]`));
  if (polygonArea(site.waitingArea) > 20000) throw new GeometryInputError('waitingArea exceeds 20,000 m²');
}
export function assertScenario(scenario: InterventionScenario): void {
  assertSite(scenario.site);
  if (scenario.proposedCanopies.length > 15) throw new GeometryInputError('Too many proposed canopies');
  scenario.proposedCanopies.forEach((c,i)=>assertCanopy(c,`proposedCanopies[${i}]`));
  if (!['add','replace'].includes(scenario.mode)) throw new GeometryInputError('mode must be add or replace');
  if (!Number.isInteger(scenario.sampleMinutes) || scenario.sampleMinutes < 5 || scenario.sampleMinutes > 60) {
    throw new GeometryInputError('sampleMinutes must be an integer between 5 and 60');
  }
  // Avoid Date's silent normalization of invalid dates such as February 30.
  if (!/^\d{4}-\d{2}-\d{2}$/.test(scenario.dateISO)) throw new GeometryInputError('dateISO must be YYYY-MM-DD');
  const [yr,mo,day] = scenario.dateISO.split('-').map(Number);
  const utc = new Date(Date.UTC(yr, mo-1, day));
  if (yr < 2000 || yr > 2100 || utc.getUTCFullYear()!==yr || utc.getUTCMonth()+1!==mo || utc.getUTCDate()!==day) {
    throw new GeometryInputError('dateISO must be a real calendar date between 2000 and 2100');
  }
  const start = parseClockMinutes(scenario.startTimeIST);
  const end = parseClockMinutes(scenario.endTimeIST, true);
  if (end <= start) throw new GeometryInputError('End time must be after start time (same local day)');
  if (Math.ceil((end-start)/scenario.sampleMinutes) > 288) throw new GeometryInputError('Too many samples');
}

export function parseClockMinutes(value: string, allow2400 = false): number {
  if (allow2400 && value === '24:00') return 1440;
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) throw new GeometryInputError(`Invalid IST time: ${value}`);
  const [h,m] = value.split(':').map(Number);
  return 60*h+m;
}
