import type { Polygon, Vec2 } from '../types/domain';
import { circlePolygon } from './geometry';
import { assertPolygon } from './validation';

/** A positive rotation is counter-clockwise from the EAST (+x) axis. */
export function transformPolygon(polygon: Polygon, eastM: number, northM: number, rotationDegCCW = 0): Polygon {
  if (![eastM,northM,rotationDegCCW].every(Number.isFinite)) throw new Error('Invalid geometry transform');
  const a = rotationDegCCW*Math.PI/180, c=Math.cos(a), s=Math.sin(a);
  return polygon.map(([x,y])=>[x*c-y*s+eastM,x*s+y*c+northM] as Vec2);
}
export function rectangle(widthM: number, depthM: number, center: Vec2 = [0,0], rotationDegCCW = 0): Polygon {
  if (![widthM,depthM].every(n=>Number.isFinite(n)&&n>0)) throw new Error('Dimensions must be positive');
  const w=widthM/2,h=depthM/2;
  return transformPolygon([[-w,-h],[w,-h],[w,h],[-w,h]],center[0],center[1],rotationDegCCW);
}
export function circle(radiusM: number, center: Vec2 = [0,0], steps=96): Polygon {
  return transformPolygon(circlePolygon(radiusM,steps),center[0],center[1]);
}
export function triangle(widthM: number, depthM: number, center: Vec2 = [0,0], rotationDegCCW=0): Polygon {
  if (!(widthM>0&&depthM>0)) throw new Error('Dimensions must be positive');
  return transformPolygon([[-widthM/2,-depthM/2],[widthM/2,-depthM/2],[0,depthM/2]],center[0],center[1],rotationDegCCW);
}
export function trapezoid(topWidthM: number, baseWidthM: number, depthM: number, center: Vec2=[0,0], rotationDegCCW=0): Polygon {
  if (![topWidthM,baseWidthM,depthM].every(n=>Number.isFinite(n)&&n>0)) throw new Error('Dimensions must be positive');
  const d=depthM/2;
  return transformPolygon([[-baseWidthM/2,-d],[baseWidthM/2,-d],[topWidthM/2,d],[-topWidthM/2,d]],center[0],center[1],rotationDegCCW);
}
export function hexagon(radiusM: number, center: Vec2=[0,0], rotationDegCCW=0): Polygon {
  if (!Number.isFinite(radiusM)||radiusM<=0) throw new Error('Radius must be positive');
  return transformPolygon(Array.from({length:6},(_,i)=>[radiusM*Math.cos(i*Math.PI/3),radiusM*Math.sin(i*Math.PI/3)] as Vec2),center[0],center[1],rotationDegCCW);
}
export function custom(vertices: Polygon): Polygon { assertPolygon(vertices,'custom canopy'); return vertices.map(([x,y])=>[x,y] as Vec2); }
