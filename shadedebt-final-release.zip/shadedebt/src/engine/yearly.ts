/** Sampled 12-month canopy placement study. Uses the exact same shadow physics
 * and polygon clipping as daily simulations; search is translation-only.
 * Every candidate is scored against the IDENTICAL sun-position samples.
 */
import type {InterventionScenario,Polygon,Vec2,Canopy} from '../types/domain';
import {assertScenario} from './validation';
import {polygonArea} from './geometry';
import {sunPosition,istInstant,type SunPosition} from './solar';
import {usableSun,canopyShadow} from './shadows';
import {measureShade} from './overlap';
import {validatePlacement} from './optimizer';
export const YEARLY_MODEL_VERSION='yearly-placement-v1';
export interface YearlyPlacement {anchor:Vec2;averageCoverage:number;changePoints:number;distanceM:number}
export interface YearlyResult {model:typeof YEARLY_MODEL_VERSION;dates:string[];timeLabels:string[];tested:number;rejected:number;current:YearlyPlacement|null;best:YearlyPlacement|null;description:string;sampledTimes:number}
interface Sample {sun:SunPosition}
export function yearlyDates(dateISO:string):string[]{
  const [y,m,d]=dateISO.split('-').map(Number);
  if(!Number.isInteger(y)||!Number.isInteger(m)||!Number.isInteger(d)||y<2000||y>2100||m<1||m>12||d<1||d>31||new Date(Date.UTC(y,m-1,d)).toISOString().slice(0,10)!==dateISO)throw new Error('Invalid study start date');
  return Array.from({length:12},(_,i)=>{
    const month=m-1+i;
    const first=new Date(Date.UTC(y,month,1));
    const last=new Date(Date.UTC(first.getUTCFullYear(),first.getUTCMonth()+1,0)).getUTCDate();
    return `${first.getUTCFullYear()}-${String(first.getUTCMonth()+1).padStart(2,'0')}-${String(Math.min(d,last)).padStart(2,'0')}`;
  });
}
const translate=(p:Polygon,dx:number,dy:number):Polygon=>p.map(([x,y])=>[x+dx,y+dy]);
export function optimizeYear(scenario:InterventionScenario,anchor:Vec2,limit=180):YearlyResult{
  assertScenario(scenario);
  if(!Array.isArray(anchor)||anchor.length!==2||!anchor.every(Number.isFinite)||!Number.isInteger(limit)||limit<20||limit>200)throw new Error('Invalid annual optimization settings');
  if(scenario.proposedCanopies.length!==1)throw new Error('One canopy is required');
  if(scenario.site.buildings.length||scenario.site.exclusionZones.length>2)throw new Error('Simplified annual model cannot include buildings or additional blocked zones');
  const dates=yearlyDates(scenario.dateISO);
  // Five midpoint samples per day: 12:30,13:30,14:30,15:30,16:30 IST.
  const timeMinutes=[750,810,870,930,990];
  const timeLabels=['12:30','13:30','14:30','15:30','16:30'];
  const samples:Sample[]=dates.flatMap(date=>timeMinutes.map(m=>({sun:sunPosition(istInstant(date,m),scenario.site.latitude,scenario.site.longitude)}))).filter(s=>usableSun(s.sun));
  if(samples.length===0)throw new Error('No usable solar samples');
  const canopy=scenario.proposedCanopies[0];const waiting=scenario.site.waitingArea;
  const bxs=canopy.footprint.map(p=>p[0]),bys=canopy.footprint.map(p=>p[1]);
  const xs=scenario.site.allowedConstructionZone.map(p=>p[0]),ys=scenario.site.allowedConstructionZone.map(p=>p[1]);
  const bounds={minX:anchor[0]+Math.min(...xs)-Math.min(...bxs),maxX:anchor[0]+Math.max(...xs)-Math.max(...bxs),minY:anchor[1]+Math.min(...ys)-Math.min(...bys),maxY:anchor[1]+Math.max(...ys)-Math.max(...bys)};
  const area=polygonArea(waiting);
  const points:[number,number][]=[];const seen=new Set<string>();
  const enqueue=(x:number,y:number)=>{const key=`${x.toFixed(4)}:${y.toFixed(4)}`;if(!seen.has(key)){seen.add(key);points.push([x,y]);}};
  enqueue(anchor[0],anchor[1]);
  // Fixed deterministic candidate lattice around the waiting space and authored location.
  for(let x=Math.ceil(bounds.minX/2)*2;x<=bounds.maxX+.0001;x+=2)
    for(let y=Math.ceil(bounds.minY/2)*2;y<=bounds.maxY+.0001;y+=2)enqueue(x,y);
  let tested=0,rejected=0;
  const scored=new Set<string>();
  let best:YearlyPlacement|null=null,current:YearlyPlacement|null=null;
  const score=(p:Vec2):YearlyPlacement=>{
    const moved:Canopy={...canopy,footprint:translate(canopy.footprint,p[0]-anchor[0],p[1]-anchor[1])};
    let covered=0;
    for(const sample of samples){
      const shadows=[canopyShadow(moved,sample.sun)];
      // 'Replace': baseline excluded. Only newly drawn custom roof is evaluated.
      covered+=measureShade(waiting,shadows).shadedAreaM2/area;
    }
    return {anchor:p,averageCoverage:covered/samples.length,changePoints:0,distanceM:Math.hypot(p[0]-anchor[0],p[1]-anchor[1])};
  };
  // Score the current design first; best is always at least as good as this valid position.
  for(const p of points){
    if(tested>=limit)break;
    scored.add(`${p[0].toFixed(3)}:${p[1].toFixed(3)}`);
    const moved=translate(canopy.footprint,p[0]-anchor[0],p[1]-anchor[1]);
    if(!validatePlacement(scenario,moved).valid){rejected++;continue;}
    const candidate=score(p);tested++;
    if(p[0]===anchor[0]&&p[1]===anchor[1])current=candidate;
    if(!best||candidate.averageCoverage>best.averageCoverage+1e-9||Math.abs(candidate.averageCoverage-best.averageCoverage)<1e-9&&candidate.distanceM<best.distanceM-1e-9)best=candidate;
  }
  if(best){
    // Two refinement passes avoid the biased left-to-right truncation of a dense
    // 1-metre grid. Every refinement uses identical 60 solar samples.
    for(const step of [1,0.25]){
     if(!best||tested>=limit)break;
     const center=[...best.anchor];
     for(let ix=-2;ix<=2&&tested<limit;ix++)for(let iy=-2;iy<=2&&tested<limit;iy++){
      const p:[number,number]=[Math.round((center[0]+ix*step)*100)/100,Math.round((center[1]+iy*step)*100)/100];
      if(p[0]<bounds.minX||p[0]>bounds.maxX||p[1]<bounds.minY||p[1]>bounds.maxY)continue;
      const key=`${p[0].toFixed(3)}:${p[1].toFixed(3)}`;
      if(scored.has(key))continue;scored.add(key);
      const moved=translate(canopy.footprint,p[0]-anchor[0],p[1]-anchor[1]);
      if(!validatePlacement(scenario,moved).valid){rejected++;continue;}
      const candidate=score(p);tested++;
      if(candidate.averageCoverage>best.averageCoverage+1e-9||Math.abs(candidate.averageCoverage-best.averageCoverage)<1e-9&&candidate.distanceM<best.distanceM-1e-9)best=candidate;
     }
    }
  }
  if(best&&current)best.changePoints=(best.averageCoverage-current.averageCoverage)*100;
  return {model:YEARLY_MODEL_VERSION,dates,timeLabels,tested,rejected,current,best,description:'12 monthly dates × five afternoon midpoints; direct-beam coverage, equally weighted. Best of bounded tested placements, not a continuous-year optimum.',sampledTimes:samples.length};
}
