/** Phase 2 authoring model. Pure conversion to the Phase 1 domain contract.
 * x-east / y-north in metres; angleCCW relative to east; no screen coordinates in data.
 */
import type { CanopyShape, InterventionScenario, MeasurementMode, Polygon, Vec2 } from '../types/domain';
import { rectangle, circle, triangle, trapezoid, hexagon, transformPolygon } from './shapes';
import { polygonArea } from './geometry';
import { assertPolygon } from './validation';
import { todayInDelhi } from './date';

export interface DesignDraft {
  shape: CanopyShape;
  x: number;
  y: number;
  width: number;
  depth: number;
  height: number;
  rotation: number;
  /** Relative to the design center; editable only for custom roofs. */
  vertices: Polygon;
}
export interface SiteDraft {
  name: string;
  latitude: number;
  longitude: number;
  mode: MeasurementMode;
  date: string;
  from: string;
  to: string;
  waiting: { x: number; y: number; width: number; depth: number; rotation: number };
  existing: DesignDraft;
  includeExisting: boolean;
  building: { enabled: boolean; x: number; y: number; width: number; depth: number; height: number; rotation: number };
  proposal: DesignDraft;
  comparisonMode: 'add' | 'replace';
  constraints: {
    allowed: {x:number;y:number;width:number;depth:number;rotation:number};
    road: {x:number;y:number;width:number;depth:number;rotation:number};
    noBuild: {enabled:boolean;x:number;y:number;width:number;depth:number;rotation:number};
  };
}
export const sampleDraft = (latitude = 28.6139, longitude = 77.2090, name = 'Delhi · conceptual site'): SiteDraft => ({
  name, latitude, longitude, mode:'concept', date:todayInDelhi(), from:'12:00', to:'17:00',
  waiting:{x:0,y:0,width:8,depth:3,rotation:0},
  existing:{shape:'rectangle',x:-1.25,y:0.8,width:4,depth:2,height:3,rotation:0,vertices:[[-1.6,-0.8],[1.6,-0.8],[1.6,0.8],[-1.6,0.8]]},
  includeExisting:true,
  building:{enabled:false,x:-6,y:5,width:4,depth:3,height:8,rotation:0},
  proposal:{shape:'circle',x:3,y:-0.3,width:3.6,depth:3.6,height:3.1,rotation:0,vertices:[[-1.6,-0.7],[0.8,-1.15],[1.8,0.25],[0.2,1.1],[-1.45,0.9]]},
  comparisonMode:'add',
  constraints:{
    allowed:{x:0,y:1.8,width:22,depth:12,rotation:0},
    road:{x:0,y:-6.2,width:22,depth:4,rotation:0},
    noBuild:{enabled:false,x:6,y:3,width:3,depth:2,rotation:0}
  }
});

export function outline(d: DesignDraft): Polygon {
  let base: Polygon;
  switch (d.shape) {
    case 'rectangle': base=rectangle(d.width,d.depth);break;
    case 'circle': base=circle(d.width/2,[0,0],64);break;
    case 'triangle': base=triangle(d.width,d.depth);break;
    case 'trapezoid': base=trapezoid(d.width*0.65,d.width,d.depth);break;
    case 'hexagon': base=hexagon(d.width/2);break;
    case 'custom': base=d.vertices;break;
    default: throw new Error('Unsupported shape');
  }
  const result=transformPolygon(base,d.x,d.y,d.rotation);
  assertPolygon(result,'proposed canopy');
  return result;
}
/** Compare roof forms on an equal-area budget without changing height or rotation.
 * A uniform scale preserves shape proportions, including custom vertex topology.
 */
export function switchRoofShape(d:DesignDraft, shape:CanopyShape, lockArea:boolean):DesignDraft {
  if(d.shape===shape)return d;
  const target={...d,shape};
  if(!lockArea)return target;
  const originalArea=footprintArea(d);
  const newArea=footprintArea(target);
  const factor=Math.sqrt(originalArea/newArea);
  const result={...target,width:target.width*factor,depth:target.depth*factor,
    vertices:target.vertices.map(([x,y])=>[x*factor,y*factor] as Vec2)};
  outline(result);
  return result;
}
/** Move only the selected local custom vertex; avoid silently overwriting good geometry. */
export function moveCustomVertex(d: DesignDraft, index:number, localPoint: Vec2): DesignDraft {
  if(d.shape!=='custom'||index<0||index>=d.vertices.length||!localPoint.every(Number.isFinite)) throw new Error('Invalid custom edit');
  const next={...d,vertices:d.vertices.map((p,i)=>i===index?localPoint:p)};
  outline(next); // validate self-intersections and degeneracy before accepting
  return next;
}
export function toScenario(d:SiteDraft):InterventionScenario {
  const existing=d.includeExisting?[{id:'baseline-roof',shape:d.existing.shape,footprint:outline(d.existing),heightM:d.existing.height,opaque:true as const}]:[];
  return {
    id:'phase2-site-scenario',
    site:{schemaVersion:1,name:d.name,latitude:d.latitude,longitude:d.longitude,measurementMode:d.mode,
      waitingArea:rectangle(d.waiting.width,d.waiting.depth,[d.waiting.x,d.waiting.y],d.waiting.rotation),
      baselineCanopies:existing,
      buildings:d.building.enabled?[{id:'neighbour-building', footprint:rectangle(d.building.width,d.building.depth,[d.building.x,d.building.y],d.building.rotation),heightM:d.building.height}]:[],
      allowedConstructionZone:rectangle(d.constraints.allowed.width,d.constraints.allowed.depth,[d.constraints.allowed.x,d.constraints.allowed.y],d.constraints.allowed.rotation),
      exclusionZones:[rectangle(d.constraints.road.width,d.constraints.road.depth,[d.constraints.road.x,d.constraints.road.y],d.constraints.road.rotation),
        ...(d.constraints.noBuild.enabled?[rectangle(d.constraints.noBuild.width,d.constraints.noBuild.depth,[d.constraints.noBuild.x,d.constraints.noBuild.y],d.constraints.noBuild.rotation)]:[])],
      measurementNotes:d.mode==='concept'?'Illustrative site geometry; not surveyed.':'User-entered site geometry; measurements have not been independently verified.'},
    mode:d.comparisonMode,proposedCanopies:[{id:'proposed-roof',shape:d.proposal.shape,footprint:outline(d.proposal),heightM:d.proposal.height,opaque:true}],
    dateISO:d.date,startTimeIST:d.from,endTimeIST:d.to,sampleMinutes:15
  };
}
export function footprintArea(d:DesignDraft):number{return polygonArea(outline(d));}
/** Screen coordinate mapping is isolated from physical scenario state. */
export const SCENE = {width:880,height:510,pixelsPerMeter:32,originX:440,originY:250};
export function toScreen([east,north]:Vec2):Vec2 {return [SCENE.originX+east*SCENE.pixelsPerMeter,SCENE.originY-north*SCENE.pixelsPerMeter];}
export function fromScreen([sx,sy]:Vec2):Vec2 {return [(sx-SCENE.originX)/SCENE.pixelsPerMeter,(SCENE.originY-sy)/SCENE.pixelsPerMeter];}
/** SVG coordinate contains both CSS scaling and viewBox; callers convert client position through SVG matrix. */
export function svgPath(polygon:Polygon):string {
  return polygon.map((p,i)=>{const [x,y]=toScreen(p);return `${i?'L':'M'}${x.toFixed(2)},${y.toFixed(2)}`;}).join(' ')+' Z';
}
/** Clipper multipolygons preserve holes; evenodd fill makes holes transparent. */
export function clippedPath(polygons:readonly (readonly (readonly number[][])[])[]):string {
  return polygons.map(p=>p.map(r=>r.map((c,i)=>{const [x,y]=toScreen([c[0],c[1]]);return `${i?'L':'M'}${x.toFixed(2)},${y.toFixed(2)}`;}).join(' ')+' Z').join(' ')).join(' ');
}
