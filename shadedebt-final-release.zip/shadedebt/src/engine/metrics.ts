export interface WeightedCoverageSample {
  durationMinutes: number;
  baselineShadedM2: number;
  proposedShadedM2: number;
}
export interface ShadeMetrics {
  waitingAreaM2: number;
  evaluatedHours: number;
  averageBaselineCoverage: number;
  averageProposedCoverage: number;
  baselineShadeDebtM2Hours: number;
  proposedShadeDebtM2Hours: number;
  addedUsefulShadeM2Hours: number;
  shadeDebtReductionM2Hours: number;
  shadeDebtReductionFraction: number | null;
}
/** Time-integrated coverage over EVALUATED daylight time, not over excluded low-sun intervals. */
export function aggregateMetrics(waitingAreaM2: number, samples: readonly WeightedCoverageSample[]): ShadeMetrics | null {
  if (!Number.isFinite(waitingAreaM2) || waitingAreaM2<=0) throw new Error('Waiting area must be positive');
  if (!samples.length) return null;
  let hours=0, baselineShadedAreaTime=0, proposedShadedAreaTime=0;
  for (const sample of samples) {
    const {durationMinutes,baselineShadedM2,proposedShadedM2}=sample;
    if (![durationMinutes,baselineShadedM2,proposedShadedM2].every(Number.isFinite) || durationMinutes<=0 ||
      baselineShadedM2 < -1e-8 || proposedShadedM2 < -1e-8 || baselineShadedM2 > waitingAreaM2+1e-7 || proposedShadedM2 > waitingAreaM2+1e-7) {
      throw new Error('Invalid sampled coverage');
    }
    const dt=durationMinutes/60;
    hours+=dt;
    baselineShadedAreaTime+=Math.min(waitingAreaM2,baselineShadedM2)*dt;
    proposedShadedAreaTime+=Math.min(waitingAreaM2,proposedShadedM2)*dt;
  }
  const baselineDebt=Math.max(0,waitingAreaM2*hours-baselineShadedAreaTime);
  const proposedDebt=Math.max(0,waitingAreaM2*hours-proposedShadedAreaTime);
  return {
    waitingAreaM2,
    evaluatedHours:hours,
    averageBaselineCoverage:baselineShadedAreaTime/(waitingAreaM2*hours),
    averageProposedCoverage:proposedShadedAreaTime/(waitingAreaM2*hours),
    baselineShadeDebtM2Hours:baselineDebt,
    proposedShadeDebtM2Hours:proposedDebt,
    addedUsefulShadeM2Hours:proposedShadedAreaTime-baselineShadedAreaTime,
    shadeDebtReductionM2Hours:baselineDebt-proposedDebt,
    shadeDebtReductionFraction:baselineDebt>1e-9?(baselineDebt-proposedDebt)/baselineDebt:null
  };
}
