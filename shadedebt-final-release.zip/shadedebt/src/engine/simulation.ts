import type { Canopy, InterventionScenario, SiteModel, Polygon } from '../types/domain';
import { polygonArea } from './geometry';
import type { SunPosition } from './solar';
import { sunPosition, istInstant } from './solar';
import { buildingShadow, canopyShadow, usableSun, MIN_SOLAR_ALTITUDE_DEG } from './shadows';
import { measureShade, type CoverageGeometry } from './overlap';
import { aggregateMetrics, type ShadeMetrics, type WeightedCoverageSample } from './metrics';
import { assertScenario, parseClockMinutes } from './validation';

export interface InstantEvaluation {
  baseline: CoverageGeometry;
  proposed: CoverageGeometry;
  baselineShadows: Polygon[];
  proposedShadows: Polygon[];
}
/** Fully deterministic geometric evaluation for a known sun vector. Test independently from astronomy. */
export function evaluateSunPosition(site:SiteModel, proposedCanopies:readonly Canopy[], mode:'add'|'replace', sun:SunPosition):InstantEvaluation {
  if (!usableSun(sun)) throw new Error(`Sun altitude must be at least ${MIN_SOLAR_ALTITUDE_DEG}°`);
  const buildingShadows=site.buildings.map(b=>buildingShadow(b,sun));
  const baselineShadows=[...buildingShadows,...site.baselineCanopies.map(c=>canopyShadow(c,sun))];
  const afterCanopies=mode==='add'?[...site.baselineCanopies,...proposedCanopies]:[...proposedCanopies];
  const proposedShadows=[...buildingShadows,...afterCanopies.map(c=>canopyShadow(c,sun))];
  return {baseline:measureShade(site.waitingArea,baselineShadows),proposed:measureShade(site.waitingArea,proposedShadows),baselineShadows,proposedShadows};
}
export type SampleStatus = 'evaluated' | 'below-horizon' | 'low-sun';
export interface TimedEvaluation {
  instantISO: string;
  localClockIST: string;
  durationMinutes: number;
  sun: SunPosition;
  status: SampleStatus;
  baselineCoverage: number | null;
  proposedCoverage: number | null;
  baselineShadeM2: number | null;
  proposedShadeM2: number | null;
  baselineShadedWithinWaiting: CoverageGeometry['shadedWithinWaiting'];
  proposedShadedWithinWaiting: CoverageGeometry['shadedWithinWaiting'];
  baselineShadows: Polygon[];
  proposedShadows: Polygon[];
}
export interface SimulationResult {
  schemaVersion:1;
  modelVersion:'phase1-geometry-1';
  dateISO:string;
  timeZone:'Asia/Kolkata';
  startTimeIST:string;
  endTimeIST:string;
  sampleMinutes:number;
  minSolarAltitudeDeg:number;
  waitingAreaM2:number;
  evaluatedMinutes:number;
  excludedMinutes:number;
  samples:TimedEvaluation[];
  metrics:ShadeMetrics | null;
  warnings:string[];
}
function clockFromMinutes(minutes:number):string {
  const rounded=Math.floor(minutes);
  return `${String(Math.floor(rounded/60)).padStart(2,'0')}:${String(rounded%60).padStart(2,'0')}`;
}
/** Midpoint quadrature. The last partial interval receives its actual weight.
 * Below-horizon and altitude <5° are EXCLUDED from both coverage denominator and ShadeDebt.
 */
export function simulateScenario(scenario:InterventionScenario):SimulationResult {
  assertScenario(scenario);
  const {site,dateISO,startTimeIST,endTimeIST,sampleMinutes}=scenario;
  const waitingAreaM2=polygonArea(site.waitingArea);
  const start=parseClockMinutes(startTimeIST), end=parseClockMinutes(endTimeIST,true);
  const samples:TimedEvaluation[]=[];
  const weighted:WeightedCoverageSample[]=[];
  let excludedMinutes=0;
  for (let t=start;t<end;t+=sampleMinutes) {
    const durationMinutes=Math.min(sampleMinutes,end-t);
    const mid=t+durationMinutes/2;
    const instant=istInstant(dateISO,mid);
    const sun=sunPosition(instant,site.latitude,site.longitude);
    const status:SampleStatus=sun.altitudeDeg<=0?'below-horizon':sun.altitudeDeg<MIN_SOLAR_ALTITUDE_DEG?'low-sun':'evaluated';
    const base={instantISO:instant.toISOString(),localClockIST:clockFromMinutes(mid),durationMinutes,sun,status};
    if (status!=='evaluated') {
      excludedMinutes+=durationMinutes;
      samples.push({...base,baselineCoverage:null,proposedCoverage:null,baselineShadeM2:null,proposedShadeM2:null,baselineShadedWithinWaiting:[],proposedShadedWithinWaiting:[],baselineShadows:[],proposedShadows:[]});
      continue;
    }
    const evaluated=evaluateSunPosition(site,scenario.proposedCanopies,scenario.mode,sun);
    weighted.push({durationMinutes,baselineShadedM2:evaluated.baseline.shadedAreaM2,proposedShadedM2:evaluated.proposed.shadedAreaM2});
    samples.push({...base,
      baselineCoverage:evaluated.baseline.coverage,proposedCoverage:evaluated.proposed.coverage,
      baselineShadeM2:evaluated.baseline.shadedAreaM2,proposedShadeM2:evaluated.proposed.shadedAreaM2,
      baselineShadedWithinWaiting:evaluated.baseline.shadedWithinWaiting,
      proposedShadedWithinWaiting:evaluated.proposed.shadedWithinWaiting,
      baselineShadows:evaluated.baselineShadows,proposedShadows:evaluated.proposedShadows
    });
  }
  const evaluatedMinutes=(end-start)-excludedMinutes;
  const warnings=[
    'Direct-beam geometric shade only: not temperature, thermal comfort, or health risk.',
    'Ideal level ground; opaque horizontal canopies; surveyed or illustrative geometry; no diffuse/reflected solar radiation.',
    'Solar position uses SunCalc v2 apparent altitude. Shadow geometry is approximate, especially near the horizon.',
    'Midpoint time sampling approximates the selected date/time window; results depend on the sampling interval.'
  ];
  if(excludedMinutes) warnings.push(`${excludedMinutes} minutes excluded (night or solar altitude below ${MIN_SOLAR_ALTITUDE_DEG}°). ShadeDebt covers evaluated time only.`);
  if(!weighted.length) warnings.push('No evaluable direct sunlight in this time window; shade metrics are unavailable.');
  if(site.measurementMode==='concept') warnings.push('Concept-mode dimensions are assumptions, not verified measurements of the selected stop.');
  return {schemaVersion:1,modelVersion:'phase1-geometry-1',dateISO,timeZone:'Asia/Kolkata',startTimeIST,endTimeIST,sampleMinutes,minSolarAltitudeDeg:MIN_SOLAR_ALTITUDE_DEG,waitingAreaM2,evaluatedMinutes,excludedMinutes,samples,metrics:aggregateMetrics(waitingAreaM2,weighted),warnings};
}
