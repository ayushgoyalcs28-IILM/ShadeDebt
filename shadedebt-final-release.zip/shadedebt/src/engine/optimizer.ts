/** Deterministic, bounded design-search for one existing proposed horizontal canopy.
 * Search variables: translation only. Shape, roof area, height and rotation do not change.
 * The site model's construction-zone and exclusion polygons are authoritative.
 */
import type { Canopy, InterventionScenario, Polygon, Vec2 } from '../types/domain';
import { assertScenario } from './validation';
import { polygonArea } from './geometry';
import { unionPolygons, clippedToWaiting, multiPolygonArea, measureShade } from './overlap';
import { canopyShadow, buildingShadow, usableSun } from './shadows';
import { sunPosition, istInstant } from './solar';
import { parseClockMinutes } from './validation';
import { aggregateMetrics, type ShadeMetrics, type WeightedCoverageSample } from './metrics';

export interface OptimizerOptions {
  /** Authoring origin (east,north), in metres, corresponding to the candidate's x/y inputs. */
  anchor: Vec2;
  coarseStepM?: number;
  fineStepM?: number;
  refineRadiusM?: number;
  maxEvaluations?: number;
}
export interface PlacementResult {
  anchor: Vec2;
  areaM2: number;
  deltaFromCurrentM: number;
  metrics: ShadeMetrics;
  /** Scalar objective: lower proposed unshaded area-time is better. */
  shadeDebtM2Hours: number;
}
export interface OptimizationResult {
  model: 'phase3-translation-grid-v1';
  best: PlacementResult | null;
  current: PlacementResult | null;
  currentValid: boolean;
  evaluatedCandidates: number;
  rejectedCandidates: number;
  coarseStepM: number;
  fineStepM: number;
  reason: string;
  rules: string[];
}
interface PreparedSample {
  minutes: number;
  baselineShadedM2: number;
  background: Polygon[];
  sun: ReturnType<typeof sunPosition>;
}
const TOL = 1e-6;
const key = (x:number,y:number)=>`${x.toFixed(5)}:${y.toFixed(5)}`;
function bbox(poly: Polygon) {
  const xs=poly.map(p=>p[0]),ys=poly.map(p=>p[1]);
  return {minX:Math.min(...xs),maxX:Math.max(...xs),minY:Math.min(...ys),maxY:Math.max(...ys)};
}
function translate(poly: Polygon, dx:number, dy:number):Polygon {
  return poly.map(([x,y])=>[x+dx,y+dy] as Vec2);
}
/** Polygon difference by area, with a conservative boundary tolerance. */
function containsFullFootprint(candidate:Polygon, allowed:Polygon):boolean {
  const inside=multiPolygonArea(clippedToWaiting(unionPolygons([candidate]),allowed));
  return polygonArea(candidate)-inside <= TOL;
}
function intersectsPhysical(candidate:Polygon, forbidden:readonly Polygon[]):boolean {
  // Touching at edges is allowed. Positive-area overlaps are rejected.
  for(const zone of forbidden) {
    const cb=bbox(candidate),zb=bbox(zone);
    if(cb.minX>=zb.maxX-TOL||zb.minX>=cb.maxX-TOL||cb.minY>=zb.maxY-TOL||zb.minY>=cb.maxY-TOL) continue;
    if(multiPolygonArea(clippedToWaiting(unionPolygons([candidate]),zone))>TOL) return true;
  }
  return false;
}
/** Validate proposed canopy against authored site geometry, not only a visual warning. */
export function validatePlacement(scenario:InterventionScenario, footprint: Polygon):{valid:boolean;reason:string} {
  const forbidden:Polygon[] = [...scenario.site.exclusionZones,...scenario.site.buildings.map(b=>b.footprint)];
  // Do not suggest spatially overlapping roof structures when ADDing a roof.
  if(scenario.mode==='add')forbidden.push(...scenario.site.baselineCanopies.map(c=>c.footprint));
  if(!containsFullFootprint(footprint,scenario.site.allowedConstructionZone))return {valid:false,reason:'Roof extends beyond the permitted construction zone'};
  if(intersectsPhysical(footprint,forbidden))return {valid:false,reason:'Roof overlaps an exclusion, building, or existing-roof footprint'};
  return {valid:true,reason:'Within permitted construction area; no footprint clashes'};
}
function samplesForSearch(scenario:InterventionScenario):PreparedSample[] {
  const {dateISO,startTimeIST,endTimeIST,sampleMinutes,site,mode}=scenario;
  const begin=parseClockMinutes(startTimeIST),end=parseClockMinutes(endTimeIST,true);
  const samples:PreparedSample[]=[];
  for(let t=begin;t<end;t+=sampleMinutes){
    const minutes=Math.min(sampleMinutes,end-t);
    const sun=sunPosition(istInstant(dateISO,t+minutes/2),site.latitude,site.longitude);
    if(!usableSun(sun))continue;
    const buildings=site.buildings.map(b=>buildingShadow(b,sun));
    const existing=site.baselineCanopies.map(c=>canopyShadow(c,sun));
    const baseline=measureShade(site.waitingArea,[...buildings,...existing]);
    const background=mode==='add'?[...buildings,...existing]:buildings;
    samples.push({minutes,sun,baselineShadedM2:baseline.shadedAreaM2,background});
  }
  return samples;
}
function score(scenario:InterventionScenario, samples:readonly PreparedSample[], canopy:Canopy, anchor:Vec2, at:Vec2): PlacementResult {
  const footprint=translate(canopy.footprint,at[0]-anchor[0],at[1]-anchor[1]);
  const moved={...canopy,footprint};
  const weighted:WeightedCoverageSample[]=samples.map(sample=>({
    durationMinutes:sample.minutes,
    baselineShadedM2:sample.baselineShadedM2,
    proposedShadedM2:measureShade(scenario.site.waitingArea,[...sample.background,canopyShadow(moved,sample.sun)]).shadedAreaM2
  }));
  const metrics=aggregateMetrics(polygonArea(scenario.site.waitingArea),weighted);
  if(!metrics) throw new Error('No daytime samples could be evaluated');
  return {anchor:at,areaM2:polygonArea(footprint),deltaFromCurrentM:Math.hypot(at[0]-anchor[0],at[1]-anchor[1]),metrics,shadeDebtM2Hours:metrics.proposedShadeDebtM2Hours};
}
const beats=(a:PlacementResult,b:PlacementResult|null):boolean=>{
  if(!b)return true;
  if(a.shadeDebtM2Hours < b.shadeDebtM2Hours-1e-7)return true;
  if(Math.abs(a.shadeDebtM2Hours-b.shadeDebtM2Hours)>1e-7)return false;
  if(a.deltaFromCurrentM < b.deltaFromCurrentM-1e-7)return true;
  if(Math.abs(a.deltaFromCurrentM-b.deltaFromCurrentM)>1e-7)return false;
  return a.anchor[0] < b.anchor[0]-1e-7 || (Math.abs(a.anchor[0]-b.anchor[0])<1e-7 && a.anchor[1]<b.anchor[1]);
};
/** Grid enumeration includes deterministic endpoints and the initial placement.
 * maxEvaluations bounds scored candidates, not the number of invalid positions checked.
 * The caller may execute this synchronous pure function in a Worker to avoid UI blocking.
 */
export function optimizeScenario(scenario:InterventionScenario, options:OptimizerOptions):OptimizationResult {
  assertScenario(scenario);
  if(scenario.proposedCanopies.length!==1)throw new Error('Optimizer supports exactly one proposed canopy');
  const anchor=options.anchor;
  if(!Array.isArray(anchor)||anchor.length!==2||!anchor.every(Number.isFinite))throw new Error('Invalid authoring anchor');
  const coarse=options.coarseStepM??1, fine=options.fineStepM??.25,radius=options.refineRadiusM??.75,limit=options.maxEvaluations??750;
  if(![coarse,fine,radius].every(Number.isFinite)||coarse<.25||coarse>3||fine<.1||fine>coarse||radius<0||radius>2||!Number.isInteger(limit)||limit<20||limit>2000)throw new Error('Invalid bounded-search settings');
  const rules=['The selected shape, area, height and rotation are held constant.', 'Search changes only the canopy position in metres east/north.', 'Roof footprint must stay fully inside the permitted region and out of exclusion zones, buildings and existing roof footprints in add mode.', 'Best of the evaluated grid candidates; not an engineering, structural or citywide optimum.', 'Geometric direct-beam shade only. No temperature or construction-cost prediction.'];
  const canopy=scenario.proposedCanopies[0];
  const samples=samplesForSearch(scenario);
  const currentFootprint=canopy.footprint;
  const currentValid=validatePlacement(scenario,currentFootprint).valid;
  if(!samples.length)return {model:'phase3-translation-grid-v1',best:null,current:null,currentValid,evaluatedCandidates:0,rejectedCandidates:0,coarseStepM:coarse,fineStepM:fine,reason:'No evaluable sunlight in this time window. No recommendation made.',rules};
  const allowed=bbox(scenario.site.allowedConstructionZone);
  const original=bbox(currentFootprint);
  const minX=anchor[0]+allowed.minX-original.minX,maxX=anchor[0]+allowed.maxX-original.maxX;
  const minY=anchor[1]+allowed.minY-original.minY,maxY=anchor[1]+allowed.maxY-original.maxY;
  let evaluatedCandidates=0,rejectedCandidates=0;
  const selections:{best:PlacementResult|null;current:PlacementResult|null}={best:null,current:null};
  const visited=new Set<string>();
  const assess=(x:number,y:number)=>{
    if(evaluatedCandidates>=limit)return;
    const id=key(x,y);if(visited.has(id))return;visited.add(id);
    const footprint=translate(currentFootprint,x-anchor[0],y-anchor[1]);
    if(!validatePlacement(scenario,footprint).valid){rejectedCandidates++;return;}
    const result=score(scenario,samples,canopy,anchor,[x,y]);
    evaluatedCandidates++;
    if(beats(result,selections.best))selections.best=result;
    if(Math.abs(x-anchor[0])<1e-7&&Math.abs(y-anchor[1])<1e-7)selections.current=result;
  };
  // The exact design the user authored is always considered first, if valid.
  assess(anchor[0],anchor[1]);
  // Coarse grid in physical world coordinates so results remain independent of viewport.
  for(let ix=Math.ceil(minX/coarse);ix*coarse<=maxX+TOL&&evaluatedCandidates<limit;ix++){
    for(let iy=Math.ceil(minY/coarse);iy*coarse<=maxY+TOL&&evaluatedCandidates<limit;iy++) assess(ix*coarse,iy*coarse);
  }
  // Reproducible local refinement around the highest-ranked coarse candidate.
  if(selections.best){
    const center=[...selections.best.anchor];
    for(let ix=-Math.round(radius/fine);ix<=Math.round(radius/fine)&&evaluatedCandidates<limit;ix++){
      for(let iy=-Math.round(radius/fine);iy<=Math.round(radius/fine)&&evaluatedCandidates<limit;iy++){
        const x=center[0]+ix*fine,y=center[1]+iy*fine;
        if(x<minX-TOL||x>maxX+TOL||y<minY-TOL||y>maxY+TOL)continue;
        assess(Math.round(x*1e5)/1e5,Math.round(y*1e5)/1e5);
      }
    }
  }
  const reason= !selections.best?'No collision-free roof placement was found within the configured constraints.':
    selections.best.metrics.shadeDebtReductionM2Hours<=1e-6?'Valid placement found, but no positive shade benefit against the baseline was demonstrated.':
    `Best tested placement reduces modeled unshaded area-time by ${selections.best.metrics.shadeDebtReductionM2Hours.toFixed(2)} m²·h against the unchanged baseline.`;
  return {model:'phase3-translation-grid-v1',best:selections.best,current:selections.current,currentValid,evaluatedCandidates,rejectedCandidates,coarseStepM:coarse,fineStepM:fine,reason,rules};
}
