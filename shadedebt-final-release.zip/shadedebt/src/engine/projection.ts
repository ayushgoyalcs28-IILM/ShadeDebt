/** Camera-only affine perspective for the Shade Lab. Simulation calculations
 * remain in metre-scale east/north ground coordinates; the camera NEVER changes
 * shadow positions or numerical coverage. A roof uses z>0 and its actual
 * sunlight shadow uses z=0, with connecting rays sharing physical vertices.
 */
import type {Vec2} from '../types/domain';
export const LAB_VIEW={width:960,height:570,cx:470,cy:340} as const;
export function projectSitePoint([east,north]:Vec2,heightM=0):Vec2 {
 return [LAB_VIEW.cx+east*43+north*16,LAB_VIEW.cy+east*9-north*26-heightM*28];
}
export function screenToSite([px,py]:Vec2,heightM=0):Vec2 {
 const x=px-LAB_VIEW.cx,y=py-LAB_VIEW.cy+heightM*28;
 const det=43*(-26)-16*9;
 return [(x*(-26)-16*y)/det,(43*y-9*x)/det];
}
