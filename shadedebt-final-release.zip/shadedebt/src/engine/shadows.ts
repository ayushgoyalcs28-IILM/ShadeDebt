import type { Building, Canopy, Polygon, Vec2 } from '../types/domain';
import type { SunPosition } from './solar';
import { assertConvexPolygon, assertPolygon } from './validation';

/** Minimum supported sun altitude: very low angles produce very long, poorly constrained shadows. */
export const MIN_SOLAR_ALTITUDE_DEG = 5;
export function usableSun(sun: SunPosition): boolean {
  return Number.isFinite(sun.altitudeDeg) && Number.isFinite(sun.azimuthDeg) && sun.altitudeDeg >= MIN_SOLAR_ALTITUDE_DEG && sun.altitudeDeg <= 90;
}
/** Shadow displacement in metres, ground EN coordinates: opposite the solar azimuth. */
export function shadowDisplacement(heightM: number, sun: SunPosition): Vec2 {
  if (!Number.isFinite(heightM) || heightM<0 || !usableSun(sun)) throw new Error('Cannot project a shadow for unsupported height/sun angle');
  const altitude = sun.altitudeDeg * Math.PI / 180;
  const azimuth = sun.azimuthDeg * Math.PI / 180;
  const d = heightM / Math.tan(altitude);
  return [-d*Math.sin(azimuth), -d*Math.cos(azimuth)];
}
/** Canopy: flat, horizontal, completely opaque roof at a constant height. */
export function canopyShadow(canopy: Canopy, sun: SunPosition): Polygon {
  const [dx,dy] = shadowDisplacement(canopy.heightM,sun);
  return canopy.footprint.map(([x,y])=>[x+dx,y+dy] as Vec2);
}
function cross(a:Vec2,b:Vec2,c:Vec2):number {return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);}
/** Monotone-chain convex hull. Handles repeated coordinates and co-linear points. */
export function convexHull(points: readonly Vec2[]): Polygon {
  const sorted = [...points].sort((a,b)=>a[0]-b[0] || a[1]-b[1]);
  const unique = sorted.filter((p,i)=>i===0 || p[0]!==sorted[i-1][0] || p[1]!==sorted[i-1][1]);
  if (unique.length<3) throw new Error('Not enough unique points for convex hull');
  const lower:Vec2[]=[], upper:Vec2[]=[];
  for (const p of unique) {while(lower.length>=2 && cross(lower[lower.length-2],lower[lower.length-1],p)<=0)lower.pop();lower.push(p);}
  for (const p of [...unique].reverse()) {while(upper.length>=2 && cross(upper[upper.length-2],upper[upper.length-1],p)<=0)upper.pop();upper.push(p);}
  lower.pop();upper.pop();
  const hull=[...lower,...upper];
  assertPolygon(hull,'convex hull');
  return hull;
}
/** Solid vertical convex prism shadow = convex hull of its footprint and translated roof.
 * Unlike translating the roof alone, includes shadow from ALL walls and occupied ground.
 * Convex footprints only (rectangles supported); concave buildings must be decomposed.
 */
export function buildingShadow(building: Building, sun: SunPosition): Polygon {
  assertConvexPolygon(building.footprint,'building footprint');
  const [dx,dy]=shadowDisplacement(building.heightM,sun);
  const translated=building.footprint.map(([x,y])=>[x+dx,y+dy] as Vec2);
  return convexHull([...building.footprint,...translated]);
}
