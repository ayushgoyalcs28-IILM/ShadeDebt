import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight, MapPin, Pause, Play, RotateCcw, Ruler, ShieldAlert, Sparkles, Printer, SlidersHorizontal, Move } from 'lucide-react';
import type { CanopyShape, Polygon, Vec2 } from '../types/domain';
import { sampleDraft, toScenario, outline, switchRoofShape, moveCustomVertex, toScreen, fromScreen, svgPath, clippedPath, footprintArea, SCENE, type SiteDraft, type DesignDraft } from '../engine/editor';
import { simulateScenario, evaluateSunPosition } from '../engine/simulation';
import { istInstant, sunPosition } from '../engine/solar';
import { shadowDisplacement, usableSun } from '../engine/shadows';
import { polygonArea } from '../engine/geometry';
import { parseClockMinutes } from '../engine/validation';
import { unionPolygons, clippedToWaiting, multiPolygonArea } from '../engine/overlap';
import { todayInDelhi } from '../engine/date';
import { draftStorageKey,legacyDraftStorageKey } from '../data/siteIdentity';
import { validatePlacement, type OptimizationResult } from '../engine/optimizer';
import { configuredOptimizerUrl, optimizeInCloud, CloudOptimizationError } from '../cloud/optimizer';

interface Props { latitude:number; longitude:number; name:string; siteKey?:string; }
type EditableKey = 'proposal'|'existing'|'waiting'|'building';
type MoveState={key:EditableKey;startWorld:Vec2;initial:SiteDraft;vertex?:number};
const shapes:{value:CanopyShape;label:string;symbol:string;subtitle:string}[]=[
  {value:'rectangle',label:'Rectangle',symbol:'▭',subtitle:'Standard roof'},
  {value:'circle',label:'Circle',symbol:'◯',subtitle:'Round canopy'},
  {value:'triangle',label:'Triangle',symbol:'△',subtitle:'3-sided roof'},
  {value:'trapezoid',label:'Trapezoid',symbol:'▱',subtitle:'Tapered form'},
  {value:'hexagon',label:'Hexagon',symbol:'⬡',subtitle:'6-sided roof'},
  {value:'custom',label:'Freeform',symbol:'⬠',subtitle:'Edit 5 corners'}
];
function signed(value:number,digits=1){return `${value>0?'+':''}${value.toFixed(digits)}`;}
const clone=(d:SiteDraft):SiteDraft=>structuredClone(d);
function restoredDraft(lat:number,lon:number,name:string,siteKey:string):SiteDraft {
  const fallback=sampleDraft(lat,lon,name);
  try {
    let raw=localStorage.getItem(draftStorageKey(siteKey));
    let fromLegacy=false;
    if(!raw){
      const oldKey=legacyDraftStorageKey(lat,lon);
      const ownerKey=draftStorageKey(`legacy-owner:${oldKey}`);
      const owner=localStorage.getItem(ownerKey);
      if(owner===null || owner===siteKey){raw=localStorage.getItem(oldKey);fromLegacy=Boolean(raw);}
    }
    if (!raw) return fallback;
    const stored:SiteDraft=JSON.parse(raw);
    if (stored.latitude!==lat || stored.longitude!==lon || (fromLegacy&&stored.name!==name) || !stored.waiting || !stored.proposal || !stored.existing || !stored.building) return fallback;
    if(fromLegacy)localStorage.setItem(draftStorageKey(`legacy-owner:${legacyDraftStorageKey(lat,lon)}`),siteKey);
    stored.constraints={...fallback.constraints,...stored.constraints};
    stored.date=todayInDelhi();
    toScenario(stored); // geometry conversion validates outlines
    return stored;
  } catch{return fallback;}
}

const clock=(mins:number)=>`${String(Math.floor(mins/60)).padStart(2,'0')}:${String(mins%60).padStart(2,'0')}`;
const safeMinutes=(value:string,fallback:number)=>{try{return parseClockMinutes(value,true);}catch{return fallback;}};
const dateLabel=(iso:string)=>{const [y,m,d]=iso.split('-');return y&&m&&d?`${d} ${['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][Number(m)-1]??m} ${y}`:iso;};
function RoofGlyph({shape}:{shape:CanopyShape}){
  if(shape==='circle')return <circle cx="24" cy="24" r="14"/>;
  if(shape==='rectangle')return <rect x="9" y="14" width="30" height="20" rx="1"/>;
  if(shape==='triangle')return <path d="M24 9 41 37H7Z"/>;
  if(shape==='trapezoid')return <path d="M17 11H31L41 37H7Z"/>;
  if(shape==='hexagon')return <path d="M15 10H33L42 24 33 38H15L6 24Z"/>;
  return <path d="M6 15 23 7 40 18 34 34 19 39 8 29Z"/>;
}
function NumberField({label,value,step=.1,min=-10,max=30,onChange,unit='m'}:{label:string;value:number;step?:number;min?:number;max?:number;onChange:(n:number)=>void;unit?:string}){
  return <label className="lab-number-field"><span>{label}</span><span className="field-input"><input aria-label={label} type="number" min={min} max={max} step={step} value={Number(value.toFixed(3))} onChange={e=>{const n=Number(e.target.value);if(e.target.value!==''&&Number.isFinite(n)&&n>=min&&n<=max)onChange(n);}}/><small>{unit}</small></span></label>;
}
function FieldBlock({title,children}:{title:string;children:React.ReactNode}){return <div className="lab-field-block"><h4>{title}</h4><div className="lab-field-grid">{children}</div></div>;}
function renderedShadow(shapes:Polygon[],color:string,opacity:number,keyPrefix:string){return shapes.map((p,i)=><path key={`${keyPrefix}-${i}`} d={svgPath(p)} fill={color} opacity={opacity} stroke={color} strokeWidth="1"/>);}

export default function ShadeLab({latitude,longitude,name,siteKey}:Props){
  const identity=siteKey??`legacy:${latitude}:${longitude}`;
  const [draft,setDraft]=useState<SiteDraft>(()=>restoredDraft(latitude,longitude,name,identity));
  const latestSavedDraft=useRef(draft);latestSavedDraft.current=draft;
  const [chosen,setChosen]=useState<EditableKey>('proposal');
  const [time,setTime]=useState(16*60);
  const [playing,setPlaying]=useState(false);
  const [showRays,setShowRays]=useState(true);
  const [view,setView]=useState<'after'|'before'>('after');
  const [showMeasurements,setShowMeasurements]=useState(true);
  const [tab,setTab]=useState<'design'|'site'>('design');
  const [notice,setNotice]=useState('');
  const [stableDraft,setStableDraft]=useState(draft);
  const [optimization,setOptimization]=useState<{key:string;result:OptimizationResult}|null>(null);
  const [optimizing,setOptimizing]=useState(false);
  const [searchError,setSearchError]=useState('');
  const [previewPlacement,setPreviewPlacement]=useState(false);
  const [lockRoofArea,setLockRoofArea]=useState(true);
  const [showAllShapes,setShowAllShapes]=useState(false);
  const workerRef=useRef<Worker|null>(null);
  const cloudAbortRef=useRef<AbortController|null>(null);
  const activeSearchId=useRef(0);
  const [searchSource,setSearchSource]=useState<'aws'|'local'|null>(null);
  const [searchNotice,setSearchNotice]=useState('');
  const [reportOpen,setReportOpen]=useState(false);
  const draftKey=JSON.stringify(draft);
  const latestDraftKeyRef=useRef(draftKey);
  latestDraftKeyRef.current=draftKey;
  const dragRef=useRef<MoveState|null>(null);
  const svgRef=useRef<SVGSVGElement|null>(null);
  useEffect(()=>{setDraft(d=>({...d,latitude,longitude,date:todayInDelhi()}));},[latitude,longitude]);
  useEffect(()=>{
    // Refresh on browser focus, tab resume, and after Delhi midnight without a new API.
    const sync=()=>{const today=todayInDelhi();setDraft(d=>d.date===today?d:{...d,date:today});};
    const onVisibility=()=>{if(!document.hidden)sync();};
    window.addEventListener('focus',sync);document.addEventListener('visibilitychange',onVisibility);
    const interval=window.setInterval(sync,60_000);sync();
    return()=>{window.removeEventListener('focus',sync);document.removeEventListener('visibilitychange',onVisibility);window.clearInterval(interval);};
  },[]);
  useEffect(()=>{
    activeSearchId.current++;
    cloudAbortRef.current?.abort();cloudAbortRef.current=null;
    if(workerRef.current){workerRef.current.terminate();workerRef.current=null;}
    setOptimizing(false);
  },[draftKey]);
  useEffect(()=>()=>{activeSearchId.current++;cloudAbortRef.current?.abort();workerRef.current?.terminate();},[]);
  useEffect(()=>{const token=window.setTimeout(()=>{try{localStorage.setItem(draftStorageKey(identity),JSON.stringify(draft));}catch{/* browser storage may be disabled */}},250);return()=>window.clearTimeout(token);},[draft,identity]);
  // Always flush the most recent edit when navigating away (even within 250 ms).
  useEffect(()=>()=>{try{localStorage.setItem(draftStorageKey(identity),JSON.stringify(latestSavedDraft.current));}catch{/* private browsing */}},[identity]);
  useEffect(()=>{const id=window.setTimeout(()=>setStableDraft(draft),150);return()=>window.clearTimeout(id);},[draft]);
  const startMinute=safeMinutes(draft.from,720), endMinute=safeMinutes(draft.to,1020);
  useEffect(()=>{setTime(t=>Math.min(Math.max(t,startMinute),Math.max(startMinute,endMinute)));},[startMinute,endMinute]);
  useEffect(()=>{if(!playing)return;const timer=window.setInterval(()=>setTime(t=>t+15>endMinute?startMinute:t+15),440);return()=>window.clearInterval(timer);},[playing,startMinute,endMinute]);

  const update=<K extends keyof SiteDraft>(key:K,value:SiteDraft[K])=>setDraft(d=>({...d,[key]:value}));
  const updateRoof=(key:'existing'|'proposal',changes:Partial<DesignDraft>)=>setDraft(d=>({...d,[key]:{...d[key],...changes}}));
  const updateWaiting=(changes:Partial<SiteDraft['waiting']>)=>setDraft(d=>({...d,waiting:{...d.waiting,...changes}}));
  const updateBuilding=(changes:Partial<SiteDraft['building']>)=>setDraft(d=>({...d,building:{...d.building,...changes}}));
  const updateConstraint=(key:'allowed'|'noBuild',changes:Partial<SiteDraft['constraints']['allowed']&SiteDraft['constraints']['noBuild']>)=>
    setDraft(d=>({...d,constraints:{...d.constraints,[key]:{...d.constraints[key],...changes}}}));
  const cancelOptimization=()=>{
    activeSearchId.current++;
    cloudAbortRef.current?.abort();cloudAbortRef.current=null;
    workerRef.current?.terminate();workerRef.current=null;
    setOptimizing(false);setSearchNotice('Search cancelled. Your current design was not changed.');
  };
  const runLocalSearch=(scenario:ReturnType<typeof toScenario>,requestKey:string,runId:number,wasFallback:boolean)=>{
    if(activeSearchId.current!==runId)return;
    try{
      const worker=new Worker(new URL('../workers/optimizer.worker.ts',import.meta.url),{type:'module'});
      workerRef.current=worker;
      worker.onmessage=(event:MessageEvent<{ok:boolean;result?:OptimizationResult;error?:string}>)=>{
        if(workerRef.current!==worker||activeSearchId.current!==runId)return;
        worker.terminate();workerRef.current=null;setOptimizing(false);
        if(latestDraftKeyRef.current!==requestKey)return;
        if(event.data.ok&&event.data.result){setOptimization({key:requestKey,result:event.data.result});setSearchSource('local');}
        else setSearchError(event.data.error??'The local placement search could not complete.');
      };
      worker.onerror=()=>{
        if(workerRef.current!==worker||activeSearchId.current!==runId)return;
        worker.terminate();workerRef.current=null;setOptimizing(false);
        setSearchError('Local search worker failed. Please retry or verify the deployed Worker assets.');
      };
      worker.postMessage({requestId:runId,scenario,options:{anchor:[draft.proposal.x,draft.proposal.y],coarseStepM:1,fineStepM:.25,refineRadiusM:.75,maxEvaluations:750}});
      if(!wasFallback)setSearchNotice('Local browser search · no cloud endpoint configured.');
    }catch(error){
      setOptimizing(false);setSearchError(error instanceof Error?error.message:'Could not start the local search.');
    }
  };
  const beginOptimization=()=>{
    cancelOptimization();
    setSearchError('');setSearchNotice('');setSearchSource(null);
    setPreviewPlacement(false);setOptimization(null);
    const runId=activeSearchId.current;
    const requestKey=draftKey;
    try{
      const scenario=toScenario(draft);
      const options={anchor:[draft.proposal.x,draft.proposal.y] as const,coarseStepM:1,fineStepM:.25,refineRadiusM:.75,maxEvaluations:750};
      setOptimizing(true);
      const url=configuredOptimizerUrl();
      if(!url){runLocalSearch(scenario,requestKey,runId,false);return;}
      const controller=new AbortController();cloudAbortRef.current=controller;
      void optimizeInCloud(url,scenario,options,controller.signal).then(result=>{
        if(activeSearchId.current!==runId||latestDraftKeyRef.current!==requestKey)return;
        cloudAbortRef.current=null;setOptimizing(false);
        setOptimization({key:requestKey,result});setSearchSource('aws');
        setSearchNotice('Recommendation calculated by AWS Lambda using the shared simulation engine.');
      }).catch(error=>{
        if(activeSearchId.current!==runId||latestDraftKeyRef.current!==requestKey||controller.signal.aborted)return;
        cloudAbortRef.current=null;
        if(error instanceof CloudOptimizationError && !error.shouldFallback){setOptimizing(false);setSearchError(error.message);return;}
        setSearchNotice('AWS unavailable or timed out. Showing a local Worker result instead; no cloud operation was completed.');
        runLocalSearch(scenario,requestKey,runId,true);
      });
    }catch(error){setOptimizing(false);setSearchError(error instanceof Error?error.message:'Could not start search');}
  };
  const acceptedSearch=optimization?.key===draftKey?optimization.result:null;
  const applyBest=()=>{
    if(!acceptedSearch?.best)return;
    const [x,y]=acceptedSearch.best.anchor;
    try {
      const scenario=toScenario(draft);
      const translated=scenario.proposedCanopies[0].footprint.map(([east,north])=>[
        east+x-draft.proposal.x,north+y-draft.proposal.y
      ] as Vec2);
      const validity=validatePlacement(scenario,translated);
      const expectedArea=polygonArea(scenario.proposedCanopies[0].footprint);
      if(!validity.valid || Math.abs(acceptedSearch.best.areaM2-expectedArea)>0.001){
        setSearchError('This recommendation no longer satisfies the site constraints. Please run search again.');return;
      }
      setDraft(d=>({...d,proposal:{...d.proposal,x,y}}));
      setPreviewPlacement(false);
      setNotice('Recommendation applied. Live metrics were recalculated locally from the new geometry.');
    }catch{setSearchError('Cannot apply recommendation to invalid geometry.');}
  };

  const evaluation=useMemo(()=>{try {const scenario=toScenario(stableDraft);return {result:simulateScenario(scenario),error:''};}catch(e){return {result:null,error:e instanceof Error?e.message:'Invalid site geometry'};}},[stableDraft]);
  const instant=useMemo(()=>{try {
    const scenario=toScenario(draft);
    const sun=sunPosition(istInstant(draft.date,time),draft.latitude,draft.longitude);
    return {sun,evaluated:usableSun(sun)?evaluateSunPosition(scenario.site,scenario.proposedCanopies,scenario.mode,sun):null,error:''};
  }catch(e){return {sun:null,evaluated:null,error:e instanceof Error?e.message:'Invalid geometry'};}},[draft,time]);
  const site=useMemo(()=>{try {return toScenario(draft).site;}catch{return null;}},[draft]);
  const building=draft.building;
  const mainResult=evaluation.result;
  const metrics=mainResult?.metrics;
  const instantaneous=instant.evaluated;
  const waitingAreaM2=site?polygonArea(site.waitingArea):0;
  const shownCoverage=instantaneous?(view==='after'?instantaneous.proposed.coverage:instantaneous.baseline.coverage):null;

  const clientToWorld=(clientX:number,clientY:number):Vec2=>{
    const svg=svgRef.current;if(!svg)return [0,0];
    const ctm=svg.getScreenCTM();if(!ctm)return [0,0];
    const point=new DOMPoint(clientX,clientY).matrixTransform(ctm.inverse());
    return fromScreen([point.x,point.y]);
  };
  const beginDrag=(e:React.PointerEvent<SVGElement>,key:EditableKey,vertex?:number)=>{
    if(e.button!==0)return;
    e.preventDefault();e.stopPropagation();setChosen(key);
    dragRef.current={key,startWorld:clientToWorld(e.clientX,e.clientY),initial:clone(draft),vertex};
    (e.currentTarget as SVGElement).setPointerCapture(e.pointerId);
  };
  const onMove=(e:React.PointerEvent<SVGSVGElement>)=>{
    const move=dragRef.current;if(!move)return;
    const current=clientToWorld(e.clientX,e.clientY);
    const dx=current[0]-move.startWorld[0],dy=current[1]-move.startWorld[1];
    const r=(v:number)=>Math.round(v*100)/100;
    if(move.vertex!==undefined){
      const original=move.initial.proposal;
      const a=original.rotation*Math.PI/180,c=Math.cos(a),s=Math.sin(a);
      const world=[current[0]-original.x,current[1]-original.y] as Vec2;
      const local=[r(world[0]*c+world[1]*s),r(-world[0]*s+world[1]*c)] as Vec2;
      try{const p=moveCustomVertex(original,move.vertex,local);setDraft(d=>({...d,proposal:p}));setNotice('');}
      catch{setNotice('Vertex would create an invalid polygon. Drag to a non-crossing location.');}
      return;
    }
    const old=move.initial[move.key];
    const x=r(old.x+dx),y=r(old.y+dy);
    setDraft(d=>({...d,[move.key]:{...d[move.key],x,y}}));
  };
  const stopDrag=()=>{dragRef.current=null;};
  const shapeClick=(shape:CanopyShape)=>{
    try{setDraft(d=>({...d,proposal:switchRoofShape(d.proposal,shape,lockRoofArea)}));setChosen('proposal');setNotice('');}
    catch{setNotice('Could not preserve the area for that shape; review geometry.');}
  };
  const clearAndReset=()=>{try{localStorage.removeItem(draftStorageKey(identity));}catch{}setDraft(sampleDraft(draft.latitude,draft.longitude,draft.name));setTime(16*60);setNotice('Restored illustrative geometry.');};
  const canRender=!!(site&&instant.sun&&instant.evaluated);
  const shift=instant.sun && usableSun(instant.sun)?shadowDisplacement(draft.proposal.height,instant.sun):null;
  const solarBearing=instant.sun?.azimuthDeg??0;
  const solarRad=solarBearing*Math.PI/180;
  const roofPoint=toScreen([draft.proposal.x,draft.proposal.y]);
  const shiftPoint=shift?toScreen([draft.proposal.x+shift[0],draft.proposal.y+shift[1]]):null;
  const roofOutline=useMemo(()=>{try{return outline(draft.proposal);}catch{return null;}},[draft.proposal]);
  const placementStatus=useMemo(()=>{try{return validatePlacement(toScenario(draft),outline(draft.proposal));}catch{return {valid:false,reason:'Invalid geometry'};}},[draft]);
  const planWarnings=useMemo(()=>{if(!site||!roofOutline)return [] as string[];
    try {const footprint=polygonArea(roofOutline);
      const inAllowed=multiPolygonArea(clippedToWaiting(unionPolygons([roofOutline]),site.allowedConstructionZone));
      const clashes=site.exclusionZones.some(zone=>multiPolygonArea(clippedToWaiting(unionPolygons([roofOutline]),zone))>1e-5);
      return [...(inAllowed<footprint-1e-5?['The proposed roof extends beyond the permitted construction envelope.']:[]),...(clashes?['The proposed roof overlaps a road or exclusion zone.']:[]),...(!placementStatus.valid&&inAllowed>=footprint-1e-5&&!clashes?[placementStatus.reason]:[])];
    }catch{return ['Check the proposed canopy outline and constraints.'];}
  },[site,roofOutline,placementStatus]);

  const outcome = metrics ? metrics.averageProposedCoverage - metrics.averageBaselineCoverage : 0;
  const changePoints = outcome * 100;
  const verdict = !metrics ? 'Set a daylight simulation window to compare.' :
    changePoints > .1 ? 'Your design shades more of the waiting space.' :
    changePoints < -.1 ? 'This design shades less of the waiting space.' :
    'This change makes little difference to useful shade.';
  const baselinePct=metrics?Math.round(metrics.averageBaselineCoverage*100):0;
  const proposedPct=metrics?Math.round(metrics.averageProposedCoverage*100):0;
  const printReport=()=>setReportOpen(true);
  const chartSamples=mainResult?.samples.filter(s=>s.baselineCoverage!==null&&s.proposedCoverage!==null)??[];
  const samplePolyline=(key:'baselineCoverage'|'proposedCoverage')=>chartSamples.map((s,i)=>{
    const x=18+(i/Math.max(1,chartSamples.length-1))*474;
    const y=91-(s[key]??0)*75;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  return <div className="studio">
    <header className="studio-intro">
      <div className="studio-intro-copy"><div className="studio-eyebrow"><span className="studio-spark"/> LIVE DESIGN STUDIO · {dateLabel(draft.date)}</div><h1>See where the shade lands.</h1><p>Move a canopy. Follow the sun. Find out whether your design actually protects the waiting area.</p></div>
      <div className="studio-place"><MapPin size={17}/><div><strong>{draft.name}</strong><small>{draft.mode==='concept'?'Illustrative shelter dimensions':'User-supplied dimensions'} · {latitude.toFixed(3)}°, {longitude.toFixed(3)}°</small></div></div>
    </header>
    <div className="studio-layout">
      <section className="studio-stage" aria-label="Live geometric shade simulation">
        <div className="studio-stage-head"><div><span className="studio-section-step">LIVE SIMULATION</span><h2>See the shade change</h2></div><div className="studio-view-buttons" aria-label="Compare conditions"><button className={view==='before'?'active':''} onClick={()=>setView('before')}>Before</button><button className={view==='after'?'active':''} onClick={()=>setView('after')}>With design</button></div></div>
        <div className="studio-scene">
          <svg ref={svgRef} viewBox={`0 0 ${SCENE.width} ${SCENE.height}`} role="img" aria-label="True scale top-down bus shelter site with projected sunlight and shade" className="studio-svg" onPointerMove={onMove} onPointerUp={stopDrag} onPointerCancel={stopDrag}>
            <defs>
              <pattern id="studio-paving" width="32" height="32" patternUnits="userSpaceOnUse"><path d="M32 0H0V32" fill="none" stroke="#c2cdc0" strokeOpacity=".5" strokeWidth=".8"/></pattern>
              <linearGradient id="studio-daylight" x1="0" x2=".85" y1="0" y2="1"><stop offset="0" stopColor="#f6eed5"/><stop offset="1" stopColor="#e9f1e6"/></linearGradient>
              <filter id="studio-soft-shadow"><feGaussianBlur stdDeviation="4"/></filter>
              <filter id="studio-sun-glow"><feGaussianBlur stdDeviation="11"/></filter>
            </defs>
            <rect width={SCENE.width} height={SCENE.height} fill="url(#studio-daylight)"/>
            <rect width={SCENE.width} height={SCENE.height} fill="url(#studio-paving)"/>
            {site?.exclusionZones[0]&&<g pointerEvents="none"><path d={svgPath(site.exclusionZones[0])} fill="#bbc5bf" stroke="#879992" strokeWidth="2"/><path d={svgPath(site.exclusionZones[0])} fill="none" stroke="#ffffff" strokeDasharray="20 17" strokeWidth="1.7" strokeOpacity=".65"/></g>}
            <path d="M0 464 H880" stroke="#839d93" strokeWidth="1" strokeDasharray="14 12" opacity=".48"/>
            {site?.exclusionZones.slice(1).map((zone,i)=><path key={i} d={svgPath(zone)} fill="#eabdb0" fillOpacity=".4" stroke="#ad715f" strokeDasharray="6 4" strokeWidth="1.5"/>)}
            {showMeasurements&&site&&<path d={svgPath(site.allowedConstructionZone)} fill="none" stroke="#538f78" strokeWidth="1.4" strokeDasharray="8 7" opacity=".4"/>}
            {site&&<g>
              <path d={svgPath(site.waitingArea)} fill="#f5d6a0" fillOpacity=".6" stroke="#c48639" strokeWidth="2.4" strokeDasharray="8 5" className="studio-draggable" onPointerDown={e=>beginDrag(e,'waiting')}/>
              <text x={toScreen([draft.waiting.x,draft.waiting.y])[0]} y={toScreen([draft.waiting.x,draft.waiting.y])[1]-draft.waiting.depth*16-16} textAnchor="middle" fontSize="13" fontWeight="800" fill="#815b30" pointerEvents="none">PASSENGER WAITING AREA</text>
              {[0,1,2,3].map(i=>{const w=draft.waiting,wx=w.x-w.width/2+(i+.7)*w.width/4.7,wy=w.y-.4;const rad=w.rotation*Math.PI/180;const [x,y]=toScreen([w.x+(wx-w.x)*Math.cos(rad)-(wy-w.y)*Math.sin(rad),w.y+(wx-w.x)*Math.sin(rad)+(wy-w.y)*Math.cos(rad)]);return <g key={i} transform={`translate(${x},${y})`} pointerEvents="none"><ellipse cy="17" rx="8" ry="3" fill="#797e70" opacity=".15"/><circle cy="-10" r="5.8" fill="#64766a"/><path d="M-6-1Q0-6 6-1L8 17H-8Z" fill="#59756d"/></g>;})}
            </g>}
            {building.enabled&&site?.buildings[0]&&<g className="studio-draggable" onPointerDown={e=>beginDrag(e,'building')}><path d={svgPath(site.buildings[0].footprint)} fill="#bbc3bf" stroke="#6e8178" strokeWidth="2.5"/><text x={toScreen([building.x,building.y])[0]} y={toScreen([building.x,building.y])[1]+4} textAnchor="middle" fontSize="12" fontWeight="700" fill="#415b50" pointerEvents="none">BUILDING</text></g>}
            {instant.evaluated&&<g pointerEvents="none">
              {renderedShadow(view==='after'?instant.evaluated.proposedShadows:instant.evaluated.baselineShadows,'#466b5d',.23,'world-shadow')}
              <path d={clippedPath(view==='after'?instant.evaluated.proposed.shadedWithinWaiting:instant.evaluated.baseline.shadedWithinWaiting)} fill="#369e83" fillOpacity=".62" fillRule="evenodd" stroke="#27866e" strokeWidth="1"/>
            </g>}
            {site?.baselineCanopies.map(c=><g key={c.id} className="studio-draggable" onPointerDown={e=>beginDrag(e,'existing')}>
              <path d={svgPath(c.footprint)} fill="#6a8079" fillOpacity=".12" stroke="#465e56" strokeWidth="5" strokeLinejoin="round"/>
              <path d={svgPath(c.footprint)} fill="#e4e8df" fillOpacity=".83" stroke="#4b655c" strokeWidth="2.2"/>
              {c.footprint.filter((_,j)=>j%Math.max(1,Math.floor(c.footprint.length/4))===0).slice(0,4).map((pt,j)=>{const [x,y]=toScreen(pt);return <circle key={j} cx={x} cy={y} r="4" fill="#375f51" stroke="#e9f0e7" strokeWidth="1.5"/>;})}
              <text x={toScreen([draft.existing.x,draft.existing.y])[0]} y={toScreen([draft.existing.x,draft.existing.y])[1]+4} fill="#304d42" fontSize="12" textAnchor="middle" fontWeight="750" pointerEvents="none">EXISTING</text>
            </g>)}
            {view==='after'&&site&&<g>
              <path d={svgPath(outline(draft.proposal))} fill="#c5e8d6" fillOpacity=".84" stroke="#1b8567" strokeWidth="3.3" className="studio-draggable" onPointerDown={e=>beginDrag(e,'proposal')}/>
              <text x={toScreen([draft.proposal.x,draft.proposal.y])[0]} y={toScreen([draft.proposal.x,draft.proposal.y])[1]+4} textAnchor="middle" fontWeight="800" fontSize="12" fill="#155b48" pointerEvents="none">YOUR DESIGN</text>
              {draft.proposal.shape==='custom'&&chosen==='proposal'&&draft.proposal.vertices.map((p,i)=>{const a=draft.proposal.rotation*Math.PI/180,c=Math.cos(a),sin=Math.sin(a);const screen=toScreen([draft.proposal.x+p[0]*c-p[1]*sin,draft.proposal.y+p[0]*sin+p[1]*c]);return <circle key={i} cx={screen[0]} cy={screen[1]} r="7" fill="#ffffff" stroke="#15886d" strokeWidth="2.5" className="studio-draggable" onPointerDown={e=>beginDrag(e,'proposal',i)}/>;})}
            </g>}
            {view==='after'&&previewPlacement&&acceptedSearch?.best&&roofOutline&&<g pointerEvents="none"><path d={svgPath(roofOutline.map(([x,y])=>[x+acceptedSearch.best!.anchor[0]-draft.proposal.x,y+acceptedSearch.best!.anchor[1]-draft.proposal.y] as Vec2))} fill="#f0b35e" fillOpacity=".45" stroke="#ab711e" strokeWidth="3" strokeDasharray="8 5"/><text x={toScreen(acceptedSearch.best.anchor)[0]} y={toScreen(acceptedSearch.best.anchor)[1]-26} fill="#755016" textAnchor="middle" fontWeight="800" fontSize="12">SUGGESTED POSITION</text></g>}
            {showRays&&shiftPoint&&view==='after'&&<g pointerEvents="none"><path d={`M${roofPoint[0]} ${roofPoint[1]}L${shiftPoint[0]} ${shiftPoint[1]}`} stroke="#c79242" strokeDasharray="7 5" strokeWidth="2"/><circle cx={shiftPoint[0]} cy={shiftPoint[1]} r="4" fill="#be8740"/></g>}
            <g transform="translate(76 63)" pointerEvents="none"><circle r="28" fill="#ffffff" fillOpacity=".83"/><path d="M0 17V-16M-7-9L0-18 7-9" fill="none" stroke="#315e50" strokeWidth="2.7"/><text y="-28" textAnchor="middle" fill="#315e50" fontWeight="800" fontSize="10">NORTH</text></g>
            <g transform="translate(766 91)" pointerEvents="none"><circle r="63" fill="#fff8e8" stroke="#decbac" strokeWidth="1.2"/><circle r="42" fill="none" stroke="#dfc69e" strokeDasharray="3 6"/><path d="M0-49V49M-49 0H49" stroke="#e6d5b9" strokeWidth="1"/><line x1="0" y1="0" x2={Math.sin(solarRad)*39} y2={-Math.cos(solarRad)*39} stroke="#dd9630" strokeWidth="3"/><circle cx={Math.sin(solarRad)*39} cy={-Math.cos(solarRad)*39} r="9" fill="#f0b24d"/><text x="0" y="-73" textAnchor="middle" fontSize="11" fill="#835c27" fontWeight="800">SUN POSITION</text><text y="78" textAnchor="middle" fontSize="12" fill="#77593d" fontWeight="700">{instant.sun?`${Math.round(instant.sun.altitudeDeg)}° above horizon`: '—'}</text></g>
            {showMeasurements&&<g pointerEvents="none"><path d="M50 439H210" stroke="#3f6555" strokeWidth="2"/><path d="M50 433V445M210 433V445" stroke="#3f6555" strokeWidth="2"/><text x="130" y="426" textAnchor="middle" fill="#436451" fontWeight="700" fontSize="12">5 m scale</text></g>}
          </svg>
          {!canRender&&<div className="studio-scene-error">{instant.error || 'Sunlight cannot be modeled at this hour. Move the time slider.'}</div>}
          <div className="studio-legend"><span><i className="studio-key studio-key-exposed"/> Sun-exposed waiting zone</span><span><i className="studio-key studio-key-shaded"/> Useful shade</span><span><i className="studio-key studio-key-canopy"/> Proposed canopy</span></div>
        </div>
        <div className="studio-playback"><div className="studio-clock"><button aria-label={playing?'Pause simulation':'Play simulation'} className="studio-play" onClick={()=>setPlaying(p=>!p)}>{playing?<Pause size={20}/>:<Play size={20}/>}</button><div><strong>{clock(time)} <small>IST</small></strong><span>{dateLabel(draft.date)} · today's sun position</span></div></div><label className="studio-slider"><span className="visually-hidden">Move through the day</span><input type="range" aria-label="Simulation time" min={Math.min(startMinute,endMinute-1)} max={Math.max(startMinute+1,endMinute)} step={15} value={time} onChange={e=>{setTime(Number(e.target.value));setPlaying(false);}}/><div><span>{draft.from}</span><span>{draft.to}</span></div></label></div>
        <div className="studio-stage-footer"><span><Move size={15}/> Drag the canopy directly on the plan</span><span>{shownCoverage===null?'Low sun / outside model':`${Math.round(shownCoverage*100)}% shaded at this moment`}</span></div>
      </section>
      <aside className="studio-editor">
        <div className="studio-editor-head"><div><span className="studio-section-step">DESIGN CONTROLS</span><h2>Design your canopy</h2></div><button className="studio-reset" onClick={clearAndReset} title="Restore example dimensions"><RotateCcw size={16}/></button></div>
        <div className="studio-editor-body">
          <div className="studio-shape-heading">Choose a roof <small>Select, then drag on the plan</small></div>
          <div className="studio-shapes">{shapes.filter((s,i)=>showAllShapes||i<2||s.value===draft.proposal.shape).map(s=><button key={s.value} onClick={()=>shapeClick(s.value)} className={draft.proposal.shape===s.value?'active':''} title={s.subtitle}><svg viewBox="0 0 48 48"><RoofGlyph shape={s.value}/></svg><span>{s.label}</span></button>)}<button type="button" className="studio-more-shapes" onClick={()=>setShowAllShapes(v=>!v)} aria-expanded={showAllShapes}>{showAllShapes?"Less shapes":"More shapes"}</button></div>
          <div className="studio-help"><Move size={15}/> Drag the green canopy to test another position.</div>
          <div className="studio-essentials"><NumberField label={draft.proposal.shape==='circle'?'Diameter':'Roof width'} value={draft.proposal.width} min={.5} max={14} onChange={n=>updateRoof('proposal',{width:n,depth:draft.proposal.shape==='circle'?n:draft.proposal.depth})}/>{!['circle','hexagon','custom'].includes(draft.proposal.shape)&&<NumberField label="Roof depth" value={draft.proposal.depth} min={.5} max={12} onChange={n=>updateRoof('proposal',{depth:n})}/>}<NumberField label="Height" value={draft.proposal.height} min={.3} max={15} onChange={n=>updateRoof('proposal',{height:n})}/></div>
          <button type="button" className="studio-site-link" onClick={()=>setTab(tab==='site'?'design':'site')}><Ruler size={15}/> {tab==='site'?'Hide site measurements':'Edit site measurements'}</button>
          <details className="studio-details"><summary><SlidersHorizontal size={16}/> More design controls</summary><div className="studio-details-body"><label className="studio-check"><input type="checkbox" checked={lockRoofArea} onChange={e=>setLockRoofArea(e.target.checked)}/> Keep roof area equal when switching shapes</label><NumberField label="Rotation" value={draft.proposal.rotation} unit="°" min={-180} max={180} step={5} onChange={n=>updateRoof('proposal',{rotation:n})}/><NumberField label="East / west" value={draft.proposal.x} min={-12} max={12} onChange={n=>updateRoof('proposal',{x:n})}/><NumberField label="North / south" value={draft.proposal.y} min={-8} max={8} onChange={n=>updateRoof('proposal',{y:n})}/><label className="studio-check"><input type="checkbox" checked={showRays} onChange={e=>setShowRays(e.target.checked)}/> Show shadow direction</label><label className="studio-check"><input type="checkbox" checked={showMeasurements} onChange={e=>setShowMeasurements(e.target.checked)}/> Show site boundaries and scale</label><div className="studio-segment"><button onClick={()=>update('comparisonMode','add')} className={draft.comparisonMode==='add'?'active':''}>Add canopy</button><button onClick={()=>update('comparisonMode','replace')} className={draft.comparisonMode==='replace'?'active':''}>Replace</button></div></div></details>
          {tab==='site'&&<div className="studio-site-settings"><div className="studio-inline-heading"><strong>Site measurements</strong><button onClick={()=>setTab('design')}>Done</button></div><label className="studio-check"><input type="checkbox" checked={draft.mode==='survey'} onChange={e=>update('mode',e.target.checked?'survey':'concept')}/> Mark as user-measured (unverified)</label><FieldBlock title="Waiting area"><NumberField label="Width" value={draft.waiting.width} min={1} max={16} onChange={n=>updateWaiting({width:n})}/><NumberField label="Depth" value={draft.waiting.depth} min={1} max={10} onChange={n=>updateWaiting({depth:n})}/><NumberField label="Direction" value={draft.waiting.rotation} unit="°" min={-180} max={180} onChange={n=>updateWaiting({rotation:n})}/></FieldBlock><label className="studio-check"><input type="checkbox" checked={draft.includeExisting} onChange={e=>update('includeExisting',e.target.checked)}/> Existing shelter present</label>{draft.includeExisting&&<FieldBlock title="Existing shelter"><NumberField label="Width" value={draft.existing.width} min={.5} max={15} onChange={n=>updateRoof('existing',{width:n})}/><NumberField label="Depth" value={draft.existing.depth} min={.5} max={12} onChange={n=>updateRoof('existing',{depth:n})}/><NumberField label="Height" value={draft.existing.height} min={.3} max={15} onChange={n=>updateRoof('existing',{height:n})}/></FieldBlock>}<label className="studio-check"><input type="checkbox" checked={building.enabled} onChange={e=>updateBuilding({enabled:e.target.checked})}/> Include rectangular neighboring building</label>{building.enabled&&<FieldBlock title="Building"><NumberField label="Width" value={building.width} min={.5} max={12} onChange={n=>updateBuilding({width:n})}/><NumberField label="Depth" value={building.depth} min={.5} max={12} onChange={n=>updateBuilding({depth:n})}/><NumberField label="Height" value={building.height} min={.3} max={50} onChange={n=>updateBuilding({height:n})}/></FieldBlock>}<FieldBlock title="Permitted area"><NumberField label="Width" value={draft.constraints.allowed.width} min={5} max={25} onChange={n=>updateConstraint('allowed',{width:n})}/><NumberField label="Depth" value={draft.constraints.allowed.depth} min={4} max={18} onChange={n=>updateConstraint('allowed',{depth:n})}/></FieldBlock><label className="studio-check"><input type="checkbox" checked={draft.constraints.noBuild.enabled} onChange={e=>updateConstraint('noBuild',{enabled:e.target.checked})}/> Add no-build zone</label>{draft.constraints.noBuild.enabled&&<FieldBlock title="No-build zone"><NumberField label="Width" value={draft.constraints.noBuild.width} min={.5} max={14} onChange={n=>updateConstraint('noBuild',{width:n})}/><NumberField label="Depth" value={draft.constraints.noBuild.depth} min={.5} max={12} onChange={n=>updateConstraint('noBuild',{depth:n})}/><NumberField label="East / west" value={draft.constraints.noBuild.x} min={-12} max={12} onChange={n=>updateConstraint('noBuild',{x:n})}/><NumberField label="North / south" value={draft.constraints.noBuild.y} min={-8} max={8} onChange={n=>updateConstraint('noBuild',{y:n})}/></FieldBlock>}<FieldBlock title="Simulation hours"><label className="lab-full-field">From (IST)<input type="time" value={draft.from} onChange={e=>update('from',e.target.value)}/></label><label className="lab-full-field">To (IST)<input type="time" value={draft.to} onChange={e=>update('to',e.target.value)}/></label></FieldBlock></div>}
          {planWarnings.length>0&&<div role="status" className="studio-warning"><ShieldAlert size={15}/>{planWarnings[0]}</div>}
          {evaluation.error&&<div role="alert" className="studio-warning">{evaluation.error}</div>}
          <div className="studio-optimize"><div><Sparkles size={19}/><strong>Want a better position?</strong></div><p>Search for more useful shade with the same roof.</p><button className="studio-cta" onClick={beginOptimization} disabled={optimizing||!metrics}>{optimizing?'Checking placements…':'Find best placement'} <ArrowRight size={16}/></button>{optimizing&&<button className="studio-textbutton" onClick={cancelOptimization}>Cancel search</button>}{searchError&&<p role="alert" className="studio-warning">{searchError}</p>}{searchNotice&&<p role="status" className="studio-searchnote">{searchNotice}</p>}{acceptedSearch&&<div role="status" className="studio-search-result"><small>{searchSource==='aws'?'✓ AWS Lambda evaluation':'Browser fallback evaluation'} · {acceptedSearch.evaluatedCandidates} placements tested</small><strong>{acceptedSearch.best?(acceptedSearch.current&&acceptedSearch.current.shadeDebtM2Hours>acceptedSearch.best.shadeDebtM2Hours+.01?'A better position was found.':'Best permissible position identified.'): 'No valid alternative found.'}</strong><span>{acceptedSearch.best?`Move ${acceptedSearch.best.deltaFromCurrentM.toFixed(1)} m · ${Math.max(0,acceptedSearch.current?acceptedSearch.current.shadeDebtM2Hours-acceptedSearch.best.shadeDebtM2Hours:0).toFixed(1)} m²·h less unshaded area-time than the current proposal.`:acceptedSearch.reason}</span>{acceptedSearch.best&&<div className="studio-result-buttons"><button onClick={()=>setPreviewPlacement(v=>!v)}>{previewPlacement?'Hide preview':'Preview position'}</button><button className="studio-apply" disabled={acceptedSearch.best.deltaFromCurrentM<.001} onClick={applyBest}>Apply placement</button></div>}<p>Tested within the supplied construction constraints; not construction approval.</p></div>}</div>
          {notice&&<p className="studio-searchnote" role="status">{notice}</p>}
        </div>
      </aside>
    </div>
    <section className="studio-outcome" aria-label="Your shade comparison">
      <div className="studio-outcome-header"><div><span className="studio-section-step">03 · THE DIFFERENCE</span><h2>Is the waiting area better shaded?</h2></div><button className="studio-report-link" onClick={printReport} disabled={!metrics}><Printer size={17}/> Get assessment</button></div>
      {metrics?<><div className="studio-outcome-content"><div className="studio-comparison"><div className="studio-bars"><div><span>Current shelter</span><strong>{baselinePct}%</strong><div className="studio-bar-track"><i style={{width:`${baselinePct}%`}} className="studio-before-bar"/></div></div><div><span>With your design</span><strong>{proposedPct}%</strong><div className="studio-bar-track"><i style={{width:`${proposedPct}%`}} className="studio-after-bar"/></div></div></div><div className="studio-verdict"><span className={changePoints>0.1?'positive':changePoints<-.1?'negative':'neutral'}>{changePoints>0.1?'+':''}{changePoints.toFixed(1)} <small>percentage points</small></span><h3>{verdict}</h3><p>Average proportion of the waiting area under modeled direct shade between {draft.from} and {draft.to} IST today.</p></div></div></div><details className="studio-technical"><summary>How the shade changes through the day · technical details</summary><div className="studio-chartbox"><div className="studio-chart-head"><span>How coverage changes through the afternoon</span><small>Current <i className="studio-line-neutral"/> · With design <i className="studio-line-green"/></small></div><svg viewBox="0 0 512 112" role="img" aria-label="Time-series comparison of modeled direct-sun shade coverage" className="studio-mini-chart"><path d="M18 16 H492 M18 53 H492 M18 91 H492" stroke="#d6e3da" strokeDasharray="4 7" fill="none"/>{chartSamples.length>1&&<><polyline points={samplePolyline('baselineCoverage')} fill="none" stroke="#8ba19a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/><polyline points={samplePolyline('proposedCoverage')} fill="none" stroke="#238b67" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"/></>}</svg><div className="studio-chart-times"><span>{draft.from}</span><span>{draft.to} IST</span></div></div><p>ShadeDebt (unshaded area-time): existing <strong>{metrics.baselineShadeDebtM2Hours.toFixed(1)}</strong> → design <strong>{metrics.proposedShadeDebtM2Hours.toFixed(1)} m²·h</strong>. Change: {signed(metrics.shadeDebtReductionM2Hours)} m²·h. {metrics.evaluatedHours.toFixed(2)} hours evaluated; {(mainResult!.excludedMinutes/60).toFixed(2)} hours excluded for low or absent sun.</p><p>Calculation: time-weighted intersection of projected shadows and your waiting-area polygon. Today's Delhi date. Flat opaque horizontal roofs, level ground, user-entered or illustrative geometry; not thermal comfort, structural design or a building permit.</p></details></>:<div className="studio-warning">{evaluation.error||'Select a daylight interval to see the comparison.'}</div>}
    </section>
    {reportOpen&&<div className="studio-report-modal" role="dialog" aria-label="Design assessment"><div className="studio-report-paper"><div className="studio-report-actions"><button onClick={()=>setReportOpen(false)}>Close</button><button onClick={()=>window.print()}><Printer size={16}/> Print / Save PDF</button></div><div className="studio-report-title"><span>SHADEDEBT / DESIGN ASSESSMENT</span><h1>Shade that actually reaches people.</h1><p>{draft.name} · {dateLabel(draft.date)} · {draft.from}–{draft.to} IST</p></div><div className="studio-report-result"><strong>{baselinePct}%</strong><span>Current →</span><strong>{proposedPct}%</strong><span>With proposal</span></div><h2>{verdict}</h2><p>Average waiting-zone direct-beam shade coverage changes by {signed(changePoints)} percentage points during the modeled interval.</p><div className="studio-report-specs"><div><b>Waiting area</b><span>{waitingAreaM2.toFixed(1)} m²</span></div><div><b>Proposed canopy</b><span>{draft.proposal.shape} · {footprintArea(draft.proposal).toFixed(1)} m² roof · {draft.proposal.height.toFixed(1)} m height</span></div><div><b>Existing shelter</b><span>{draft.includeExisting?'Included':'None'}</span></div><div><b>Comparison</b><span>{draft.comparisonMode==='add'?'New canopy added':'Existing roof replaced'}</span></div><div><b>ShadeDebt reduction</b><span>{metrics?signed(metrics.shadeDebtReductionM2Hours):'—'} m²·h</span></div><div><b>Model provenance</b><span>Solar geometry · SunCalc v2 · {mainResult?.modelVersion??'phase1-geometry-1'}</span></div><div><b>Coordinates</b><span>{draft.latitude.toFixed(5)}°N, {draft.longitude.toFixed(5)}°E</span></div><div><b>Data quality</b><span>{draft.mode==='concept'?'Illustrative dimensions':'User-supplied dimensions (unverified)'}</span></div></div><div className="studio-report-caveat"><strong>Limitations</strong><p>Concept-level direct-beam geometric shade, not measured temperatures or thermal comfort. The model assumes flat opaque horizontal roofs and level ground. This report is not structural approval, permitting advice or a substitute for an on-site engineering survey.</p></div><footer>ShadeDebt · Infrastructure design exploration · Generated from the current simulation</footer></div></div>}
  </div>;
}
