import {ArrowUpRight,ArrowRight,Sun,MapPin,MoveUpRight} from 'lucide-react';
export default function Welcome({enter}:{enter:()=>void}){
 return <main className="welcome">
  <div className="welcome-noise"/>
  <section className="welcome-hero">
    <div className="welcome-copy">
      <span className="welcome-kicker"><span className="welcome-dot"/> A NEW WAY TO DESIGN PUBLIC SHADE</span>
      <h1>Shade is not<br/>a <em>structure.</em><br/>It's a <span className="welcome-outlined">result.</span></h1>
      <p>A shelter can exist and still leave people in the sun. Explore a real Delhi location, draw a better canopy, and see where the shade actually falls.</p>
      <button className="welcome-cta" onClick={enter}>Open the Shade Lab <ArrowUpRight size={21}/></button>
      <div className="welcome-provenance">SOLAR GEOMETRY&nbsp; / &nbsp;12-MONTH DESIGN STUDY&nbsp; / &nbsp;BUILT ON AWS</div>
    </div>
    <div className="welcome-art" aria-label="Architectural illustration of a bus shelter and projected sunlight">
     <svg viewBox="0 0 720 640" role="img" aria-label="A three-dimensional architectural illustration shows sunlight passing past a shelter and casting a displaced canopy shadow">
      <defs><linearGradient id="heroGround" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#f0efe8"/><stop offset="1" stopColor="#dfe6d7"/></linearGradient><linearGradient id="heroRoof" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#749686"/><stop offset="1" stopColor="#315d4c"/></linearGradient><linearGradient id="heroLight" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#f9d17c" stopOpacity=".45"/><stop offset="1" stopColor="#f9d17c" stopOpacity="0"/></linearGradient><filter id="heroBlur"><feGaussianBlur stdDeviation="14"/></filter></defs>
      <circle cx="545" cy="120" r="85" fill="#ffda8d" opacity=".4" filter="url(#heroBlur)"/><circle cx="545" cy="120" r="35" fill="#f9c66f" className="welcome-sun"/>
      <path d="M485 153L205 441L422 520L612 219Z" fill="url(#heroLight)"/>
      <polygon points="66,408 427,314 690,428 330,578" fill="url(#heroGround)" stroke="#d9dfd4" strokeWidth="1.5"/>
      <path d="M123 438L454 360 M147 469L477 394 M170 500L502 427" stroke="#ced8cb" strokeWidth="1" strokeDasharray="4 8"/>
      <polygon points="266,425 409,391 546,469 398,510" fill="#4e8473" opacity=".23" className="welcome-shadow"/>
      <g stroke="#b98635" strokeDasharray="5 8" strokeWidth="2" opacity=".8"><path d="M545 120L300 434"/><path d="M545 120L540 466"/></g>
      <polygon points="178,300 353,255 467,311 287,359" fill="url(#heroRoof)" stroke="#1f4b3c" strokeWidth="2"/>
      <polygon points="178,300 287,359 287,369 178,311" fill="#355d4d"/><polygon points="287,359 467,311 467,320 287,369" fill="#183e32"/>
      <g stroke="#325747" strokeWidth="8" strokeLinecap="round"><path d="M202 315V444"/><path d="M436 325V427"/><path d="M294 368V487"/></g>
      <polygon points="177,441 299,410 425,467 296,501" fill="#ffffff" opacity=".25"/>
      <g fill="#1f4238"><circle cx="321" cy="404" r="8"/><path d="M313 414L307 454L327 458L330 415Z"/><circle cx="360" cy="411" r="7"/><path d="M355 420L348 461L367 464L368 422Z"/></g>
      <g fontFamily="sans-serif" fontSize="12" letterSpacing="2" fill="#507264"><text x="77" y="340">EXISTING SHELTER</text><path d="M188 340L247 329" stroke="#6e9883" fill="none"/><text x="465" y="550">WHERE SHADE LANDS</text><path d="M460 524L414 488" stroke="#6e9883" fill="none"/></g>
     </svg>
     <div className="welcome-art-caption"><Sun size={17}/> The sun moves. Your design should work with it.</div>
    </div>
  </section>
  <section className="welcome-principle">
   <div><span>01 / LOCATE</span><strong><MapPin size={19}/> Choose a real place</strong></div>
   <div><span>02 / DESIGN</span><strong><MoveUpRight size={19}/> Draw your intervention</strong></div>
   <div><span>03 / UNDERSTAND</span><strong><Sun size={19}/> Evaluate the next 12 months</strong></div>
   <button onClick={enter}>Try the simulation <ArrowRight size={18}/></button>
  </section>
 </main>;
}
