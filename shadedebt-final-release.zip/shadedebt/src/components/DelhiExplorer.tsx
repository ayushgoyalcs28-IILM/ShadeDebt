import { useDeferredValue, useEffect, useMemo, useState } from 'react';
import { ArrowUpRight, Compass, Database, Info, MapPin, Search, UploadCloud } from 'lucide-react';
import type { TransitStop } from '../types/domain';
import { parseStopCatalogue,searchStops } from '../data/catalogue';
import { loadLocalCatalogue } from '../data/localCatalogue';
import { fromCustom,fromStop,type SelectedSite } from '../data/siteIdentity';
import DelhiMap from './DelhiMap';

interface Props { activeSite:SelectedSite; onOpen:(site:SelectedSite)=>void; }
const locationText=(s:TransitStop)=>`${s.latitude.toFixed(5)}° N · ${s.longitude.toFixed(5)}° E`;
export default function DelhiExplorer({activeSite,onOpen}:Props){
  const [catalogue,setCatalogue]=useState<TransitStop[]>([]);
  const [source,setSource]=useState<'loading'|'local'|'imported'|'empty'>('loading');
  const [dataError,setDataError]=useState('');
  const [dataNote,setDataNote]=useState('');
  const [mapIssue,setMapIssue]=useState(false);
  const [query,setQuery]=useState('');
  const deferredQuery=useDeferredValue(query);
  const [highlighted,setHighlighted]=useState<TransitStop|null>(null);
  const [custom,setCustom]=useState({name:activeSite.kind==='custom'?activeSite.name:'Custom site',lat:String(activeSite.latitude),lon:String(activeSite.longitude)});
  const [customOpen,setCustomOpen]=useState(false);
  useEffect(()=>{
    let active=true;
    void loadLocalCatalogue().then(items=>{
      if(!active)return;
      setCatalogue(items);setSource(items.length?'local':'empty');
    });
    return()=>{active=false;};
  },[]);
  useEffect(()=>{
    if(activeSite.kind!=='stop')return;
    const previous=catalogue.find(s=>fromStop(s).key===activeSite.key);
    if(previous)setHighlighted(previous);
  },[activeSite.key,activeSite.kind,catalogue]);
  const matches=useMemo(()=>searchStops(catalogue,deferredQuery),[catalogue,deferredQuery]);
  const selectedLocation=highlighted?fromStop(highlighted):null;
  const selectStop=(stop:TransitStop)=>{setHighlighted(stop);setDataError('');};
  const loadUserFile=async(file:File)=>{
    if(file.size>6_000_000){setDataError('File exceeds 6 MB. Import a processed stops.json catalogue.');return;}
    try{
      const parsed=parseStopCatalogue(JSON.parse(await file.text()) as unknown);
      setCatalogue(parsed.stops);setSource('imported');setHighlighted(null);setQuery('');setDataError('');
      setDataNote(`${parsed.stops.length.toLocaleString()} geographic locations loaded. ${parsed.rejected} invalid and ${parsed.duplicates} duplicate records skipped.`);
    }catch(err){setDataError(err instanceof Error?err.message:'Could not load the file.');}
  };
  const validCustom=custom.lat.trim()!==''&&custom.lon.trim()!==''&&Number.isFinite(Number(custom.lat))&&Number.isFinite(Number(custom.lon))&&Math.abs(Number(custom.lat))<=90&&Math.abs(Number(custom.lon))<=180;
  return <section className="explorer-v4" aria-label="Delhi transit site explorer">
    <div className="explorer-head"><div><span className="eyebrow">04 / LOCATION INTELLIGENCE</span><h1>Choose a real location.<br/><em>Design the shade.</em></h1><p>Find a Delhi transit stop, then supply the shelter's physical dimensions in the Shade Laboratory. Locations are not verified shelter surveys.</p></div><span className="explorer-status"><Database size={15}/>{source==='local'?'GEOGRAPHICAL CATALOGUE':source==='imported'?'USER-LOADED CATALOGUE':source==='loading'?'LOADING SOURCE':'NO CATALOGUE LOADED'}</span></div>
    <div className="explorer-workspace">
      <aside className="explorer-list">
        <div className="explorer-search-block"><label htmlFor="delhi-stop-search"><Search size={15}/> Find a bus stop</label><input id="delhi-stop-search" type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search stop names · 2+ letters" disabled={catalogue.length===0}/>
          <p>{source==='loading'?'Loading local source…':catalogue.length?`${catalogue.length.toLocaleString()} geographic locations · historical or user-provided`:'No licensed catalogue was published. You can import one or use custom coordinates.'}</p>
        </div>
        {catalogue.length===0?<div className="explorer-empty"><Database size={25}/><strong>Bring your stop catalogue</strong><p>Use the processed JSON file for local testing or import a catalogue you are entitled to use. A custom coordinate works without any dataset.</p></div>:<div className="explorer-result-list" aria-label="Stop search results">
          {deferredQuery.trim().length<2?<div className="explorer-hint">Search for a stop by name, or explore markers on the map. Nearby stops with the same name remain separate locations.</div>:matches.length===0?<div className="explorer-hint">No matching stops. Try another spelling.</div>:matches.map(stop=><button key={`${stop.source}:${stop.id}`} type="button" className={`explorer-stop ${highlighted?.id===stop.id&&highlighted.source===stop.source?'selected':''}`} onClick={()=>selectStop(stop)}><span><strong>{stop.name}</strong><small>{locationText(stop)}</small></span><MapPin size={17}/></button>)}
        </div>}
        <div className="explorer-bottom">
          <label className="explorer-import"><UploadCloud size={16}/> Import stops JSON<input type="file" accept=".json,application/json" onChange={e=>{const file=e.target.files?.[0];if(file)void loadUserFile(file);e.target.value='';}}/></label>
          {dataError&&<p className="explorer-alert" role="alert">{dataError}</p>}{dataNote&&<p className="explorer-data-note" role="status">{dataNote}</p>}
          <button className="explorer-custom-toggle" type="button" onClick={()=>setCustomOpen(x=>!x)} aria-expanded={customOpen}><Compass size={16}/> Use custom coordinates <span>{customOpen?'−':'+'}</span></button>
          {customOpen&&<div className="explorer-custom-panel"><label>Name<input value={custom.name} maxLength={160} onChange={e=>setCustom(s=>({...s,name:e.target.value}))}/></label><div className="explorer-coordinate-pair"><label>Latitude<input type="number" min={-90} max={90} step="any" value={custom.lat} onChange={e=>setCustom(s=>({...s,lat:e.target.value}))}/></label><label>Longitude<input type="number" min={-180} max={180} step="any" value={custom.lon} onChange={e=>setCustom(s=>({...s,lon:e.target.value}))}/></label></div><button type="button" className="explorer-open" disabled={!validCustom} onClick={()=>onOpen(fromCustom(custom.name,Number(custom.lat),Number(custom.lon)))}>Open custom site <ArrowUpRight size={16}/></button></div>}
        </div>
      </aside>
      <div className="explorer-map-area"><div className="explorer-map-toolbar"><span><MapPin size={15}/> DELHI · NCR</span><span>Scroll to search · Zoom with +/−</span></div><DelhiMap stops={catalogue} selected={highlighted} onSelect={selectStop} onClusterSelect={entries=>setQuery(entries[0].name)} onTileIssue={setMapIssue}/>
        {mapIssue&&<div className="explorer-map-warning" role="status">Map tiles unavailable. Stop selection still works through the search list.</div>}
        <div className="explorer-map-note"><Info size={13}/> © OpenStreetMap contributors (where OSM data is loaded) · ODbL. Locations are unverified; selecting one does not reconstruct a shelter.</div>
      </div>
    </div>
    <div className="explorer-selection">
      <div><span className="eyebrow">SELECTED SITE</span><h2>{highlighted?highlighted.name:activeSite.name}</h2><p>{highlighted?locationText(highlighted):`${activeSite.latitude.toFixed(5)}, ${activeSite.longitude.toFixed(5)}`} · {highlighted?'Source stop record; geometry not surveyed':activeSite.kind==='custom'?'Manual location':'Previously selected stop'}</p></div>
      <button className="primary" type="button" onClick={()=>onOpen(selectedLocation??activeSite)}>Open in Shade Laboratory <ArrowUpRight size={16}/></button>
    </div>
  </section>;
}
