import { useEffect, useRef } from 'react';
import * as L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { TransitStop } from '../types/domain';
import { groupStopsInViewport } from '../data/viewport';

interface Props {
  stops:readonly TransitStop[];
  selected:TransitStop|null;
  onSelect:(stop:TransitStop)=>void;
  onClusterSelect?:(stops:TransitStop[])=>void;
  onTileIssue?:(issue:boolean)=>void;
}

/** Marker aggregation is performed in screen pixels for the current viewport.
 * This bounds Leaflet object count even with thousands of local records,
 * without introducing a marker clustering service or losing exact stop IDs. */

export default function DelhiMap({stops,selected,onSelect,onClusterSelect,onTileIssue}:Props){
  const host=useRef<HTMLDivElement|null>(null);
  const mapRef=useRef<L.Map|null>(null);
  const overlayRef=useRef<L.LayerGroup|null>(null);
  const stopsRef=useRef(stops);
  const selectedRef=useRef(selected);
  const selectRef=useRef(onSelect);
  const clusterRef=useRef(onClusterSelect);
  const issueRef=useRef(onTileIssue);
  stopsRef.current=stops; selectedRef.current=selected;
  selectRef.current=onSelect;clusterRef.current=onClusterSelect;issueRef.current=onTileIssue;

  useEffect(()=>{
    const node=host.current;
    if(!node)return;
    const map=L.map(node,{center:[28.6139,77.209],zoom:11,zoomControl:false,preferCanvas:true,scrollWheelZoom:false});
    mapRef.current=map;
    L.control.zoom({position:'bottomright'}).addTo(map);
    const tiles=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{
      maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
    });
    let tileFailures=0;
    tiles.on('tileerror',()=>{tileFailures++;if(tileFailures>=3)issueRef.current?.(true);});
    tiles.on('tileload',()=>{if(tileFailures){tileFailures=0;issueRef.current?.(false);}});
    tiles.addTo(map);
    const layer=L.layerGroup().addTo(map);overlayRef.current=layer;
    const draw=()=>{
      layer.clearLayers();
      const bounds=map.getBounds().pad(.15);
      const cellSize=map.getZoom()<13?60:map.getZoom()<15?48:32;
      const clusters=groupStopsInViewport(stopsRef.current,(lat,lon)=>bounds.contains([lat,lon]),(lat,lon)=>{const p=map.latLngToContainerPoint([lat,lon]);return [p.x,p.y];},cellSize);
      const active=selectedRef.current;
      for(const group of clusters){
        const entries=group.members;
        if(entries.length>1){
          const selectedInside=active!==null&&entries.some(s=>s.id===active.id&&s.source===active.source);
          const icon=L.divIcon({className:`sd-map-cluster ${selectedInside?'is-selected':''}`,
            html:`<span>${entries.length}</span>`,iconSize:[36,36],iconAnchor:[18,18]});
          const pin=L.marker([group.latitude,group.longitude],{icon,keyboard:true}).addTo(layer);
          pin.on('click',()=>{
            if(map.getZoom()<17){map.flyTo([group.latitude,group.longitude],Math.min(18,map.getZoom()+2),{duration:.4});}
            else {
              // Coincident records cannot be reliably chosen through a single pin.
              // Open a matching search list instead of picking an arbitrary stop.
              clusterRef.current?.(entries);
            }
          });
          pin.bindTooltip(`${entries.length} nearby stop records`,{direction:'top'});
        }else{
          const stop=entries[0];
          const chosen=active?.id===stop.id&&active.source===stop.source;
          const circle=L.circleMarker([group.latitude,group.longitude],{radius:chosen?10:6,color:chosen?'#f6e5b6':'#d9fcf0',weight:chosen?3:1,
            fillColor:chosen?'#edc06f':'#67cba9',fillOpacity:chosen?1:.9}).addTo(layer);
          circle.on('click',()=>selectRef.current(stop));
          const tooltip=document.createElement('span');tooltip.textContent=stop.name;
          circle.bindTooltip(tooltip,{direction:'top'});
        }
      }
      // Always show the selected stop even when it is co-located in a cluster.
      if(active && map.getBounds().pad(.15).contains([active.latitude,active.longitude])){
        L.circleMarker([active.latitude,active.longitude],{radius:12,color:'#f6d68a',weight:2,fillOpacity:0,interactive:false}).addTo(layer);
      }
    };
    map.on('moveend zoomend resize',draw);
    draw();
    // Leaflet needs a size pass when mounted inside a conditional app view.
    const raf=requestAnimationFrame(()=>map.invalidateSize());
    return()=>{cancelAnimationFrame(raf);map.off('moveend zoomend resize',draw);layer.clearLayers();map.remove();mapRef.current=null;overlayRef.current=null;};
  },[]);

  useEffect(()=>{const map=mapRef.current;if(!map)return;
    if(selected){map.flyTo([selected.latitude,selected.longitude],Math.max(15,map.getZoom()),{duration:.4});}
    else if(overlayRef.current){map.fire('moveend');}
  },[selected]);
  useEffect(()=>{mapRef.current?.fire('moveend');},[stops]);
  return <div ref={host} className="delhi-map" role="region" aria-label="Geographical bus-stop map. Select markers or choose a stop from the searchable list."/>;
}
