import {useEffect,useMemo,useRef,useState} from 'react';
import {ArrowRight,ArrowUpRight,Check,ChevronDown,FileText,MapPin,Pause,Play,Plus,RotateCcw,Search,Sun, X} from 'lucide-react';
import type {Polygon,Vec2} from '../types/domain';
import {sampleDraft,outline,toScenario,moveCustomVertex,type SiteDraft} from '../engine/editor';
import {simulateScenario,evaluateSunPosition} from '../engine/simulation';
import {sunPosition,istInstant} from '../engine/solar';
import {canopyShadow,usableSun} from '../engine/shadows';
import {polygonArea} from '../engine/geometry';
import {todayInDelhi} from '../engine/date';
import {lookupRoadAxis,rotateLocal} from '../data/roadAxis';
import {draftStorageKey,fromStop,type SelectedSite} from '../data/siteIdentity';
import {loadLocalCatalogue} from '../data/localCatalogue';
import {parseStopCatalogue,searchStops} from '../data/catalogue';
import type {TransitStop} from '../types/domain';
import {type YearlyResult} from '../engine/yearly';
import {optimizeYearCloud} from '../cloud/yearly';
import {validatePlacement} from '../engine/optimizer';
import {LAB_VIEW,projectSitePoint as iso,screenToSite as fromIso} from '../engine/projection';

interface Props{site:SelectedSite;chooseSite:(s:SelectedSite)=>void}
type AxisInfo={status:'loading'|'osm'|'missing';bearing:number|null;distance?:number};
function dateLabel(v:string){return new Intl.DateTimeFormat('en-IN',{month:'short',day:'numeric',year:'numeric',timeZone:'UTC'}).format(new Date(`${v}T00:00:00Z`));}
function defaultStudio(site:SelectedSite):SiteDraft{
 const d=sampleDraft(site.latitude,site.longitude,site.name);
 d.proposal={...d.proposal,shape:'custom',vertices:[[-1.65,-1.15],[1.65,-1.15],[1.65,1.15],[-1.65,1.15]],x:.65,y:.5,height:3};
 d.comparisonMode='replace';d.building.enabled=false;d.constraints.noBuild.enabled=false;d.from='12:00';d.to='17:00';return d;
}
function restore(site:SelectedSite):SiteDraft{
 const fallback=defaultStudio(site);
 try{
  const raw=localStorage.getItem(draftStorageKey(site.key));if(!raw)return fallback;
  const d=JSON.parse(raw) as SiteDraft & {axisSource?:string;axisBearing?:number};
  if(d.latitude!==site.latitude||d.longitude!==site.longitude)return fallback;
  if(d.proposal.shape!=='custom'){
   const full=outline(d.proposal),angle=-d.proposal.rotation*Math.PI/180,c=Math.cos(angle),s=Math.sin(angle);
   d.proposal={...d.proposal,shape:'custom',vertices:full.map(([x,y])=>[(x-d.proposal.x)*c-(y-d.proposal.y)*s,(x-d.proposal.x)*s+(y-d.proposal.y)*c])};
  }
  d.date=todayInDelhi();d.from='12:00';d.to='17:00';d.comparisonMode='replace';d.building.enabled=false;d.constraints.noBuild.enabled=false;
  toScenario(d);return d;
 }catch{return fallback;}
}
const STAGE={w:LAB_VIEW.width,h:LAB_VIEW.height};
function points(poly:Polygon,z=0){return poly.map(p=>iso(p,z).map(n=>n.toFixed(2)).join(',')).join(' ');}
function polyPath(poly:Polygon,z=0){return poly.map((p,i)=>`${i?'L':'M'}${iso(p,z).join(' ')}`).join(' ')+'Z';}
const formatPercent=(x:number)=>`${Math.round(x*100)}%`;
const minutesLabel=(m:number)=>`${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
function NumberEntry({label,value,min=.5,max=15,step=.1,onChange}:{label:string;value:number;min?:number;max?:number;step?:number;onChange:(v:number)=>void}){
 return <label className="fin-field"><span>{label}</span><div><input type="number" aria-label={label} min={min} max={max} step={step} value={Number(value.toFixed(2))} onChange={e=>{const n=Number(e.target.value);if(e.target.value!==''&&Number.isFinite(n)&&n>=min&&n<=max)onChange(n);}}/><small>m</small></div></label>;
}
export default function ShadeStudio({site,chooseSite}:Props){
 const [draft,setDraft]=useState<SiteDraft>(()=>restore(site));
 const [axis,setAxis]=useState<AxisInfo>(()=>site.kind==='stop'?{status:'loading',bearing:null}:{status:'missing',bearing:null});
 const [catalogue,setCatalogue]=useState<TransitStop[]>([]);
 const [query,setQuery]=useState('');const [showSearch,setShowSearch]=useState(false);
 const [time,setTime]=useState(16*60);const [playing,setPlaying]=useState(false);
 const [view,setView]=useState<'before'|'after'>('after');

 const [drawing,setDrawing]=useState(false);const [drawn,setDrawn]=useState<Vec2[]>([]);
 const [report,setReport]=useState(false);
 const [yearly,setYearly]=useState<YearlyResult|null>(null);
 const [loading,setLoading]=useState(false);const [annualSource,setAnnualSource]=useState<'aws'|'browser'|null>(null);
 const [message,setMessage]=useState('');const [preview,setPreview]=useState(false);
 const svgRef=useRef<SVGSVGElement|null>(null);
 const drag=useRef<{kind:'roof'|'vertex';index?:number;start:Vec2;initial:SiteDraft}|null>(null);
 const controller=useRef<AbortController|null>(null);const worker=useRef<Worker|null>(null);const searchNumber=useRef(0);
 const draftRef=useRef(draft);draftRef.current=draft;
 const invalidationKey=JSON.stringify(draft);
 useEffect(()=>{
  let cancelled=false;void loadLocalCatalogue().then(list=>{if(!cancelled)setCatalogue(list);});return()=>{cancelled=true;};
 },[]);
 useEffect(()=>{
  if(site.kind!=='stop')return;
  const previous=draft as SiteDraft&{axisSource?:string;axisBearing?:number};
  if(previous.axisSource==='osm'&&Number.isFinite(previous.axisBearing)){setAxis({status:'osm',bearing:previous.axisBearing!});return;}
  const aborter=new AbortController();
  void lookupRoadAxis(site.latitude,site.longitude,aborter.signal).then(found=>{
   if(aborter.signal.aborted)return;
   if(!found){setAxis({status:'missing',bearing:null});return;}
   setAxis({status:'osm',bearing:found.bearingDeg,distance:found.distanceM});
   setDraft(d=>{
    const rotation=90-found.bearingDeg,delta=rotation-d.waiting.rotation;
    const existing=rotateLocal(d.existing.x-d.waiting.x,d.existing.y-d.waiting.y,delta);
    const proposal=rotateLocal(d.proposal.x-d.waiting.x,d.proposal.y-d.waiting.y,delta);
    const road=rotateLocal(d.constraints.road.x-d.waiting.x,d.constraints.road.y-d.waiting.y,delta);
    return {...d,waiting:{...d.waiting,rotation},existing:{...d.existing,rotation:d.existing.rotation+delta,x:existing[0]+d.waiting.x,y:existing[1]+d.waiting.y},proposal:{...d.proposal,rotation:d.proposal.rotation+delta,x:proposal[0]+d.waiting.x,y:proposal[1]+d.waiting.y},constraints:{...d.constraints,allowed:{...d.constraints.allowed,rotation},road:{...d.constraints.road,rotation,x:road[0]+d.waiting.x,y:road[1]+d.waiting.y}},axisSource:'osm',axisBearing:found.bearingDeg} as SiteDraft;
   });
  });
  return()=>aborter.abort();
 // mount is keyed to site; do not refetch after arbitrary edits.
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[site.key]);
 useEffect(()=>{
  const id=setTimeout(()=>{try{localStorage.setItem(draftStorageKey(site.key),JSON.stringify(draft));}catch{/* optional */}},220);
  return()=>clearTimeout(id);
 },[draft,site.key]);
 useEffect(()=>()=>{try{localStorage.setItem(draftStorageKey(site.key),JSON.stringify(draftRef.current));}catch{/* optional */}},[site.key]);
 useEffect(()=>{
  const update=()=>{const today=todayInDelhi();setDraft(d=>d.date===today?d:{...d,date:today});};
  const onVis=()=>{if(!document.hidden)update();};window.addEventListener('focus',update);document.addEventListener('visibilitychange',onVis);
  const timer=setInterval(update,60000);return()=>{clearInterval(timer);window.removeEventListener('focus',update);document.removeEventListener('visibilitychange',onVis);};
 },[]);
 useEffect(()=>{if(!playing)return;const timer=setInterval(()=>setTime(t=>t>=1020?720:t+5),130);return()=>clearInterval(timer);},[playing]);
 useEffect(()=>{
  controller.current?.abort();worker.current?.terminate();worker.current=null;searchNumber.current++;
  setYearly(null);setPreview(false);setLoading(false);setMessage('');
 },[invalidationKey]);
 useEffect(()=>()=>{controller.current?.abort();worker.current?.terminate();},[]);
 const scenario=useMemo(()=>{try{return toScenario(draft);}catch{return null;}},[draft]);
 const result=useMemo(()=>{try{return scenario?simulateScenario(scenario):null;}catch{return null;}},[scenario]);
 const current=useMemo(()=>{
  try{
   if(!scenario)return null;
   const sun=sunPosition(istInstant(draft.date,time),draft.latitude,draft.longitude);
   return {sun,evaluation:usableSun(sun)?evaluateSunPosition(scenario.site,scenario.proposedCanopies,'replace',sun):null};
  }catch{return null;}
 },[scenario,draft.date,draft.latitude,draft.longitude,time]);
 const metrics=result?.metrics;
 const before=metrics?.averageBaselineCoverage??0,after=metrics?.averageProposedCoverage??0;
 const gain=Math.round((after-before)*100);
 const shade=current?.evaluation;
 const currentCoverage=shade?(view==='before'?shade.baseline.coverage:shade.proposed.coverage):0;
 const selectedRoof=view==='before'&&draft.includeExisting?draft.existing:draft.proposal;
 const selectedPoly=view==='before'&&draft.includeExisting?outline(draft.existing):scenario?.proposedCanopies[0].footprint;
 const sunDisc=useMemo(()=>{
  if(!current?.sun)return [815,86] as const;
  const az=current.sun.azimuthDeg*Math.PI/180,al=current.sun.altitudeDeg*Math.PI/180;
  return [470+Math.sin(az)*290+Math.cos(az)*70,118+Math.sin(az)*30-Math.cos(az)*55-Math.sin(al)*35] as const;
 },[current?.sun]);
 const projectedShadow=current?.sun&&usableSun(current.sun)&&selectedPoly?canopyShadow({id:'scene-roof',shape:selectedRoof.shape,footprint:selectedPoly,heightM:selectedRoof.height,opaque:true},current.sun):null;
 const shadows=view==='before'?shade?.baselineShadows:shade?.proposedShadows;
 const waiting=scenario?.site.waitingArea;
 const sourceShaded=view==='before'?shade?.baseline.shadedWithinWaiting:shade?.proposed.shadedWithinWaiting;
 const worldPoint=(evt:React.PointerEvent<SVGElement>,height=0):Vec2|null=>{
  const svg=svgRef.current;const ctm=svg?.getScreenCTM();if(!ctm)return null;
  const p=new DOMPoint(evt.clientX,evt.clientY).matrixTransform(ctm.inverse());return fromIso([p.x,p.y],height);
 };
 const startDrag=(evt:React.PointerEvent<SVGElement>,kind:'roof'|'vertex',index?:number)=>{
  if(view==='before'||drawing)return;const p=worldPoint(evt,draft.proposal.height);if(!p)return;
  evt.stopPropagation();evt.preventDefault();drag.current={kind,index,start:p,initial:structuredClone(draft)};
  (evt.currentTarget as SVGElement).setPointerCapture(evt.pointerId);
 };
 const moveDrag=(evt:React.PointerEvent<SVGSVGElement>)=>{
  const d=drag.current;if(!d)return;const p=worldPoint(evt,d.initial.proposal.height);if(!p)return;
  if(d.kind==='roof'){
   setDraft(old=>({...old,proposal:{...old.proposal,x:Math.round((d.initial.proposal.x+p[0]-d.start[0])*100)/100,y:Math.round((d.initial.proposal.y+p[1]-d.start[1])*100)/100}}));
  }else if(d.index!==undefined){
   const base=d.initial.proposal,dx=p[0]-base.x,dy=p[1]-base.y;
   const a=-base.rotation*Math.PI/180;
   const local:[number,number]=[dx*Math.cos(a)-dy*Math.sin(a),dx*Math.sin(a)+dy*Math.cos(a)];
   try{const next=moveCustomVertex(base,d.index!,local);setDraft(old=>({...old,proposal:next}));}catch{/* crossing corner: preserve valid site */}
  }
 };
 const drawClick=(evt:React.MouseEvent<SVGSVGElement>)=>{
  if(!drawing)return;
  const svg=svgRef.current,ctm=svg?.getScreenCTM();if(!ctm)return;
  const p=new DOMPoint(evt.clientX,evt.clientY).matrixTransform(ctm.inverse());
  const world=fromIso([p.x,p.y],draft.proposal.height);
  const dx=world[0]-draft.proposal.x,dy=world[1]-draft.proposal.y,a=-draft.proposal.rotation*Math.PI/180;
  const local:[number,number]=[Number((dx*Math.cos(a)-dy*Math.sin(a)).toFixed(2)),Number((dx*Math.sin(a)+dy*Math.cos(a)).toFixed(2))];
  if(drawn.length<8)setDrawn(d=>[...d,local]);
 };
 const finishDrawing=()=>{
  try{
   if(drawn.length<3)throw new Error('Draw at least three corners.');
   const next={...draft,proposal:{...draft.proposal,vertices:drawn}};
   toScenario(next);setDraft(next);setDrawing(false);setDrawn([]);setMessage('New custom canopy ready. Drag its corners to refine the shape.');
  }catch(e){setMessage(e instanceof Error?e.message:'Invalid shape');}
 };
 const updateExisting=(key:'width'|'depth'|'height',value:number)=>setDraft(d=>({...d,existing:{...d.existing,[key]:value},mode:'survey'}));
 const updateWaiting=(key:'width'|'depth',value:number)=>setDraft(d=>({...d,waiting:{...d.waiting,[key]:value},mode:'survey'}));
 const resetShape=()=>setDraft(d=>({...d,proposal:{...d.proposal,shape:'custom',vertices:[[-1.65,-1.15],[1.65,-1.15],[1.65,1.15],[-1.65,1.15]]}}));
 const runAnnual=()=>{
  if(!scenario)return;setLoading(true);setYearly(null);setPreview(false);setMessage('');const id=++searchNumber.current;
  const anchor:Vec2=[draft.proposal.x,draft.proposal.y];const ctrl=new AbortController();controller.current=ctrl;
  const local=()=>{
   const w=new Worker(new URL('../workers/yearly.worker.ts',import.meta.url),{type:'module'});worker.current=w;
   w.onmessage=(e:MessageEvent<{ok:boolean;result?:YearlyResult;error?:string}>)=>{
    w.terminate();if(searchNumber.current!==id)return;setLoading(false);
    if(e.data.ok&&e.data.result){setYearly(e.data.result);setAnnualSource('browser');setMessage('Computed locally. Redeploy the updated Lambda bundle for AWS annual analysis.');}
    else setMessage(e.data.error||'The sampled annual study could not complete.');
   };
   w.onerror=()=>{w.terminate();if(searchNumber.current===id){setLoading(false);setMessage('The local calculation could not finish.');}};
   w.postMessage({scenario,anchor});
  };
  void optimizeYearCloud(scenario,anchor,ctrl.signal).then(res=>{
   if(searchNumber.current!==id)return;setLoading(false);setYearly(res);setAnnualSource('aws');
  }).catch(()=>{if(searchNumber.current===id&&!ctrl.signal.aborted)local();});
 };
 const applyAnnual=()=>{
  if(!yearly?.best||!scenario)return;
  const [x,y]=yearly.best.anchor,dx=x-draft.proposal.x,dy=y-draft.proposal.y;
  const moved=scenario.proposedCanopies[0].footprint.map(([a,b])=>[a+dx,b+dy] as Vec2);
  if(!validatePlacement(scenario,moved).valid){setMessage('The proposed location is no longer permitted. Run the study again.');return;}
  setDraft(d=>({...d,proposal:{...d.proposal,x,y}}));setMessage('Recommended placement applied. The daily simulation is updated.');setPreview(false);
 };
 const candidates=searchStops(catalogue,query,8);
 const catalogueImport=async(file:File)=>{
  try{if(file.size>8e6)throw new Error('Location file is too large');const data=parseStopCatalogue(JSON.parse(await file.text()));setCatalogue(data.stops);setMessage(`${data.stops.length} locations loaded for this session.`);}
  catch(e){setMessage(e instanceof Error?e.message:'Could not read the stop catalogue');}
 };
 // A deliberately legible, projected physical scene, not a decorative solar map.
 return <main className="fin-studio">
  <section className="fin-top"><div><span className="fin-overline">THE SHADE LAB / DELHI</span><h1>Make your shade <i>count.</i></h1><p>Draw an alternative canopy. Follow the sun. Discover the difference.</p></div><div className="fin-date"><Sun size={18}/><span>{dateLabel(draft.date)}<small>LIVE SOLAR GEOMETRY · 12–5 PM IST</small></span></div></section>
  <div className="fin-searchbar"><MapPin size={19}/><div className="fin-site-copy"><span>YOUR SITE</span><strong>{site.name}</strong></div><button onClick={()=>setShowSearch(x=>!x)}>{showSearch?'Close search':'Change bus stop'} <Search size={17}/></button><span className={`fin-axis-tag ${axis.status}`}>{axis.status==='osm'?`Road aligned · ${axis.bearing?.toFixed(0)}° axis`:axis.status==='loading'?'Finding road alignment…':'Orientation not verified'}</span></div>
  {showSearch&&<div className="fin-search-results"><label><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} autoFocus placeholder="Search a Delhi bus stop" aria-label="Search bus stops"/></label>{candidates.map(s=><button key={`${s.source}:${s.id}`} onClick={()=>{chooseSite(fromStop(s));setShowSearch(false);}}><MapPin size={15}/><span>{s.name}<small>{s.latitude.toFixed(5)}°N · {s.longitude.toFixed(5)}°E</small></span><ArrowUpRight size={15}/></button>)}{catalogue.length===0&&<div className="fin-import">No public stop catalogue is installed. <label>Import your local stop JSON <input type="file" accept=".json,application/json" onChange={e=>{const f=e.target.files?.[0];if(f)void catalogueImport(f);}}/></label></div>}{catalogue.length>0&&query.length>1&&candidates.length===0&&<p>No matching stops. Try a shorter name.</p>}<p className="fin-data-note">Stop coordinates are historic geographic records. Road-axis estimates come from nearby OpenStreetMap road geometry, not surveyed roof measurements. © OpenStreetMap contributors.</p></div>}
  <div className="fin-layout">
   <section className="fin-scene-card">
    <div className="fin-scene-header"><div><span className="fin-overline">01 / SIMULATE</span><h2>Watch the light move.</h2></div><div className="fin-segment"><button className={view==='before'?'on':''} onClick={()=>setView('before')}>Before</button><button className={view==='after'?'on':''} onClick={()=>setView('after')}>After</button></div></div>
    <div className="fin-stage">
     <div className="fin-stage-hud fin-stage-hud-left"><span className="fin-hud-dot"/> {view==='before'?'ORIGINAL SHELTER':'CUSTOM CANOPY'} <small>· {formatPercent(currentCoverage)} shaded now</small></div>
     <div className="fin-stage-hud fin-stage-hud-right"><span className="fin-hud-sun">☀</span> {current?.sun?`${current.sun.altitudeDeg.toFixed(0)}° elevation · ${current.sun.azimuthDeg.toFixed(0)}° bearing`:'Sun geometry unavailable'}</div>
     <svg ref={svgRef} viewBox={`0 0 ${STAGE.w} ${STAGE.h}`} className={`fin-world ${drawing?'drawing':''}`} role="img" aria-label="Perspective architectural view of the bus stop, canopy, calculated sunlight rays and ground shadows" onPointerMove={moveDrag} onPointerUp={()=>drag.current=null} onPointerCancel={()=>drag.current=null} onClick={drawClick}>
      <defs>
       <linearGradient id="finCanvas" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f6f7ef"/><stop offset="1" stopColor="#e7ecdf"/></linearGradient>
       <linearGradient id="finRoof" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#659f8a"/><stop offset="1" stopColor="#286451"/></linearGradient>
       <linearGradient id="finLight" x1="0" y1="0" x2=".8" y2="1"><stop stopColor="#e8b45d" stopOpacity=".34"/><stop offset="1" stopColor="#f5dca8" stopOpacity="0"/></linearGradient>
       <filter id="finSunBlur"><feGaussianBlur stdDeviation="18"/></filter>
      </defs>
      <rect width="960" height="570" fill="url(#finCanvas)"/>
      <circle cx={sunDisc[0]} cy={sunDisc[1]} r="77" fill="#f4dba2" opacity=".34" filter="url(#finSunBlur)"/><circle cx={sunDisc[0]} cy={sunDisc[1]} r="27" fill="#edb85c" className="fin-ambient-sun"/>
      <polygon points="0,410 960,580 960,570 0,570" fill="#c8d0c8" opacity=".45"/>
      {scenario&&<><polygon points={points(scenario.site.exclusionZones[0])} fill="#aebeb6" opacity=".42"/><path d={polyPath(scenario.site.exclusionZones[0])} stroke="#c3cac1" strokeWidth="2" fill="none"/></>}
      {waiting&&<><path d={polyPath(waiting)} fill="#f4d7ab" opacity=".46" stroke="#dbb16f" strokeWidth="2" strokeDasharray="8 8"/><text x="332" y="450" className="fin-ground-label">PASSENGER WAITING AREA</text></>}
      {shadows?.map((shape,i)=><path key={i} d={polyPath(shape)} fill="#376c5e" opacity=".17"/>)}
      {sourceShaded?.map((p,i)=>p.map((r,j)=><path key={`${i}-${j}`} d={polyPath(r as Polygon)} fill="#2e9775" opacity=".29"/>))}
      {selectedPoly&&<>
        {projectedShadow&&current?.sun&&selectedPoly.slice(0,Math.min(5,selectedPoly.length)).map((p,i)=>{
          const [sx,sy]=iso(p,selectedRoof.height);
          const [ex,ey]=iso(projectedShadow[i]);
          return <g key={`beam${i}`}><line x1={sx} y1={sy} x2={ex} y2={ey} stroke="#d4a04d" strokeWidth="1.5" strokeDasharray="6 8" opacity=".72" className="fin-ray"/></g>;
        })}
        {selectedPoly.filter((_,i)=>i===0||i===Math.floor(selectedPoly.length/2)).map((p,i)=>{const [a,b]=iso(p,selectedRoof.height),[x,y]=iso(p);return <path key={`post${i}`} d={`M${a} ${b}L${x} ${y}`} stroke="#426e60" strokeWidth="7" strokeLinecap="round"/>;})}
        <path d={polyPath(selectedPoly,selectedRoof.height)} fill="url(#finRoof)" stroke="#225745" strokeWidth="3" className={view==='after'?'fin-roof-interactive':''} onPointerDown={e=>startDrag(e,'roof')}/>
        {view==='after'&&!drawing&&selectedPoly.map((p,i)=>{const [x,y]=iso(p,selectedRoof.height);return <circle key={i} cx={x} cy={y} r="7" fill="#fffdf2" stroke="#2a8163" strokeWidth="3" className="fin-vertex" onPointerDown={e=>startDrag(e,'vertex',i)}/>})}
      </>}
      {waiting&&[[-2,0],[0,0],[2,0]].map(([x,y],i)=>{const rot=(draft.waiting.rotation*Math.PI/180),wx=x*Math.cos(rot)-y*Math.sin(rot),wy=x*Math.sin(rot)+y*Math.cos(rot),[px,py]=iso([wx,wy]);return <g key={i} opacity=".8"><ellipse cx={px} cy={py+3} rx="9" ry="4" fill="#2b6658" opacity=".12"/><circle cx={px} cy={py-26} r="7" fill="#4b6255"/><path d={`M${px-6} ${py-16}L${px+6} ${py-16}L${px+8} ${py-1}L${px-8} ${py-1}Z`} fill="#567368"/></g>;})}
      {drawing&&drawn.map((p,i)=>{const a=draft.proposal.rotation*Math.PI/180;const world:Vec2=[draft.proposal.x+p[0]*Math.cos(a)-p[1]*Math.sin(a),draft.proposal.y+p[0]*Math.sin(a)+p[1]*Math.cos(a)];const [x,y]=iso(world,draft.proposal.height);return <circle key={i} cx={x} cy={y} r="7" fill="#e4ad4e" stroke="white" strokeWidth="2"/>;})}
      {drawing&&drawn.length>1&&<polyline points={drawn.map(p=>{const a=draft.proposal.rotation*Math.PI/180;return iso([draft.proposal.x+p[0]*Math.cos(a)-p[1]*Math.sin(a),draft.proposal.y+p[0]*Math.sin(a)+p[1]*Math.cos(a)],draft.proposal.height).join(',');}).join(' ')} fill="none" stroke="#bd8237" strokeWidth="2.5" strokeDasharray="7 5"/>}
      <text x="44" y="72" className="fin-north">N</text><path d="M67 76V48 M67 48l-7 11 M67 48l7 11" fill="none" stroke="#58856f" strokeWidth="2.4" strokeLinecap="round"/><text x="44" y="535" className="fin-ground-label">3D PROJECTION / METRIC-SCALE SITE</text>
     </svg>
     {drawing&&<div className="fin-draw-help"><strong>Draw your canopy</strong><span>Click the canvas for each corner. Minimum three, maximum eight.</span><div><button onClick={()=>{setDrawing(false);setDrawn([]);}}>Cancel</button><button disabled={drawn.length<3} onClick={finishDrawing}>Finish shape <Check size={15}/></button></div></div>}
    </div>
    <div className="fin-timeline"><button className="fin-play" onClick={()=>setPlaying(p=>!p)} aria-label={playing?'Pause simulation':'Play solar simulation'}>{playing?<Pause size={18}/>:<Play size={18}/>}</button><div className="fin-clock"><strong>{minutesLabel(time)}</strong><span>IST</span></div><div className="fin-time-range"><input aria-label="Simulation time" type="range" min="720" max="1020" step="5" value={time} onChange={e=>{setPlaying(false);setTime(Number(e.target.value));}}/><div><span>12 PM</span><span>2:30 PM</span><span>5 PM</span></div></div></div>
    <div className="fin-stage-footer"><span><Sun size={15}/> Rays and shadows share the same solar geometry.</span><span>{axis.status==='osm'?'Site axis from nearby OSM road':'Site orientation assumed · not surveyed'}</span></div>
   </section>
   <aside className="fin-sidebar">
    <div className="fin-design-head"><span className="fin-overline">02 / DESIGN</span><h2>One shape. <i>Yours.</i></h2><p>Drag the roof. Move its corners. Watch the waiting area change.</p></div>
    <div className="fin-custom-tool"><div className="fin-tool-graphic"><svg viewBox="0 0 100 70"><path d="M15 14L74 8L87 50L42 61L13 40Z" fill="#b4dbc8" stroke="#377c5c" strokeWidth="2"/></svg></div><div><strong>Custom canopy</strong><span>{draft.proposal.vertices.length} editable corners · {scenario?polygonArea(scenario.proposedCanopies[0].footprint).toFixed(1):'—'} m²</span></div></div>
    <div className="fin-actions"><button onClick={()=>{setView('after');setDrawing(true);setDrawn([]);setPlaying(false);}}><Plus size={16}/> Draw new shape</button><button onClick={resetShape}><RotateCcw size={15}/> Reset outline</button></div>
    <NumberEntry label="Roof elevation" value={draft.proposal.height} min={1.5} max={7} onChange={n=>setDraft(d=>({...d,proposal:{...d.proposal,height:n}}))}/>
    <details className="fin-measurements" ><summary>Original shelter measurements <ChevronDown size={16}/></summary><p>Set the existing roof and waiting area once. Values are illustrative unless measured onsite.</p><div className="fin-measure-grid"><NumberEntry label="Shelter width" value={draft.existing.width} onChange={n=>updateExisting('width',n)}/><NumberEntry label="Shelter depth" value={draft.existing.depth} onChange={n=>updateExisting('depth',n)}/><NumberEntry label="Shelter height" value={draft.existing.height} onChange={n=>updateExisting('height',n)}/><NumberEntry label="Waiting width" value={draft.waiting.width} onChange={n=>updateWaiting('width',n)}/><NumberEntry label="Waiting depth" value={draft.waiting.depth} onChange={n=>updateWaiting('depth',n)}/></div></details>
    <div className="fin-score"><span>03 / EVALUATE</span><h3>Does it shade more?</h3><div className="fin-score-numbers"><div><small>Before</small><strong>{formatPercent(before)}</strong></div><ArrowRight size={21}/><div><small>After</small><strong>{formatPercent(after)}</strong></div></div><p className="fin-gain">{metrics?`${gain>=0?'+':''}${gain} percentage points · average coverage today`:'Adjust your outline to calculate shade coverage'}</p></div>
    <div className="fin-year"><div className="fin-year-icon"><Sun size={20}/></div><div><strong>Think beyond today.</strong><p>Find a placement that works across twelve monthly solar paths—not just this afternoon.</p></div><button className="fin-primary" onClick={runAnnual} disabled={loading||!scenario}>{loading?'Studying 12 months…':'Find year-round placement'} <ArrowUpRight size={17}/></button>{loading&&<button className="fin-cancel" onClick={()=>{searchNumber.current++;controller.current?.abort();worker.current?.terminate();setLoading(false);}}>Cancel study</button>}
      {yearly&&<div className="fin-year-result"><span>{annualSource==='aws'?'AWS LAMBDA · YEARLY STUDY':'BROWSER · YEARLY STUDY'}</span>{yearly.best?<><div><strong>{formatPercent(yearly.current?.averageCoverage??0)}</strong><ArrowRight size={18}/><strong>{formatPercent(yearly.best.averageCoverage)}</strong></div><p>12 dates × 5 sun positions · {yearly.tested} valid placements tested. Best sampled-year average for your custom shape.</p><div className="fin-actions"><button onClick={()=>setPreview(x=>!x)}>{preview?'Hide':'Preview'} position</button><button onClick={applyAnnual}>Apply <Check size={14}/></button></div>{preview&&<p>Move {yearly.best.distanceM.toFixed(1)} m from this design to {yearly.best.anchor[0].toFixed(1)} m east / {yearly.best.anchor[1].toFixed(1)} m north.</p>}</>:<p>No permitted placement found; your original site remains unchanged.</p>}</div>}
      {message&&<p role="status" className="fin-message">{message}</p>}
    </div>
    <button className="fin-report" onClick={()=>setReport(true)} disabled={!metrics}><FileText size={18}/> View your design assessment <ArrowRight size={16}/></button>
   </aside>
  </div>
  <section className="fin-explainer"><div><span className="fin-overline">WHAT THE MODEL ACTUALLY MEASURES</span><h2>Not how big the roof is.<br/><i>Where its shadow lands.</i></h2></div><p>The result is the fraction of passenger waiting area under direct-beam shade. Today's animation uses actual calculated sun positions; the twelve-month study samples five afternoon sun positions on each of twelve dates. Geometry is supplied by you unless measured onsite.</p></section>
  {report&&<div className="fin-modal" role="dialog" aria-modal="true" aria-label="ShadeDebt assessment"><div className="fin-paper"><div className="fin-paper-actions"><button onClick={()=>setReport(false)}><X size={16}/> Close</button><button onClick={()=>window.print()}><FileText size={16}/> Print / save</button></div><span className="fin-overline">SHADEDEBT / DESIGN ASSESSMENT</span><h2>More shade, where it matters.</h2><p>{site.name} · {dateLabel(draft.date)} · 12:00–17:00 IST</p><div className="fin-report-numbers"><div><span>Original roof</span><strong>{formatPercent(before)}</strong></div><ArrowRight size={25}/><div><span>Custom replacement</span><strong>{formatPercent(after)}</strong></div></div><p>{gain>=0?'This design improves':'This design reduces'} the modeled fraction of the waiting area under direct sunlight protection by {Math.abs(gain)} percentage points on today's analysis.</p>{yearly&&<p><strong>Sampled annual result:</strong> current {formatPercent(yearly.current?.averageCoverage??0)}, best tested {formatPercent(yearly.best?.averageCoverage??0)} over {yearly.dates.length} dates ({yearly.sampledTimes} sun positions). Execution: {annualSource==='aws'?'AWS Lambda':'browser'}.</p>}<dl><dt>Location</dt><dd>{draft.latitude.toFixed(5)}°, {draft.longitude.toFixed(5)}°</dd><dt>Roof footprint</dt><dd>{scenario?polygonArea(scenario.proposedCanopies[0].footprint).toFixed(1):'—'} m²</dd><dt>Roof elevation</dt><dd>{draft.proposal.height.toFixed(1)} metres</dd><dt>Orientation</dt><dd>{axis.status==='osm'?`OSM-nearest-road axis ${axis.bearing?.toFixed(1)}° (not surveyed)`:'Assumed; not geographically verified'}</dd><dt>Source</dt><dd>SunCalc v2 + polygon clipping, direct-beam only</dd></dl><p className="fin-paper-warning">This is a geometric study, not a measured temperature, thermal-comfort, structural, or construction-permit assessment. OSM road axes do not verify physical shelter alignment. The yearly study is sampled, not a continuous annual integral.</p></div></div>}
 </main>;
}
