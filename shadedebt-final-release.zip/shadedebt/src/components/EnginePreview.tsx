import {useEffect, useMemo, useState} from 'react';
import {todayInDelhi} from '../engine/date';
import {Activity, MoveRight, ShieldCheck} from 'lucide-react';
import type {Polygon} from '../types/domain';
import {exampleScenario} from '../engine/demo';
import {simulateScenario, evaluateSunPosition} from '../engine/simulation';
import {istFromClock, sunPosition} from '../engine/solar';
import {canopyShadow, usableSun} from '../engine/shadows';

const fmt = (n:number, digits=1)=>n.toFixed(digits);
const coords=(poly:Polygon)=>poly.map(([x,y])=>`${370+x*33},${205-y*33}`).join(' ');


/** Phase 1 proof panel, deliberately not a full CAD editor (Phase 2). */
export default function EnginePreview({latitude,longitude}:{latitude:number;longitude:number}) {
  const [dateISO,setDateISO]=useState(todayInDelhi);
  useEffect(()=>{const sync=()=>setDateISO(d=>{const today=todayInDelhi();return d===today?d:today;});
    const onVisible=()=>{if(!document.hidden)sync();};
    window.addEventListener('focus',sync);document.addEventListener('visibilitychange',onVisible);
    const interval=window.setInterval(sync,60_000);return()=>{window.removeEventListener('focus',sync);document.removeEventListener('visibilitychange',onVisible);window.clearInterval(interval);};
  },[]);
  const [clock,setClock]=useState(16);
  const [shape,setShape]=useState<'circle'|'rectangle'>('circle');
  const [proposalEast,setProposalEast]=useState(1.5);
  const [proposalHeight,setProposalHeight]=useState(3.1);
  const payload=useMemo(()=>{
    try {
      const scenario=exampleScenario(latitude,longitude);scenario.dateISO=dateISO;
      const canopy=scenario.proposedCanopies[0];
      canopy.heightM=proposalHeight;
      if(shape==='rectangle') {
        canopy.shape='rectangle';
        // Same 10.18 m² approximate footprint as the circular example.
        canopy.footprint=[[-1.1+proposalEast,-2.5],[1.1+proposalEast,-2.5],[1.1+proposalEast,2.1],[-1.1+proposalEast,2.1]];
      } else {
        canopy.footprint=canopy.footprint.map(([x,y])=>[x+proposalEast-1.5,y] as const);
      }
      const report=simulateScenario(scenario);
      const time=`${String(Math.floor(clock)).padStart(2,'0')}:${clock%1===0.5?'30':'00'}`;
      const sun=sunPosition(istFromClock(dateISO,time),latitude,longitude);
      const instant=usableSun(sun)?evaluateSunPosition(scenario.site,scenario.proposedCanopies,'add',sun):null;
      return {scenario,report,sun,instant,proposedShadow:instant?canopyShadow(canopy,sun):null};
    } catch(err) {return {error:err instanceof Error?err.message:'Unable to calculate geometry'};}
  },[latitude,longitude,clock,shape,proposalEast,proposalHeight,dateISO]);
  if('error' in payload) return <section className="engine-preview"><p role="alert">Solar engine could not run: {payload.error}</p></section>;
  const {scenario,report,sun,instant,proposedShadow}=payload;
  const avg=report.metrics;
  return <section className="engine-preview" aria-labelledby="engine-heading">
    <div className="engine-heading"><div><span className="eyebrow">PHASE 1 · FUNCTIONAL ENGINE VERIFICATION</span><h2 id="engine-heading">Solar geometry workbench</h2><p>A live calculation with illustrative site geometry. Select a location above to update solar position; the structure dimensions are not surveyed.</p></div><span className="engine-live"><Activity size={15}/> LIVE CALCULATION</span></div>
    <div className="engine-layout">
      <div className="engine-scene">
        <div className="engine-scene-bar"><span>GROUND PLAN · X EAST → / Y NORTH ↑</span><span>{dateISO} · IST</span></div>
        <svg viewBox="0 0 740 410" role="img" aria-label="Calculated baseline and proposed roof shadows over a rectangular waiting area" className="engine-svg">
          <defs><pattern id="engine-grid" width="33" height="33" patternUnits="userSpaceOnUse"><path d="M33 0 H0 V33" fill="none" stroke="#2d4356" strokeWidth="0.8"/></pattern></defs>
          <rect width="740" height="410" fill="#102337"/><rect width="740" height="410" fill="url(#engine-grid)" />
          <line x1="0" y1="336" x2="740" y2="336" stroke="#627381" strokeWidth="32" opacity=".4"/>
          <text x="26" y="377" fill="#8198AA" fontSize="12">GROUND COORDINATES · 1 GRID = 1m</text>
          <polygon points={coords(scenario.site.waitingArea)} fill="#E6A96A" fillOpacity=".1" stroke="#EDBF81" strokeWidth="2" strokeDasharray="8 6"/>
          {instant?.baselineShadows.map((poly,i)=><polygon key={`base-${i}`} points={coords(poly)} fill="#F0BD76" fillOpacity=".25" stroke="#E5AF68" strokeWidth="1"/>)}
          {proposedShadow&&<polygon points={coords(proposedShadow)} fill="#70D5AE" fillOpacity=".3" stroke="#75E6BE" strokeWidth="1.5"/>}
          {scenario.site.baselineCanopies.map(c=><polygon key={c.id} points={coords(c.footprint)} fill="#52687A" stroke="#B0C2D0" strokeWidth="2"/>)}
          {scenario.proposedCanopies.map(c=><polygon key={c.id} points={coords(c.footprint)} fill="#337F71" fillOpacity=".9" stroke="#B6FFE2" strokeWidth="2"/>)}
          <text x="240" y="132" fontSize="12" fill="#F2C88A">WAITING AREA · 8 × 3m</text>
          <g transform="translate(676 59)"><path d="M0 23V-17 M-7-7L0-18L7-7" fill="none" stroke="#DDEAF1" strokeWidth="2"/><text textAnchor="middle" x="0" y="-28" fill="#DDEAF1" fontSize="13">N</text></g>
          <g transform="translate(60 58)"><circle r="18" fill="#F2BB64"/><path d="M0 0L0 -24" stroke="#F2BB64" strokeWidth="2"/><text x="28" y="5" fill="#AFC6D7" fontSize="13">SUN {fmt(sun.altitudeDeg,0)}°</text></g>
        </svg>
        <div className="engine-controls"><div><label htmlFor="time-preview">LOCAL TIME (IST)</label><strong>{String(Math.floor(clock)).padStart(2,'0')}:{clock%1===0.5?'30':'00'}</strong></div><input id="time-preview" type="range" min="12" max="17" step="0.5" value={clock} onChange={e=>setClock(Number(e.target.value))}/><span>12:00 → 17:00 · scrub to move the physical shadow</span></div>
      </div>
      <div className="engine-sidebar">
        <div className="engine-card"><span className="eyebrow">PROPOSED CANOPY</span><label htmlFor="shape-preview">Geometry preset</label><select id="shape-preview" value={shape} onChange={e=>setShape(e.target.value as 'circle'|'rectangle')}><option value="circle">Circular · Ø 3.6m</option><option value="rectangle">Rectangle · 2.2 × 4.6m</option></select><label htmlFor="east-preview">Easting of canopy centre</label><input id="east-preview" type="range" min="-2" max="3" step="0.25" value={proposalEast} onChange={e=>setProposalEast(Number(e.target.value))}/><strong>{fmt(proposalEast,2)}m east</strong><label htmlFor="height-preview">Roof height</label><input id="height-preview" type="range" min="1.5" max="6" step="0.1" value={proposalHeight} onChange={e=>setProposalHeight(Number(e.target.value))}/><strong>{fmt(proposalHeight)}m</strong></div>
        <div className="engine-card"><span className="eyebrow">CURRENT INSTANT</span>{instant?<><div className="engine-number">{fmt(instant.proposed.coverage*100,1)}%</div><span>combined waiting-area shade · {fmt(sun.altitudeDeg)}° altitude / {fmt(sun.azimuthDeg)}° azimuth</span></>:<p>Sun below supported altitude. No shade coverage asserted.</p>}</div>
        <div className="engine-card"><span className="eyebrow">12:00–17:00 TIME-INTEGRATED</span>{avg?<><div className="engine-stats"><div><span>Baseline debt</span><strong>{fmt(avg.baselineShadeDebtM2Hours)} m²·h</strong></div><div><span>Proposal debt</span><strong>{fmt(avg.proposedShadeDebtM2Hours)} m²·h</strong></div><div><span>Added useful shade</span><strong>{fmt(avg.addedUsefulShadeM2Hours)} m²·h</strong></div></div></>:<p>No evaluable sunlight.</p>}</div>
      </div>
    </div>
    <div className="engine-disclaimer"><ShieldCheck size={16}/><span>Computed with SunCalc v2 and polygon clipping. This is a geometric direct-beam model, not thermal comfort or a surveyed real stop. <strong>Existing roof remains present</strong> (add-intervention mode). Low-sun intervals below 5° are excluded; 15-minute midpoint integration. The primary Shade Laboratory offers editable geometry and constrained placement search.</span><MoveRight size={16}/></div>
  </section>;
}
