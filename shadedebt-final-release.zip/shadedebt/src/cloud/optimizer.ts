/** Thin browser transport. Calculations are owned by the shared Phase 3 engine. */
import type { InterventionScenario } from '../types/domain';
import type { OptimizationResult, OptimizerOptions } from '../engine/optimizer';

export const CLOUD_API_VERSION = 'shadedebt-optimize-v1';
const TIMEOUT_MS = 50000;

export class CloudOptimizationError extends Error {
  constructor(message:string,public readonly shouldFallback:boolean){super(message);this.name='CloudOptimizationError';}
}
export function configuredOptimizerUrl():string|null {
  const raw=String(import.meta.env.VITE_SHADEDEBT_API_URL??'').trim();
  if(!raw)return null;
  try {
    const parsed=new URL(raw);
    if(parsed.protocol!=='https:' && !(import.meta.env.DEV && parsed.protocol==='http:' && ['localhost','127.0.0.1'].includes(parsed.hostname)))return null;
    return parsed.toString();
  }catch{return null;}
}
const isRecord=(v:unknown):v is Record<string,unknown>=>v!==null&&typeof v==='object'&&!Array.isArray(v);
export async function optimizeInCloud(url:string,scenario:InterventionScenario,options:OptimizerOptions,signal?:AbortSignal):Promise<OptimizationResult>{
  const controller=new AbortController();
  const onAbort=()=>controller.abort();
  if(signal?.aborted)throw new DOMException('Aborted','AbortError');
  signal?.addEventListener('abort',onAbort,{once:true});
  const timeout=setTimeout(()=>controller.abort(),TIMEOUT_MS);
  try {
    const response=await fetch(url,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({apiVersion:CLOUD_API_VERSION,scenario,options}),signal:controller.signal,cache:'no-store'
    });
    let payload:unknown;
    try{payload=await response.json();}catch{throw new CloudOptimizationError('The AWS endpoint returned an unreadable response.',true);}
    if(!response.ok){
      const message=isRecord(payload)&&typeof payload.error==='string'?payload.error:`AWS returned HTTP ${response.status}.`;
      throw new CloudOptimizationError(message,response.status===429||response.status>=500||response.status===408);
    }
    if(!isRecord(payload)||payload.ok!==true||payload.modelVersion!=='phase3-translation-grid-v1'||!isRecord(payload.result)){
      throw new CloudOptimizationError('AWS returned an incompatible optimizer result; refusing to apply it.',false);
    }
    const result=payload.result as unknown as OptimizationResult;
    if(result.model!=='phase3-translation-grid-v1'||!Number.isInteger(result.evaluatedCandidates)||result.evaluatedCandidates<0||result.evaluatedCandidates>750||
      (result.best!==null && (!isRecord(result.best)||!Array.isArray(result.best.anchor)||result.best.anchor.length!==2||!result.best.anchor.every((v:unknown)=>typeof v==='number'&&Number.isFinite(v)) || typeof result.best.shadeDebtM2Hours!=='number'||!Number.isFinite(result.best.shadeDebtM2Hours)))){
      throw new CloudOptimizationError('AWS returned an invalid optimizer result; refusing to apply it.',false);
    }
    return result;
  }catch(e){
    if(signal?.aborted)throw new DOMException('Aborted','AbortError');
    if(e instanceof CloudOptimizationError)throw e;
    if(e instanceof Error && e.name==='AbortError')throw new CloudOptimizationError('AWS optimization timed out.',true);
    throw new CloudOptimizationError('AWS optimization is temporarily unreachable.',true);
  }finally{
    clearTimeout(timeout);signal?.removeEventListener('abort',onAbort);
  }
}
