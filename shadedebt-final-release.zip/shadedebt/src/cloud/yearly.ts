/** Cloud annual optimization; keep the legacy v1 search API intact. */
import type {InterventionScenario,Vec2} from '../types/domain';
import {YEARLY_MODEL_VERSION,type YearlyResult} from '../engine/yearly';
import {configuredOptimizerUrl} from './optimizer';
export const YEARLY_API_VERSION='shadedebt-optimize-year-v1';
export async function optimizeYearCloud(scenario:InterventionScenario,anchor:Vec2,signal:AbortSignal):Promise<YearlyResult>{
 const url=configuredOptimizerUrl();if(!url)throw new Error('Cloud endpoint not configured');
 const c=new AbortController();const abort=()=>c.abort();signal.addEventListener('abort',abort,{once:true});
 const timer=setTimeout(()=>c.abort(),45000);
 try{
  const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({apiVersion:YEARLY_API_VERSION,scenario,options:{anchor}}),signal:c.signal});
  const payload=await response.json() as {ok?:boolean;modelVersion?:string;result?:YearlyResult;error?:string};
  if(!response.ok||!payload.ok)throw new Error(payload.error||`Cloud HTTP ${response.status}`);
  const result=payload.result;
  if(payload.modelVersion!==YEARLY_MODEL_VERSION||result?.model!==YEARLY_MODEL_VERSION||!Number.isInteger(result.tested)||result.tested>120||result.tested<0||!Array.isArray(result.dates)||result.dates.length!==12||!result.dates.every(v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v))||!Number.isInteger(result.sampledTimes)||result.sampledTimes<1||result.sampledTimes>60)throw new Error('Cloud returned an incompatible annual result');
  const goodPlacement=(v:typeof result.best)=>v===null||(Array.isArray(v.anchor)&&v.anchor.length===2&&v.anchor.every(x=>typeof x==='number'&&Number.isFinite(x)&&Math.abs(x)<1000)&&Number.isFinite(v.averageCoverage)&&v.averageCoverage>=0&&v.averageCoverage<=1&&Number.isFinite(v.distanceM)&&v.distanceM>=0);
  if(!goodPlacement(result.best)||!goodPlacement(result.current))throw new Error('Cloud returned an invalid placement');
  return result;
 }finally{clearTimeout(timer);signal.removeEventListener('abort',abort);}
}
