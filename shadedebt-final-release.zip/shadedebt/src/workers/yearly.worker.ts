import {optimizeYear} from '../engine/yearly';
import type {InterventionScenario,Vec2} from '../types/domain';
self.onmessage=(e:MessageEvent<{scenario:InterventionScenario;anchor:Vec2}>)=>{
 try{self.postMessage({ok:true,result:optimizeYear(e.data.scenario,e.data.anchor,120)});}catch(err){self.postMessage({ok:false,error:err instanceof Error?err.message:'Annual search failed'});}
};
