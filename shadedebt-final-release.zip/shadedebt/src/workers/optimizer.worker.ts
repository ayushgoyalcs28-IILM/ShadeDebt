import { optimizeScenario, type OptimizerOptions } from '../engine/optimizer';
import type { InterventionScenario } from '../types/domain';
self.onmessage=(event:MessageEvent<{requestId:number;scenario:InterventionScenario;options:OptimizerOptions}>)=>{
  const {requestId,scenario,options}=event.data;
  try {self.postMessage({requestId,ok:true,result:optimizeScenario(scenario,options)});}
  catch(error){self.postMessage({requestId,ok:false,error:error instanceof Error?error.message:'Optimization failed'});}
};
