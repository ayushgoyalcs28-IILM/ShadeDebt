/** Geometry is in local ENU-style ground coordinates: x East, y North, metres. */
export type Vec2 = readonly [number, number];
export type Polygon = readonly Vec2[];
export type MeasurementMode = 'concept' | 'survey';
export type CanopyShape = 'rectangle' | 'circle' | 'triangle' | 'trapezoid' | 'hexagon' | 'custom';

export interface TransitStop {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  source: string;
}
export interface Canopy {
  id: string;
  shape: CanopyShape;
  footprint: Polygon;
  heightM: number;
  opaque: true;
}
export interface Building {
  id: string;
  footprint: Polygon;
  heightM: number;
}
export interface SiteModel {
  schemaVersion: 1;
  name: string;
  latitude: number;
  longitude: number;
  measurementMode: MeasurementMode;
  waitingArea: Polygon;
  baselineCanopies: Canopy[];
  buildings: Building[];
  allowedConstructionZone: Polygon;
  exclusionZones: Polygon[];
  measurementNotes?: string;
}
export interface InterventionScenario {
  id: string;
  site: SiteModel;
  mode: 'add' | 'replace';
  proposedCanopies: Canopy[];
  dateISO: string;
  startTimeIST: string;
  endTimeIST: string;
  sampleMinutes: number;
}
