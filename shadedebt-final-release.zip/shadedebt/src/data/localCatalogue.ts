import type { TransitStop } from '../types/domain';
import { parseStopCatalogue } from './catalogue';

/** Private Kaggle catalogue: dev-only Vite middleware. Optional public feed:
 * explicitly generated ODbL-licensed OpenStreetMap derived locations. */
export async function loadLocalCatalogue(): Promise<TransitStop[]> {
  if(import.meta.env.DEV){
    try {
      const response = await fetch('/__shadedebt_local_stops.json', { cache: 'no-store' });
      if(response.ok)return parseStopCatalogue(await response.json()).stops;
    }catch{/* private data absent or invalid */}
  }
  // Published only after a separate, explicitly licensed OSM extraction.
  // This never reads or bundles the development-only Kaggle-derived catalogue.
  try {
    const response = await fetch('/data/delhi-stops.json', {cache:'no-store'});
    if(!response.ok || !String(response.headers.get('content-type')??'').includes('json'))return [];
    return parseStopCatalogue(await response.json()).stops;
  }catch {return [];}
}
