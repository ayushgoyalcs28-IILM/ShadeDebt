import type { TransitStop } from '../types/domain';

/** Stable identity for independently saved physical surveys. Different stop IDs
 * must never share a survey merely because their coordinates coincide. */
export interface SelectedSite {
  key:string;
  name:string;
  latitude:number;
  longitude:number;
  source:string;
  kind:'stop'|'custom';
}
export function fromStop(stop:TransitStop):SelectedSite {
  return {key:`stop:${encodeURIComponent(stop.source)}:${encodeURIComponent(stop.id)}`,name:stop.name,latitude:stop.latitude,longitude:stop.longitude,source:stop.source,kind:'stop'};
}
export function fromCustom(name:string,latitude:number,longitude:number):SelectedSite {
  if(!Number.isFinite(latitude)||!Number.isFinite(longitude)||Math.abs(latitude)>90||Math.abs(longitude)>180)throw new Error('Invalid coordinates');
  return {key:`custom:${latitude.toFixed(7)}:${longitude.toFixed(7)}`,name:name.trim().slice(0,160)||'Custom site',latitude,longitude,source:'manually-entered',kind:'custom'};
}
export function draftStorageKey(key:string):string {return `shadedebt.phase4.site.${encodeURIComponent(key)}`;}
export function legacyDraftStorageKey(lat:number,lon:number):string {return `shadedebt.phase2.site.${lat.toFixed(5)}.${lon.toFixed(5)}`;}
