import type { TransitStop } from '../types/domain';

/** Normalise *user provided* stop catalogues. A stop is a geographic record, not
 * evidence that a physical shelter currently exists. Same-name opposite-side
 * stops are deliberately NOT collapsed. */
export interface CatalogueParse {
  stops: TransitStop[];
  rejected: number;
  duplicates: number;
}

export const MAX_CATALOGUE_RECORDS = 20_000;
const isRecord = (v: unknown): v is Record<string,unknown> => v !== null && typeof v === 'object' && !Array.isArray(v);
const clean = (v: string, max: number) => v.trim().slice(0,max);
// Exact input coordinates only: rounding would collapse source-distinct IDs.
const coordKey = (lat:number,lon:number) => `${lat}|${lon}`;

export function parseStopCatalogue(input: unknown): CatalogueParse {
  if (!Array.isArray(input) || input.length > 25_000) throw new Error('Expected a JSON array with no more than 25,000 records.');
  const stops:TransitStop[]=[];
  const ids=new Set<string>();
  const locations=new Set<string>();
  let rejected=0,duplicates=0;
  for(const raw of input){
    if(!isRecord(raw) || typeof raw.id!=='string' || typeof raw.name!=='string' || typeof raw.latitude!=='number' || typeof raw.longitude!=='number') { rejected++;continue; }
    const id=clean(raw.id,120),name=clean(raw.name,160),lat=raw.latitude,lon=raw.longitude;
    if(!id||!name||!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180) {rejected++;continue;}
    const locationName=`${coordKey(lat,lon)}|${name.toLocaleLowerCase('en')}`;
    if(ids.has(id)||locations.has(locationName)){duplicates++;continue;}
    ids.add(id);locations.add(locationName);
    stops.push({id,name,latitude:lat,longitude:lon,source:typeof raw.source==='string'?clean(raw.source,160):'user-provided-unverified'});
    if(stops.length>MAX_CATALOGUE_RECORDS) throw new Error('Catalogue exceeds the 20,000-stop limit.');
  }
  if(stops.length===0)throw new Error('No valid geographic stop locations found.');
  return {stops,rejected,duplicates};
}

export function searchStops(stops: readonly TransitStop[], query:string, limit=25): TransitStop[] {
  const needle=query.trim().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('en');
  if(needle.length<2)return [];
  const matches:TransitStop[]=[];
  for(const stop of stops){
    const text=stop.name.normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('en');
    if(text.includes(needle)){matches.push(stop);if(matches.length>=limit)break;}
  }
  return matches;
}
