/** On-demand, user-triggered road alignment from OpenStreetMap's Overpass data.
 * Estimates the tangent of the nearest plausible road segment. Roads do NOT verify
 * the orientation or existence of an actual shelter. Never report as surveyed.
 */
export interface RoadNode {lat:number;lon:number}
export interface RoadWay {geometry:RoadNode[];tags?:Record<string,string>}
export interface RoadAxis {bearingDeg:number; distanceM:number;roadName?:string;status:'osm'|'unavailable'}
const DEG=Math.PI/180;
const isRoad=(tags?:Record<string,string>)=>!tags?.highway || /^(residential|living_street|unclassified|tertiary|secondary|primary|trunk|service|busway|pedestrian|road)$/i.test(tags.highway);
export function nearestRoadAxis(latitude:number,longitude:number,ways:readonly RoadWay[]):RoadAxis|null {
  const metresLat=111132, metresLon=Math.cos(latitude*DEG)*111320;
  let best:RoadAxis|null=null;
  for(const way of ways){
    if(!isRoad(way.tags)||!Array.isArray(way.geometry))continue;
    for(let i=1;i<way.geometry.length;i++){
      const a=way.geometry[i-1],b=way.geometry[i];
      if(![a.lat,a.lon,b.lat,b.lon].every(Number.isFinite))continue;
      const x0=(a.lon-longitude)*metresLon,y0=(a.lat-latitude)*metresLat;
      const x1=(b.lon-longitude)*metresLon,y1=(b.lat-latitude)*metresLat;
      const dx=x1-x0,dy=y1-y0,len2=dx*dx+dy*dy;
      if(len2<4)continue;
      const t=Math.max(0,Math.min(1,-(x0*dx+y0*dy)/len2));
      const distanceM=Math.hypot(x0+t*dx,y0+t*dy);
      if(distanceM>65||(best&&distanceM>=best.distanceM))continue;
      // Undirected axis: 180 degrees equivalent for a rectangular shelter.
      const bearingDeg=((Math.atan2(dx,dy)/DEG)%180+180)%180;
      best={bearingDeg,distanceM,roadName:way.tags?.name,status:'osm'};
    }
  }
  return best;
}
export async function lookupRoadAxis(lat:number,lon:number,signal?:AbortSignal):Promise<RoadAxis|null>{
  if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return null;
  const cacheKey=`shadedebt.road-axis.v1.${lat.toFixed(5)}.${lon.toFixed(5)}`;
  try{const cached=localStorage.getItem(cacheKey);if(cached){const parsed=JSON.parse(cached) as {saved:number;result:RoadAxis|null};if(Date.now()-parsed.saved<30*864e5)return parsed.result;}}catch{/* Storage optional */}
  const query=`[out:json][timeout:12];way(around:70,${lat.toFixed(7)},${lon.toFixed(7)})["highway"~"^(residential|living_street|unclassified|tertiary|secondary|primary|trunk|service|busway|road)$"];out geom;`;
  const controller=new AbortController();const forward=()=>controller.abort();signal?.addEventListener('abort',forward,{once:true});
  const timer=setTimeout(()=>controller.abort(),9000);
  try{
    const response=await fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`,{signal:controller.signal,headers:{Accept:'application/json'}});
    if(!response.ok)return null;
    const raw=await response.json() as {elements?:RoadWay[]};
    const result=nearestRoadAxis(lat,lon,Array.isArray(raw.elements)?raw.elements:[]);
    try{localStorage.setItem(cacheKey,JSON.stringify({saved:Date.now(),result}));}catch{/* Optional */}
    return result;
  }catch{return null;}
  finally{clearTimeout(timer);signal?.removeEventListener('abort',forward);}
}
/** Rotate an entire conceptual site as one object around its origin. */
export function rotateLocal(x:number,y:number,angleDeg:number):[number,number]{
  const a=angleDeg*DEG;return [x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a)];
}
