import type { TransitStop } from '../types/domain';

/** Pure screen-space aggregation. Rebuild on pan/zoom; only in-view records are
 * considered and exact identity is retained inside each cluster. */
export interface StopCluster { latitude:number; longitude:number; members:TransitStop[]; }
export function groupStopsInViewport(
  stops:readonly TransitStop[],
  contains:(lat:number,lon:number)=>boolean,
  toPixels:(lat:number,lon:number)=>readonly [number,number],
  cellPixels:number
):StopCluster[] {
  if(!Number.isFinite(cellPixels)||cellPixels<=0)throw new Error('Positive grid size required');
  const cells=new Map<string,{members:TransitStop[];latSum:number;lonSum:number}>();
  for(const stop of stops){
    if(!contains(stop.latitude,stop.longitude))continue;
    const [x,y]=toPixels(stop.latitude,stop.longitude);
    if(!Number.isFinite(x)||!Number.isFinite(y))continue;
    const key=`${Math.floor(x/cellPixels)}:${Math.floor(y/cellPixels)}`;
    const group=cells.get(key);
    if(group){group.members.push(stop);group.latSum+=stop.latitude;group.lonSum+=stop.longitude;}
    else cells.set(key,{members:[stop],latSum:stop.latitude,lonSum:stop.longitude});
  }
  return Array.from(cells.values(),({members,latSum,lonSum})=>({
    latitude:latSum/members.length,longitude:lonSum/members.length,members
  }));
}
