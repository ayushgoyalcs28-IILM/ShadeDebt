# Phase 3 — Constrained placement assistant

## Deliverable

ShadeDebt now searches *translations only* of the single proposed canopy, preserving its original polygon, area, height and rotation. Existing and proposed structures remain independent. Users can preview the best tested permissible location and elect to apply it. The optimizer does **not** change the design automatically.

This is a deterministic, bounded grid search rather than a continuous global optimization or a structural safety analysis.

## Algorithm and invariant

1. Convert the Phase 2 `SiteDraft` to the unchanged Phase 1 `InterventionScenario` via `toScenario`.
2. Validate the scenario and proposed canopy polygon using the Phase 1 validation routines.
3. Sample the current **Delhi calendar day** over the existing user-selected time window at the same 15-minute midpoint intervals as Phase 1. SunCalc v2 provides azimuth/altitude.
4. Calculate background and baseline shadows once for each evaluated sample: existing canopies, plus buildings as appropriate. Skip periods with solar altitude below the engine's 5° cutoff.
5. For each candidate translation, check that its complete polygon footprint (not its box or centre alone) is inside the permitted construction polygon by intersection area. Reject positive-area intersection with site exclusions, solid building footprints, and baseline roof footprints in add mode.
6. Evaluate remaining candidates using `canopyShadow`, `measureShade` (polygon union and waiting-zone intersection) and `aggregateMetrics`. Minimize *proposed ShadeDebt* in m²·h. Time-of-day weights and minimum sun altitude exactly match the Phase 1 engine.
7. Enumerate a regular 1.0 m coarse grid in east/north physical coordinates within the feasible bounding rectangle, include the original placement if permitted, then refine a 0.25 m grid within 0.75 m of the best coarse position. Tie-break by shortest translation and then deterministic x/y order. Cap scored candidates at 750.
8. Return the best candidate, its metrics, rejection count, optional valid-original metrics, explicit assumptions and a rationale. Return no recommendation if no permitted candidates or no evaluable sun.

The results are *best among evaluated candidates*, not a global optimum. Material properties, roof supports, boarding accessibility, sightlines, underground utilities and construction costs remain outside this mathematical model. A site professional must review every installation.

### Decision metric

`ShadeDebt = ∑(waitingAreaM² - shadedWithinWaitingM²) × sampleHours`.

For a fixed waiting area and analysis window, reducing this is equivalent to increasing the time-integrated useful shade. The optimizer therefore does **not** reward shade thrown onto the road or outside the waiting polygon. Duplicate overlapping shadows are counted once.

### Add versus replace

- **Add:** Existing roof(s) and building shadows are retained as background; a new roof cannot geometrically overlap the baseline roof footprint in the permitted candidate set.
- **Replace:** The baseline retains the current roofs, but candidate scoring uses only buildings and the proposed replacement roof. The candidate may occupy the original roof's footprint.

### Workers, stale results and user control

The browser instantiates `optimizer.worker.ts` through Vite's native module Worker support to avoid blocking animation and edits. The Worker can be cancelled. Changing the site invalidates an in-flight calculation and any stale recommendation; the user must search again. Preview draws a distinct golden dotted roof outline and changes no model inputs. Apply updates only `proposal.x/y`; existing Phase 2 live analysis recomputes all metrics from the same geometry engine.

## Current-day behavior (Phase 2 correction)

`todayInDelhi()` converts the **device current instant** to the `Asia/Kolkata` calendar date via `Intl.DateTimeFormat.formatToParts`. This is not a solar API request. The main laboratory and the legacy diagnostic workbench set their simulation date from this function on startup and refresh it after window focus, tab reactivation or a one-minute check. Old saved Phase 2 dates are replaced with today's Delhi date upon loading. The local-time simulation slider still controls a time range on **today's date**.

A device clock that is wrong can produce an incorrect calendar date. Simulation predicts geometric direct-beam shade for that date and does not sample current cloud cover.

## Adjustable constraints

The original ground coordinate convention remains x=east, y=north in metres. The site editor now exposes a rectangular allowed construction envelope and a supplemental optional rectangular no-build zone. The existing road strip remains part of the exclusion set. These constraints are *planning assumptions* manually supplied by the user; the tool cannot discover legal setbacks or construction permissions.

## Acceptance tests and status

- `npm run smoke:offline` — Phase 0/2/3 static smoke checks. **13/13 passed in the authoring environment**.
- Strict source check against dependency declaration stubs — **passed**, NOT a full installed-library TypeScript build.
- `npm run check`, `npm test`, `npm run build` — **must be executed with real npm dependencies on developer machine**. Authoring environment package installation was blocked.
- `npm run test:phase3` — numerical optimizer tests and timezone rollover tests (authored, actual Vitest run pending).
- Browser review — manually test all six shapes, add/replace modes, exclusions, no valid candidate, date rollover/resume, preview/apply, and responsiveness while search runs.

## Out of scope

No cloud optimizer, verified public Delhi database, formal PDF/report and no construction-ready engineering certification; those remain later phases. Source catalogue remains dev-only under `local-data/stops.json`, and public builds omit unverified Kaggle-derived data.

When changing between the six roof presets, the **Lock roof footprint area** toggle is enabled by default. It uniformly scales the new polygon to preserve the previous roof area, allowing a fair shape comparison; users can disable it to experiment with different roof budgets.
