# Phase 1 — solar geometry engine and verification contract

Status: engine modules and a **live scientific verification panel** added on top of the unchanged Phase 0 site-selector and overview workflow. This is NOT the full Phase 2 drawing/editor UI, not a real bus-stop survey, not AWS Lambda deployment, and not a thermal comfort model.

## Units and coordinate conventions

- Site latitude/longitude: WGS84-style degrees, positive N/E.
- All physical site footprints: **metres**, local `(x=east, y=north)`.
- Screen: x increases right/east, y increases up/north (SVG applies negative y in the rendering conversion).
- All roof and building footprints: non-self-intersecting polygons with ≥3 vertices, no holes.
- Shapes: rectangle, circle (96-sided default), triangle, trapezoid, hexagon, user-defined polygon. Custom polygons share the SAME projection engine.
- Canopy is an **opaque, horizontal, planar polygon at uniform height**. It has no walls.
- Building is a **solid vertical convex prism** from level ground to constant roof height; rectangles are valid. Concave footprints intentionally rejected. Trees, tilt, roof curvature, thermal properties and diffuse radiation are out of scope.

## Time and solar position

- Dates are local civil YYYY-MM-DD (Delhi, IST UTC+05:30). `Date.UTC` constructs instants explicitly. Never use server/browser locale for calculation.
- SunCalc pinned to v2.0.2. **Breaking API:** output altitude/azimuth are in DEGREES; azimuth clockwise from TRUE NORTH (0 N, 90 E, 180 S, 270 W). v1 is incompatible without conversion.
- SunCalc apparent altitude includes atmospheric refraction. Geometry still uses an idealized straight solar ray.
- Samples use midpoints of 15-minute (configurable 5–60 minute) intervals; last partial interval has its actual duration.
- Sun below the horizon and below **5° altitude** is explicitly excluded from metrics (not scored as shaded). The report gives evaluated/excluded minutes, and metrics are `null` when nothing is eligible. Users should not interpret reported averages as an all-day exposure assessment.

## Shadow projection

For a canopy height `h`, solar altitude α and north-clockwise azimuth A (angles converted to radians):

```
dx = -h * sin(A) / tan(α)   // metres east
dy = -h * cos(A) / tan(α)   // metres north
```

A flat roof's shadow footprint is its roof polygon translated by `(dx,dy)`. At 4 PM Delhi in May, the sun is to the west; therefore dx is positive (eastward shadow). An opaque roof's shadow area before clipping is independent of altitude under the level-ground model.

A solid, convex vertical building casts the swept union of its footprint and translated rooftop. This is represented by the convex hull of the original vertices plus translated vertices. Using only the translated roof would miss wall shadows; using the hull for a concave building would overstate the shaded area. That is why concave buildings are rejected in Phase 1.

## Coverage and ShadeDebt

At each eligible time sample, let `W` be the waiting zone, `B(t)` the union of baseline shelter and building shadows, and `P(t)` the union after modification.

```
A_baseline(t) = area(W ∩ B(t))
A_proposed(t) = area(W ∩ P(t))
coverage(t) = A(t) / area(W)

D = Σ [area(W) − A(t)] * Δt_hours     // ShadeDebt, m²·h
coverage_average = Σ [A(t)*Δt_hours] / [area(W)*Σ Δt_hours]
```

Union is performed **before** intersection to avoid double-counting overlapping shade. MultiPolygon hole areas are subtracted. No aggregation uses unverified passenger counts or temperature predictions.

- `add`: keep baseline shelters and buildings, add proposed canopies. Under fixed model assumptions ShadeDebt cannot increase.
- `replace`: keep buildings, remove baseline shelters and use only proposed canopies. A design can legitimately perform worse.
- Additional useful shade = `Σ (A_proposed − A_baseline)*Δt_hours`, which may be negative for replacement.
- No optimization or automated placement search in this phase; Phase 3 will use the same deterministic evaluator.

## Example workbench

Open **Site selector**. Leave Delhi coordinates or edit them. Below the unchanged Phase 0 forms is an **illustrative, live** scene for 15 May 2026 between 12:00 and 17:00 IST.

Controls:
1. Drag the time slider. Verify the shadow changes and the sun azimuth is westerly near 4 PM.
2. Change proposed canopy from circle to equal-approximate-area rectangle. The shape changes, and calculated coverage/debt updates.
3. Change the roof height. The translation length changes.
4. Change the canopy's east position. Time-integrated shade debt changes.
5. Change latitude/longitude in the site form. Solar position changes.

**Important:** Selected stop coordinates do not imply actual physical measurements. The stop catalogue remains empty in this source package pending confirmed redistribution rights. Do not label the example measurements as surveyed.

## Tests and pass/fail gates

With Node >=20.19 and npm dependencies installed:

```
npm install
npm run check
npm test
npm run build
npm run dev
```

Tests cover coordinates, shape areas, self-intersection, transforms, solar reference values, IST conversion, shadow direction, canopies, convex solid buildings, polygon union / holes / clipping, partial times, nighttime, add/replace semantics, and reproducibility. The original Phase 0 smoke tests are retained unchanged.

The engine source was statically typechecked in an offline environment with signature shims and tested against *independent* Swiss Ephemeris and Shapely reference adapters. **The container cannot download npm packages**, so the real installed SunCalc/polygon-clipping/Vitest build must be validated on the user's internet-connected machine. Do not describe the offline adapters as the production libraries.

## Model limitations (must remain in the product)

- This models direct sun obstruction on a horizontal plane; NOT radiant-temperature exposure, air temperature, thermal comfort, health risk, construction safety, structural loading, material transmittance, or cloudy/diffuse conditions.
- Site dimensions, obstruction layout, orientation and height require measurements for site-specific claims.
- SunCalc uses apparent altitude and a solar-point approximation; penumbra and non-level ground not modeled.
- Within the sampling window, low sun may be important in practice but is intentionally omitted for numerical stability; results disclose exclusions.
- Accuracy of simulation output does not imply accuracy of unverified inputs.
