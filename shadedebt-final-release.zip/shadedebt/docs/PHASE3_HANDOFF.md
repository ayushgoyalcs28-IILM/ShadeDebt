# Phase 3 handoff — incremental upgrade

**Baseline:** The *complete Phase 2 source*, including the Phase 0 + 1 code and Phase 2 editor. The patch contains only Phase 3 and agreed date-correction changes. Phase 1 solar, shadow, polygon clipping, metrics and simulation modules were not edited.

## Recommended upgrade on your machine

1. Commit or stash local changes; `git status --short` should be empty.
2. Download `shadedebt-phase3.patch`. From the Phase 2 repo root:

   ```sh
   git apply --check /path/to/shadedebt-phase3.patch
   git apply /path/to/shadedebt-phase3.patch
   npm install
   npm run check
   npm test
   npm run build
   npm run dev
   ```

3. If you need the complete project rather than a patch, extract `shadedebt-phase3-source.zip` into a new directory. The separate local-data package must be restored into `local-data/stops.json` to enable historical stop search in development. It is intentionally excluded from Git and public builds.

## Manual acceptance journey

1. Open Shade Laboratory. Confirm the displayed date is **today in Delhi**, not May 15. If the device is located in another timezone, the Delhi date may differ near midnight.
2. In Intervention, select Circle. The current input can start outside the collision-free envelope; the panel should flag it rather than pretending it is valid.
3. Select **Search for better placement**, wait for candidate counts and a rationale. Inspect the golden preview, then **Apply placement**. Live metrics and the shadow on the canvas should change and the previous search result should become stale.
4. Switch to Rectangle, Trapezoid and Freeform. Confirm that the search holds current polygon area, height and rotation constant for each run.
5. Under Site setup, enable a 3 × 2 m no-build rectangle. Re-run the search. Preview must not intersect the prohibited footprint.
6. Toggle **Add new roof** versus **Replace roof**. These modes have different roof-collision rules and baseline interpretations.
7. If there are no evaluated daylight samples or no feasible candidates, verify that the UI says so instead of producing an attractive false recommendation.
8. Navigate away and back. Confirm the edited site remains saved locally; the calendar date still resets to current Delhi date on resume.
9. Confirm previous Phase 2 custom vertex editing, building shadows, geometry controls, stop search and coverage charts are intact.
10. Open the Advanced Phase 1 workbench under Site selector and confirm it also shows today's date.

## Known boundaries

- The optimizer is bounded and does not prove global optimality. It checks *horizontal footprint geometry*, not physical supports or civil engineering safety.
- Near-horizon solar angles under 5° are excluded exactly as in Phase 1.
- There is no simulated thermal material performance or verified site measurement.
- Full npm build and real browser testing must be verified locally before closing Phase 3.

When changing between the six roof presets, the **Lock roof footprint area** toggle is enabled by default. It uniformly scales the new polygon to preserve the previous roof area, allowing a fair shape comparison; users can disable it to experiment with different roof budgets.
