# Phase 2 — Model, units and evidence

## Architectural invariants

All physics lives in the Phase 1 `src/engine/` modules and is not duplicated in React. Phase 2 `SiteDraft` is an ergonomic editable representation only, converted into the existing `InterventionScenario` by `toScenario()`.

- Ground local coordinates: **x east, y north, z up**, in **metres**.
- Rotation of a polygon: degrees counter-clockwise from east. The compass remains north-up even as an object's rotation changes.
- Site geolocation: degrees latitude/longitude; used for astronomical sun position only. Geographic degrees are *never* used as planar metres.
- User date/time: India Standard Time for Delhi (fixed UTC+05:30). The same date/time window drives animation and midpoint time-integrated metrics.
- Canopies: horizontal opaque polygons at a uniform roof elevation, with footprints constructed for rectangle, circle (64-sided discretization), triangle, trapezoid, hexagon or editable custom polygon.
- Shadow translation for solar altitude α and solar azimuth A: `dx = -h sin(A)/tan(α)` and `dy = -h cos(A)/tan(α)`.
- Building shadow: convex hull of solid building footprint and translated elevated roof footprint (only valid for convex vertical prisms).
- Combine all shadows by polygon union, clip to waiting-area polygon, calculate *area* without double-counting.
- Report average coverage and unshaded area-time `ShadeDebt = Σ(Awaiting − Ashaded,i)·Δti`, in m²·h. Sample duration is accounted for, including fractional final intervals.
- Disallow unphysical self-intersecting user polygons. The editor warns when a proposed footprint is outside its site envelope or intersects road exclusion geometry. Phase 3 will enforce candidate feasibility in search, not Phase 2.

## Why the visualization is not merely decorative

The roof polygons and illuminated waiting area are drawn from the **same authoring geometry** passed to the physics engine. Clipped mint regions use the actual polygon-union/intersection output at the selected sun position. The solar compass marker is positioned at the calculated azimuth, not an animation constant. The dashed centre displacement shows the actual model's roof-to-shadow vector. The sectional illustration derives its height and ground-shift annotations from the same inputs and solar altitude; the canopy graphic is illustrative rather than full engineering elevation.

## Reading a result correctly

If baseline ShadeDebt is 90 m²·h and the proposal has 70 m²·h, this demonstrates **20 m²·h less *modeled unshaded waiting-area footprint* over the evaluated interval**. It does not mean 20 m² of physical material, twenty passenger-hours, a specified degree of cooling, or verified health benefit.

“Canopy-area efficiency” here means *(modeled added shaded area-time) / (proposed canopy footprint area × evaluated hours)*; it is dimensionless. An `Add` intervention may not reduce coverage; a `Replace` design may. This is an assessment of the selected proposed geometry, **not** a statement that it is optimal. Optimizing over permitted placements and an equal canopy-area budget is Phase 3.

The engine excludes samples with solar altitude below 5° rather than counting them as shaded. Time sampling, missing neighbouring buildings, actual site measurement error, building geometry simplifications, roof opacity, and diffuse or reflected radiation all limit accuracy. Assessment results are best viewed as directional *concept design comparisons*, not surveyed engineering certification.

## Data governance

The earlier Kaggle audit produced 6,880 unique coordinate pairs. This is a historical **location catalogue**, not 6,880 confirmed existing canopies. Each displayed label should remain associated with its source and metadata. Upstream ODbL/database redistribution rights were not established from the DbCL contents-license link; this repository avoids publishing those records by keeping them in a Git-ignored development folder and only exposing them via a Vite `apply:'serve'` middleware route. Users may import licensed files client-side in a production session; file contents are not uploaded to a server by the Phase 2 app.
