# Deployment runbook (no credentials sent to ChatGPT)

## 1. Manual Phase 0 Amplify smoke test
1. Sign in to https://console.aws.amazon.com/amplify/ using your verified AWS account.
2. **Create new app** → **Deploy without Git** → **Next**.
3. App name `shadedebt-smoke`, branch `main`, method **Drag and drop**.
4. Upload the separately provided `shadedebt-amplify-smoke.zip`, not the source project archive.
5. **Save and deploy**. Wait for AWS to show deployment success.
6. Open the AWS-generated HTTPS URL. Verify the words `SHADEDEBT · AWS AMPLIFY CONNECTIVITY CHECK`.
7. Note the public URL (do not expose IAM credentials). This verifies **hosting**, not Lambda permissions.

AWS official manual-deploy reference: https://docs.aws.amazon.com/amplify/latest/userguide/manual-deploys.html

## 2. Real React application
On your own machine, with Node >=20.19:
```bash
npm install
npm run check
npm run test
npm run build
```
`npm install` generates `package-lock.json`—commit it. To deploy via Amplify manual deployment, zip **contents** of `dist/`, not the parent directory. Or connect the Github repo and build via `amplify.yml` (`npm ci` requires a lockfile).

## 3. AWS service validation (next phases)
- After Phase 1 engine tests, package optimizer endpoint for AWS Lambda and restrict its HTTP invocation; use request validation, CORS limited to Amplify domain, throttling/budget alerts.
- No AWS access keys in repo, frontend, screenshots or chats.
- Keep cloud optional to live UI animation: animation performs calculations in browser. A real Lambda call will later provide reproducible optimizer results.
- Confirm AWS account identity, permitted services and selected AWS region from inside the user's Console; this environment has no AWS session.

## 4. Costs
Amplify and Lambda may incur charges. Check service pricing/free allowances, set a budget alarm, and remove unused deployments after judging.
