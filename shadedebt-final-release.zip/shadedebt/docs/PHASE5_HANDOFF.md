# ShadeDebt Phase 5 — AWS deployment and acceptance

## What changed

The Phase 4 source is extended, not replaced. `src/engine/*.ts`, the Phase 3 optimizer, site drafts, map, and all prior tests are preserved. The Phase 5 Lambda function bundles **the same** `optimizeScenario()` implementation as the browser Worker; no alternative shade-scoring formulas were created.

- `lambda/handler.ts`: versioned, stateless compute-only HTTP API with request-size, geometry and bounded-search validation.
- `src/cloud/optimizer.ts`: browser HTTP client, timeout, schema/model checks, abort support.
- Shade Laboratory: calls AWS when configured, indicates AWS execution, and falls back explicitly to the existing local Worker when AWS/network is unavailable. Schema or input errors do not silently fall back.
- `infra/shadedebt-lambda.yaml`: Lambda, limited basic logging role, reserved concurrency 2, CORS constrained to the exact Amplify HTTPS origin, and **both** public Function URL invoke permissions needed since October 2025.
- `scripts/build-lambda.mjs`, `scripts/package_lambda.py`, `scripts/package_amplify.py`, `scripts/deploy_lambda.sh`, `scripts/smoke_cloud.py`.
- Optional ODbL-attributed public stop data pipeline (`scripts/import_osm_delhi.py`); private Kaggle stops are never bundled.

## A. Verify on developer machine

Node.js >=20.19 and Python3. In your **existing Phase 4 repository**, preserve uncommitted work and the private `local-data/` directory. Apply the incremental Phase 5 patch or merge full source archive.

```sh
npm install
npm run check
npm test
npm run smoke:offline
npm run build
npm run build:lambda
npm run package:amplify
```

**Commit generated `package-lock.json`** so Git-connected Amplify can run the existing `npm ci` command reproducibly. The source archive does not contain a generated lockfile because packages could not be fetched in the packaging environment. For manual Amplify uploads, deploy the locally built `build/shadedebt-amplify.zip`, not the source ZIP.

## B. Deploy Lambda on AWS

### Console route (no CLI setup required)

1. AWS Lambda Console → Create function → Author from scratch → `shadedebt-optimize` → **Node.js 22.x** → execution role with basic CloudWatch Logs permissions only.
2. Code → Upload from → `.zip file`: select `build/lambda/lambda.zip`. The ZIP root must contain `index.mjs`.
3. Runtime settings → Handler `index.handler`; memory **512 MB**; timeout **25 seconds**; reserved concurrency **2**.
4. Configuration → Function URL → create → Auth type **NONE**. Configure **CORS at Function URL only**: Allowed origin is exactly your Amplify HTTPS domain (without a trailing slash); allowed methods GET, POST; allowed header `content-type`; max age 300 seconds. Do not manually emit additional `Access-Control-Allow-Origin` from handler.
5. Confirm the resource-based policy permits **both** `lambda:InvokeFunctionUrl` and `lambda:InvokeFunction`, with the latter restricted to `lambda:InvokedViaFunctionUrl`. The provided CloudFormation template handles this automatically; console flows may vary.
6. Verify `https://<function-url>/health` returns JSON with `phase3-translation-grid-v1`.
7. Do not send your AWS credentials or access keys to ChatGPT. Set an AWS Budget alert in your account and watch the function's CloudWatch invocation/error metrics. Reserved concurrency alone is not a per-user rate limiter. A public URL can still be abused; consider disabling it once judging ends.

### Optional CLI/CloudFormation route

Prerequisites: authenticated AWS CLI, a **private S3 bucket you own** in the deployment region, permissions to upload an object and deploy a CloudFormation stack with an IAM execution role.

```sh
export AWS_REGION=ap-south-1
export SHADEDEBT_UPLOAD_BUCKET='YOUR_EXISTING_PRIVATE_BUCKET'
export SHADEDEBT_AMPLIFY_ORIGIN='https://main.YOUR-AMPLIFY-ID.amplifyapp.com'
bash scripts/deploy_lambda.sh
```

The script uploads a content-hashed Lambda ZIP to S3 (ensuring stack updates actually deploy changed code). The stack output lists `OptimizerUrl`. AWS resources are not created merely by downloading the ZIP.

## C. Deploy the real frontend to Amplify

Your Phase 0 Amplify smoke page is **not** the production app. After Lambda deployment:

1. Create local `.env.production` containing only `VITE_SHADEDEBT_API_URL=https://YOUR-LAMBDA-FUNCTION-URL/`. No AWS credentials are needed or allowed in the frontend.
2. Re-run `npm run build && npm run package:amplify`. Confirm `build/shadedebt-amplify.zip` contains `index.html` at the ZIP root.
3. In AWS Amplify, deploy the production ZIP through the manual static deployment workflow. Use the same site hostname allowed by Lambda's Function URL CORS configuration. If its hostname changes, update allowed origins on Lambda.
4. In a clean browser, verify the map renders, custom site works, the 6 shapes work, SunCalc calculations work, search shows **AWS LAMBDA**, and recommendation Preview → Apply updates live metrics.
5. Test an invalid candidate, cancel an in-flight search, and block the Lambda URL temporarily; the application must identify the local Worker fallback instead of claiming a cloud run.
6. Run `SHADEDEBT_API_URL='https://your-function-url/' python3 scripts/smoke_cloud.py` to verify actual AWS HTTP handling. This command cannot run before Lambda is deployed.

## D. Public stop data — optional, explicit import

The Kaggle-derived `local-data/stops.json` cannot be redistributed in this build without resolving source-level database rights. The public site retains Custom Site and JSON upload. To populate a published geographical catalogue from an independently attributed OSM source, **optionally** run:

```sh
python3 scripts/import_osm_delhi.py
# Or supply an Overpass JSON export you have acquired:
python3 scripts/import_osm_delhi.py downloaded-overpass.json
npm run build
npm run package:amplify
```

This fetches **named bus-stop nodes**, not verified active shelters, in a Delhi/NCR bounding box. The generated `public/data/delhi-stops.json` and `public/data/LICENSE-DATA.txt` are ODbL-attributed public artifacts. The number of locations is determined by the actual downloaded records, not an invented 6,880 production count. `vite.config.ts` serves the private Kaggle file **only** during development. The public importer never reads that file.

## E. Exit criteria

- Local `npm run check`, `npm test`, `npm run smoke:offline`, `npm run build` pass.
- Lambda package contains bundled dependencies and exports `handler`.
- Real AWS `/health`, valid `POST`, invalid `POST` smoke tests pass.
- The frontend served by Amplify makes an observable browser-network `POST` to Lambda and receives a versioned result.
- A cloud result agrees with the local deterministic engine for a matching test fixture.
- Stale/cancelled responses do not overwrite the latest proposal.
- Public bundle contains no AWS credentials or private Kaggle catalogue.

**Not implemented:** DynamoDB, user authentication, live temperature predictions, or formal assessment PDF. The final report and overall UX restructuring belong to Phases 6–7.
