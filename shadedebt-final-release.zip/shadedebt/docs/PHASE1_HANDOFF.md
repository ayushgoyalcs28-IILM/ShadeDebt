# Phase 1 handoff — ShadeDebt

## Upgrade instructions (preserve your local Phase 0 repository)

Preferred: from the original project repo at its Phase 0 state, apply `shadedebt-phase1.patch` using `git am /path/to/shadedebt-phase1.patch`. This preserves Git history and creates a new Phase 1 commit. The patch assumes the original Phase 0 commit and a clean working tree.

Alternative: extract the full Phase 1 source archive into the **parent** folder containing your `shadedebt/` folder, allowing it to replace same-named source files. The archive intentionally contains **no `.git`, `node_modules`, `.env`, `package-lock.json`, `dist` or generated Delhi database**. Your existing Git repository and installed dependencies are not deleted.

After applying:

```bash
npm install
npm run check
npm test
npm run build
npm run dev
```

Visit `http://localhost:5173`, select **Site selector**, and scroll below the Phase 0 site form to the **Phase 1 Solar Geometry Workbench**.

### Functional verification checklist

1. Default Delhi scene with illustrative 8×3m waiting zone appears. This must not claim to be a site survey.
2. Changing latitude/longitude changes solar altitude and azimuth; a western afternoon sun should cast **eastward** shadows.
3. Scrubbing the time control visibly moves the shadow polygon while metrics reflect the selected 12:00–17:00 time window.
4. Change the proposed canopy circle ↔ rectangle. Its shadow outline and computed metrics should both change.
5. Move proposed canopy in the east/west direction and change height. Geometry and metrics must respond.
6. Reload; the original Phase 0 overview and site selector must still work.
7. Confirm `npm run check`, `npm test` and `npm run build` all succeed. These are the project-side dependency integration and build gates; they have **not been executed with the actual npm packages in this restricted build environment**.

Expected suite: **37 tests across 6 files** (4 Phase 0 smoke + 3 Phase 0 geometry + 30 Phase 1 engine). The count is a target, not a claim the real npm suite ran in this environment.

If you receive an error, send the **full first error**, command, Node version, and screenshot of the Site selector view. No need to send credentials.

### Notes

- Full draggable/click-to-draw 6-shape editor is **Phase 2**; Phase 1 includes the reusable geometry core plus limited circle/rectangle live control.
- Baseline and proposal use a fixed sample roof layout in concept mode. Actual stop geometry remains user-supplied in Phase 2.
- The local workbench is **not AWS-deployed yet**. Phase 0 hosted smoke page confirms account access, not the Phase 1 React deployment.
- `src/data/stops.json` remains empty intentionally until full database redistribution permission is established. Existing importer is unchanged.
