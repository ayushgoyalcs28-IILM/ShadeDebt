# Phase 4 — Delhi Explorer and isolated site drafts

## What changed

- **Delhi Explorer** replaces the original Phase 3 site-selector form, retaining a clearly accessible Custom Site mode and the original Phase 1 diagnostic workbench in a collapsed advanced section.
- Geographical map: Leaflet + attributed OpenStreetMap tiles; zoom controls; source-identity-preserving stop selection; fast in-view screen-cell aggregation instead of thousands of independently mounted marker icons.
- Search by stop name (at least two characters). Same-name stops at different coordinates are displayed separately. Clicking a map marker highlights the location; clustered locations zoom in or open the corresponding search results for precise selection.
- **Open in Shade Laboratory** passes name/coordinates and a stable source-backed stop key. The existing SunCalc simulation, edit canvas, current-day handling, Phase 3 placement assistant and metrics are not rewritten.
- Site drafts use source-specific keys and are flushed immediately on editor unmount; the previous coordinate-only key is migrated at most once to prevent two stops accidentally inheriting the same old draft.
- Custom coordinates remain available, including if the map or catalogue is inaccessible.

## Data handling and user expectations

`local-data/stops.json` is historical, Kaggle-derived location data that has not had its entire database redistribution rights independently verified. **Do not commit or deploy that file**. It is `.gitignore`d and only served through `vite.config.ts` development-only middleware (`apply:'serve'`). A production visitor can import a processed, authorized JSON catalogue in the browser or use a Custom Site. No stop catalogue is embedded in the application bundle.

The user-supplied JSON is parsed locally, not uploaded. The adapter enforces a 6 MB file size cap, numeric geographic coordinates, limited record/text lengths, source identity and duplicate handling. Search results are geography, not proof that a shelter currently exists. Exact source coordinates/IDs are preserved; almost-coincident records are not merged by rounding.

OSM tiles require network access; if blocked, a warning appears and the list remains operational. The map includes OpenStreetMap attribution. A future licensed citywide static feed may be integrated without changing the selection contract.

## Local acceptance

1. Apply the Phase 4 patch on a **clean Phase 3 repository** or extract the full source ZIP. Keep your existing `package-lock.json`, `node_modules`, and private `local-data` directory.
2. Restore your authorized `local-data/stops.json` (the separate Phase 2 local-data archive) only if it is not already present.
3. Run:

   ```sh
   npm install
   npm run check
   npm test
   npm run smoke:offline
   npm run build
   npm run dev
   ```

4. Open **Delhi Explorer**. In local dev, confirm `6,880` available historical geographic locations (if using the audited Kaggle file). Search `11 Murti`; multiple same-name locations should appear. Click a list result; the map should focus it. Click **Open in Shade Laboratory**.
5. Change canopy geometry, return to Delhi Explorer and choose a different stop; confirm the new stop starts with its own site draft. Return to the first stop; confirm its previous edit is still present.
6. Import a different user-owned processed stop catalogue and verify map/list selection work; **Custom Site** must remain functional without any catalogue or when map tiles fail.
7. Verify the existing shape editor, current Delhi date, animated sun, ShadeDebt metrics, Phase 3 optimizer and geometry tests still work.

## Known limitations

- This is a site-entry improvement, **not** a citywide shelter-quality audit. GTFS/Kaggle records do not contain shelter footprint geometry.
- Browser geometry drafts remain local to the device/browser. They are not synced across devices (cloud persistence follows in Phase 5).
- Browser tile downloads require availability of the OpenStreetMap tile server and observance of its usage policy. For large-scale public deployments, choose an appropriate production tile provider or host your own licensed tiles.
- In this build environment, a real npm dependency install / Vite build cannot be run; source parsing, standalone data tests and offline regression checks were run. **Your local `npm run check`, `npm test`, and `npm run build` remain mandatory.**

## Next boundary

Phase 5 is the first production deployment of the **actual** ShadeDebt application with a meaningful AWS integration. Phase 6–7 will review the presentation and report flow end to end. No Phase 5 AWS services have been deployed during Phase 4.
