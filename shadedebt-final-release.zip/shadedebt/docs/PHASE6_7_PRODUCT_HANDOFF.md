# ShadeDebt — Product simplification and visual release

This release was built directly from the developer-uploaded **working Phase 5 repository**. It deliberately does not modify the solar geometry, shade metrics, Lambda handler, cloud client, optimization engine, AWS infrastructure, or package-lock.

## What the first-time user sees

1. **Live studio first.** A self-contained illustrative Delhi scenario loads immediately. There is no mandatory onboarding or overview screen.
2. **See and change shade.** The sun-driven top-down diagram is the centerpiece. The user selects a circular/rectangular roof, drags it, changes its size or height, and scrubs time. Four more shapes are available through `More shapes`.
3. **Read one conclusion.** The comparison shows the existing and proposed **time-averaged direct-beam shade coverage**, the change in percentage points, and a short verdict. ShadeDebt and graph are secondary under `How the shade changes…`.
4. **Find a better position.** The existing cloud/local optimizer, constraints, Preview → Apply and error handling remain unchanged. No new optimizing physics was introduced.
5. **Get assessment.** This opens a clean one-page report; it no longer auto-triggers the print dialog. The user explicitly chooses Print / Save PDF.

Location search remains available via **Choose a location**, without requiring a catalog to try the simulator. Existing site-specific drafts are preserved. Actual site geometry is still requested from the user and labeled unverified; the illustrative sample is never presented as a surveyed shelter.

## Visual design

The previous dark dashboard is replaced by a light architectural canvas, with useful shade in green, sun exposure in amber, and only one primary action in each part of the studio. The physics-derived shadows, scale and north orientation remain model driven. Technical coordinates, constraints, additional geometry inputs, roof type and detailed time graph are still available without occupying the main journey.

## Source delta

- `src/App.tsx` — removes the marketing-first overview from the navigation, starts in the working studio, makes map selection optional.
- `src/components/ShadeLab.tsx` — simplifies primary controls and result explanation, hides secondary chart, keeps the API/optimizer path; report opens before print.
- `src/engine/editor.ts` — shifts only the **illustrative** proposed canopy's default x position to avoid starting the example with a physical footprint collision. Calculation functions unchanged.
- `src/styles/studio.css` — new responsive visual surface, main-site and print layout.
- `src/main.tsx` — imports the new CSS after legacy styles to protect older explorer behavior.
- `tests/studio-experience.test.tsx` — render and default-geometry contract checks.

## Release checklist

On a developer machine with normal platform-native dependencies:

```bash
npm ci
npm run check
npm test
npm run build
npm run build:lambda
npm run dev
```

**Browser acceptance:**

- Open the root and verify that the Studio is visible immediately with the illustrative scenario.
- Drag the canopy, change roof dimensions and scrub time. The shadow and current shade fraction should change together.
- Switch Before / With design. Both views must use the same site/date/time.
- Open `More shapes`, select a freeform roof, edit site measurements and ensure prior site drafts continue to work.
- Run Find best placement and confirm AWS origin if `VITE_SHADEDEBT_API_URL` is configured. Preview must not mutate the design; Apply must.
- Open Get assessment, confirm it shows the same baseline/proposal metrics; optionally print/save it.
- Choose a location and return to the Studio; check per-stop draft isolation.
- Verify a fresh Amplify deployment by checking JS bundle fingerprint and actual Lambda requests, not merely a cached page.

## AWS deployment

Keep the developer's existing `.env.production` **locally**: it contains the public Lambda URL configuration. It is intentionally excluded from downloadable source packages. Recreate it as needed:

```
VITE_SHADEDEBT_API_URL=https://YOUR-AWS-FUNCTION-URL/
```

Then `npm run build && npm run package:amplify`, and upload the generated distribution ZIP through Amplify. **The Lambda backend does not need redeploying** for this presentation-only release. Review the account's AWS build configuration and do not publish secrets. Keep the Kaggle historical catalogue out of public distribution until source rights are verified.

## Scientific boundary

Coverage refers to the fraction of the user-defined waiting-area footprint shaded by the modelled *direct solar beam*, averaged across evaluable samples in the chosen local time interval. A higher number is not proof of lower measured temperature or construction safety. Sun angles and canopy shadows use the existing Phase 1 engine; Phase 3 continues the same bounded placement search. The report preserves the actual units and caveats.

## Verification caveat

The provided project came with macOS ARM optional native npm binaries. In the Linux build container, TypeScript checks pass but real Vitest/Vite commands cannot run because Rollup's Linux native binary is unavailable; there is no network access to install it. The release must pass `npm ci`, tests, browser checks and a clean Amplify production deployment on the developer's machine before being described as production-verified.
