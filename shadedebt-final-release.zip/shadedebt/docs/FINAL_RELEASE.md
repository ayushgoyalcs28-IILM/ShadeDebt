# ShadeDebt — final product revision

This release is based on the user's uploaded `shadedebt-phase6-7-source.zip` (not the older Phase 5 files). It preserves the existing solar, shadow, polygon and daily optimization engines while replacing the public-facing product flow.

## User journey

1. Landing introduction → Open Shade Lab.
2. Search for a bus stop in a pre-installed authorized catalogue, import a catalogue, or use the explicitly illustrative Delhi site.
3. On selecting a stop, the app requests the nearest mapped road way from the OpenStreetMap Overpass service, estimates its **undirected road axis** from the nearest segment, and automatically aligns the model. This is **not a measured shelter bearing**. On lookup failure the app shows that orientation is unverified. The site model is never falsely labelled surveyed.
4. Enter existing shelter/waiting-zone dimensions in a single collapsible panel.
5. Create one custom canopy polygon by clicking corners (3–8), drag its roof or corners, and set height. The 2.5D stage projects the roof in elevation, its geometric ground shadow and matching incident sunlight rays. There are no additional material/heat claims.
6. Before = original roof only; After = custom replacement roof only. All metrics use the same date, location, waiting footprint, time period (12–5 IST).
7. Year-round placement study = **12 monthly dates from today's Delhi date, each sampled at 12:30, 13:30, 14:30, 15:30 and 16:30 IST**. Every candidate placement uses all the same solar samples. The roof's shape, size, height and orientation remain fixed. Coarse 2-metre grid, then 1-metre and quarter-metre local refinement, <=120 valid candidates. Best tested sampled-year average; not a continuous annual optimum.
8. An assessment shows direct-shade coverage with measurement/source limitations.

## Source provenance

- Transit coordinates from the prior local-development dataset are not published by this package. The existing OSM importer produces an ODbL-labelled public catalogue if run before production building. Or import a properly licensed stop JSON through the UI.
- On-demand orientation requests go to an OpenStreetMap Overpass public endpoint only when the user selects a stop. Results are cached locally for 30 days. The service can be unavailable or rate-limited; in that case the model displays an unverified orientation. It is inappropriate to represent this as automatically surveyed shelter geometry.
- The model is geometry only: roof height, flat opaque canopy, level ground, and direct-beam sun. No weather, heat-transfer, structural approval, actual roof alignment or human thermal comfort is calculated.

## Deployment: update BOTH the frontend and Lambda

1. Preserve your existing `.env.production` and AWS settings. Never commit cloud secrets.
2. `npm ci && npm run check && npm test && npm run build`.
3. `npm run build:lambda`; replace the code ZIP of your **existing Lambda function** with `build/lambda/lambda.zip`. No CORS or Function URL change is needed. Existing v1 search remains supported; the new POST `apiVersion: shadedebt-optimize-year-v1` uses the same URL.
4. For OSM bus stops in production: `python3 scripts/import_osm_delhi.py` with network access and applicable ODbL attribution, then run the frontend build again. If not installed, the user-provided stop JSON importer and illustrative Delhi site are available.
5. `npm run build && npm run package:amplify`; upload the archive to the existing Amplify app, retaining the real Lambda HTTPS URL in `VITE_SHADEDEBT_API_URL`.
6. `SHADEDEBT_API_URL="https://YOUR-FUNCTION-URL/" python3 scripts/smoke_cloud.py` tests both the original daily AWS endpoint and the new yearly endpoint (60 sun positions), plus invalid input rejection. Test a real AWS yearly request, not just health and the old optimizer. If the old Lambda bundle has not yet been redeployed, annual search explicitly falls back to a local Worker and labels the result accordingly.
7. Verify React entry, room dimensions, all stages of custom shape drawing, same date/metrics in Before and After, annual Preview/Apply, report and print; check desktop and mobile sizes, browser console and network.

## Checks done in this handoff

- `tsc -b` and `tsc --noEmit -p tsconfig.lambda.json`: passed.
- Independent Node tests with actual installed solar + polygon dependencies: v1 and v2 Lambda HTTP 200; invalid v2 input HTTP 422; 12 dates/60 sun positions; annual model repeatable; geometric sun-ray projection reversible; road bearing computed for synthetic roads.
- Full Vite/Vitest execution was unavailable in the creation container because the archived node_modules hold only macOS-native Rollup/esbuild binaries and external npm downloads were blocked. Local testing is a required release gate, not claimed complete.
- Local Chromium refused navigation with an administrator block. Visual interaction acceptance remains to be done in the user's browser after Vite build.

## Things intentionally not added

No new material scoring, tree canopy heat physics, building simulations, route planning, full 3D renderer, cloud accounts, calendar picker, or new database. Existing underlying calculation APIs are preserved.
