# Phase 2 — Shade Laboratory handoff

## What changed from Phase 1

This update preserves all original Phase 0 and Phase 1 source modules and their test files. It adds a *draft authoring layer* (`src/engine/editor.ts`), a full interactive studio (`src/components/ShadeLab.tsx`), a production-safe catalogue adapter, and meaningful assessment views. The existing Phase 1 diagnostic workbench is still accessible under **Site selector → Advanced: original verification workbench**. It is collapsed by default so it does not compete with the product experience.

### Site selection

In development, the local-only endpoint `/__shadedebt_local_stops.json` serves the separately supplied and previously audited 6,880-location catalogue from `local-data/stops.json`. Try searching for a name in **Site selector** (at least two characters), then choose a location. This supplies its geographic coordinates, *not* measured shelter geometry.

The Kaggle-derived database has unresolved upstream redistribution permissions: `local-data/` is `.gitignore`d; the development endpoint is not included in a production bundle. In the hosted app, bring your own authorized `stops.json` via the **Import stop catalogue** input, or choose a custom site. Do not commit or publish the local dataset until rights are verified.

### Authoring and simulation

1. **Shade Laboratory** opens with a deliberately labeled illustrative site. Change the location from Site selector.
2. **Site setup tab:** set waiting-area size and bearing, existing shelter dimensions, optional solid rectangular building, date and time window, and illustrative/user-measured input label.
3. **Intervention tab:** select rectangle, circle, triangle, trapezoid, hexagon or freeform; edit position, rotation, height and size, or drag roof/waiting-zone/building in the plan view. Freeform shows five draggable corners. The editor rejects self-crossing geometry.
4. Switch **Existing / With proposal**, then scrub or play time. Observe the polygon shadows, usable shade clipped to the waiting area, actual solar compass bearing, ground shadow shift and linked side section.
5. Compare **ShadeDebt reduction**, average shade coverage, selected instant coverage, canopy-area efficiency, and the time series. Read the explanatory assessment and scientific limitations. The parameters are saved automatically in this browser's local storage for this location.
6. **Reset** returns the example geometry. The Phase 2 tool does *not* automatically optimize; that belongs to Phase 3. The print-ready intervention report is planned for Phase 6.

### Source installation on the existing project

**Preferred: Git patch against Phase 1**, preserving your own working tree and Git history. Commit or stash your uncommitted work first.

```bash
git status --short
git apply --check /path/to/shadedebt-phase2.patch
git apply /path/to/shadedebt-phase2.patch
npm install
npm run check
npm test
npm run build
npm run dev
```

The patch does **not** include the license-unverified local stop dataset. Restore it from the separately provided private `shadedebt-phase2-local-data.zip` by unzipping into the repo root, or from the previous dataset review package by copying `src/data/stops.json` into `local-data/stops.json` (not into production `src/data/`).

Alternatively, extract the full source ZIP into a *new directory* for a separate clean test. The source ZIP contains the private local development catalogue and excludes `.git`, `node_modules`, secrets, build outputs and your local lockfile. The existing project's `package-lock.json` is intentionally preserved when applying the patch.

### Acceptance gate

```bash
npm run smoke:offline  # 8 offline Phase 0 + Phase 2 structural/privacy checks
npm run check          # actual installed dependency TypeScript type check
npm test               # original suite + 12 new Phase 2 numerical integration tests
npm run build          # Vite production bundle with no locally staged Kaggle stops
npm run dev
```

Expected Vitest test count: **53** if the original Phase 1 suite contains 37 as previously delivered and Vitest discovers the new 12 editor tests and four Phase 2 offline checks. The authoritative count is your local `npm test` output, not this estimate.

### Manual product test sequence

- Search for a real Delhi-area stop locally; select it. Verify name and coordinates appear in Shade Lab while geometry remains flagged as illustrative.
- Toggle all six canopy shapes; use **Circle**, scrub noon → 5pm, and confirm the ground shadow moves with solar bearing.
- Change roof height; the linked section, roof-to-shadow distance and shaded overlap must update. Set a higher roof and lower afternoon sun for a larger displacement.
- Drag the proposed roof and then a custom polygon vertex. Attempt to cross its edges; the editor should reject the edit without corrupting geometry.
- Compare **Add** vs **Replace** and verify the metrics and assessment differ. In Add mode the proposal cannot reduce direct-beam shade (overlap is counted only once).
- Change date and time window in Site setup, return to Intervention, play the timeline, verify labels and chart follow the new window.
- Enable nearby building; notice the background building shadow already contributes to baseline coverage. Move it and inspect the change.
- Drag a proposal into the road; an explicit placement warning should appear. This is advisory in Phase 2, not a structural safety certification.
- Navigate away and back to the same site; your draft should be retained through local storage. Press Reset to return to the example.
- Open **Advanced** Phase 1 workbench to confirm the old interface remains available.
- Build production; the Kaggle-derived stop records must not be bundled; custom site and user-file import still work.

### Known model boundaries

Horizontal, opaque, flat roofs; level ground; direct-beam geometry only. Buildings are opaque, solid, *convex* vertical prisms. The waiting area is rectangular in Phase 2. Nearby trees and materials are not scored. No pedestrian footfall, thermal comfort, construction cost, wind, structural safety or measured temperature is inferred. The section view is explanatory, not an engineering elevation drawing. Location alone does not produce measured roof dimensions.

### Verification performed by assistant

- Original Phase 1 computational modules and original test files compared byte-for-byte and left unchanged.
- Eight Phase 0/Phase 2 offline structural/privacy tests passed.
- New authoring geometry compiled with globally available TypeScript and was exercised against its pure geometry conversion functions.
- Source parsing checked with TypeScript compiler tooling.
- Full npm / React browser integration still requires your actual installed dependencies and `npm run check`, `npm test`, `npm run build` acceptance.
