# Phase 0 execution status

Checked 2026-10-11, Asia/Kolkata.

| Item | Status | Evidence / next action |
|---|---|---|
| Project structure + React/TypeScript sources | DONE | `src/`, `package.json`, `tsconfig*.json`, Vite config |
| Local git history | DONE | initial commit generated in this project |
| Dependency versions specified | DONE | exact solar/polygon versions in package.json |
| npm dependencies installed | BLOCKED | execution container cannot resolve registry.npmjs.org; user must run `npm install` on internet-connected computer |
| Vite React build executed | BLOCKED | depends on npm installation; do not claim build success |
| Offline smoke tests | DONE | Node built-in tests execute without network |
| Static Amplify manual upload artifact | DONE | separate `shadedebt-amplify-smoke.zip` available alongside repo |
| Actual Amplify deployment | BLOCKED | no AWS credentials / user-console session exposed to assistant |
| Delhi GTFS published source identified | DONE | OTD Delhi 3,464 stops, June 20 2024 |
| Delhi stop archive downloaded & parsed | BLOCKED | no network to fetch official or mirror archive; importer ready |

## Key constraint
The static smoke artifact is a Phase 0 connectivity check, not a working solar simulator. The React codebase is the actual product scaffold; it has not yet been installed or built here. These are kept separate to avoid falsely passing a deployment test.

## Gate to exit Phase 0
1. On a computer with internet: `npm install`, `npm run check`, `npm test`, `npm run build`.
2. For the real stop catalogue: download official GTFS from https://otd.delhi.gov.in/data/static/ and run `python3 scripts/import_gtfs_stops.py /path/to/GTFS.zip --source official-otd`.
3. Upload `shadedebt-amplify-smoke.zip` manually to AWS Amplify; confirm live URL. Then build and deploy the actual React app when dependencies are installed.

Security: do not send AWS access keys or secrets in chat or commit them to Git. Use console login or locally configured IAM credentials.
