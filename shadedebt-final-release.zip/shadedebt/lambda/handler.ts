/** SHADEDEBT PHASE 5 — compute-only Lambda API.
 * Bundles the exact same deterministic optimizer used in the browser Worker.
 * Function URL CORS is configured in AWS, not duplicated by this handler.
 */
import { optimizeScenario, type OptimizerOptions } from '../src/engine/optimizer';
import { assertScenario } from '../src/engine/validation';
import { todayInDelhi } from '../src/engine/date';
import { optimizeYear, YEARLY_MODEL_VERSION } from '../src/engine/yearly';
import type { InterventionScenario } from '../src/types/domain';

export const MODEL_VERSION = 'phase3-translation-grid-v1';
export const API_VERSION = 'shadedebt-optimize-v1';
export const YEARLY_API_VERSION='shadedebt-optimize-year-v1';
const MAX_BODY_BYTES = 64 * 1024;
const MAX_TOTAL_POINTS = 700;
const DEFAULT_OPTIONS = { coarseStepM: 1, fineStepM: .25, refineRadiusM: .75, maxEvaluations: 750 } as const;

export interface LambdaHttpEvent {
  rawPath?: string;
  requestContext?: { http?: { method?: string; path?: string } };
  headers?: Record<string, string | undefined>;
  body?: string | null;
  isBase64Encoded?: boolean;
}
export interface LambdaHttpResponse { statusCode: number; headers: Record<string,string>; body: string; }
const respond = (statusCode:number, body:unknown):LambdaHttpResponse=>({
  statusCode,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'},body:JSON.stringify(body)
});
class RequestError extends Error {
  constructor(public readonly status: number, message: string) { super(message); }
}
const record = (value:unknown):value is Record<string,unknown> =>
  Boolean(value) && typeof value==='object' && !Array.isArray(value);
const boundedAnchor = (v:unknown):v is [number,number] =>
  Array.isArray(v) && v.length===2 && v.every(x=>typeof x==='number' && Number.isFinite(x) && Math.abs(x)<=10000);

function parseRequest(event:LambdaHttpEvent):{scenario:InterventionScenario;options:OptimizerOptions;yearly:boolean} {
  if (typeof event.body!=='string') throw new RequestError(400,'Request requires a JSON body.');
  let raw: string;
  if(event.isBase64Encoded){
    // Lambda Function URL bodies are typically already decoded, but the event flag is authoritative.
    if(event.body.length>MAX_BODY_BYTES*2)throw new RequestError(413,'Request is too large.');
    raw=Buffer.from(event.body,'base64').toString('utf8');
  } else raw=event.body;
  if(Buffer.byteLength(raw,'utf8')>MAX_BODY_BYTES)throw new RequestError(413,'Request is too large.');
  let parsed:unknown;
  try{parsed=JSON.parse(raw);}catch{throw new RequestError(400,'Malformed JSON.');}
  if(!record(parsed) || ![API_VERSION,YEARLY_API_VERSION].includes(String(parsed.apiVersion)) || !record(parsed.options) || !record(parsed.scenario)){
    throw new RequestError(400,'Expected a versioned scenario and options.');
  }
  const yearly=parsed.apiVersion===YEARLY_API_VERSION;
  const scenario=parsed.scenario as unknown as InterventionScenario;
  const inputOptions=parsed.options;
  if(!boundedAnchor(inputOptions.anchor))throw new RequestError(422,'Optimizer anchor must be a finite [east,north] pair.');
  // The client cannot override our search budget or attempt pathologically fine grids.
  for(const key of ['coarseStepM','fineStepM','refineRadiusM','maxEvaluations'] as const){
    if(inputOptions[key] !== undefined && inputOptions[key] !== DEFAULT_OPTIONS[key]){
      throw new RequestError(422,`Unsupported optimization setting: ${key}.`);
    }
  }
  try { assertScenario(scenario); }catch(e) {
    throw new RequestError(422,e instanceof Error?e.message:'Invalid geometry.');
  }
  if(scenario.proposedCanopies.length!==1)throw new RequestError(422,'Exactly one proposed canopy is required.');
  const site=scenario.site;
  // A public Function URL must reject pathological site envelopes even when the
  // underlying offline optimizer supports broader engineering research.
  const zoneX=site.allowedConstructionZone.map(([x])=>x);
  const zoneY=site.allowedConstructionZone.map(([,y])=>y);
  const spanX=Math.max(...zoneX)-Math.min(...zoneX);
  const spanY=Math.max(...zoneY)-Math.min(...zoneY);
  if(spanX>45 || spanY>45 || spanX*spanY>1500)throw new RequestError(422,'Construction search envelope exceeds cloud service limits (45 m per axis; 1500 m² bounding rectangle).');
  const clockMinutes=(v:string)=>Number(v.slice(0,2))*60+Number(v.slice(3,5));
  const steps=Math.ceil((clockMinutes(scenario.endTimeIST)-clockMinutes(scenario.startTimeIST))/scenario.sampleMinutes);
  if(steps>60 || site.baselineCanopies.length>4 || site.buildings.length>2 || site.exclusionZones.length>5){
    throw new RequestError(422,'Scenario is too complex for the public optimization endpoint.');
  }
  const points = site.waitingArea.length + site.allowedConstructionZone.length +
    site.baselineCanopies.reduce((n,c)=>n+c.footprint.length,0)+
    site.buildings.reduce((n,b)=>n+b.footprint.length,0)+
    site.exclusionZones.reduce((n,z)=>n+z.length,0)+
    scenario.proposedCanopies[0].footprint.length;
  if(points>MAX_TOTAL_POINTS)throw new RequestError(422,'Too many geometric vertices.');
  if(scenario.endTimeIST===undefined)throw new RequestError(422,'Missing analysis time.');
  if(yearly && (site.buildings.length>0 || site.exclusionZones.length>2 || scenario.mode!=='replace' || scenario.startTimeIST!=='12:00' || scenario.endTimeIST!=='17:00'))throw new RequestError(422,'Annual study requires replacement mode, noon–5 PM, and simplified site geometry.');
  return {scenario,options:{...DEFAULT_OPTIONS,anchor:inputOptions.anchor},yearly};
}

/** Input is an AWS Lambda Function URL event. All processing is stateless; no credentials required. */
export async function handler(event:LambdaHttpEvent):Promise<LambdaHttpResponse>{
  const method=event.requestContext?.http?.method?.toUpperCase()??'';
  const path=event.rawPath??event.requestContext?.http?.path??'/';
  if(method==='GET' && (path==='/' || path==='/health'))return respond(200,{ok:true,apiVersion:API_VERSION,modelVersion:MODEL_VERSION,service:'ShadeDebt Optimization',delhiDate:todayInDelhi()});
  if(method==='OPTIONS')return {statusCode:204,headers:{'Cache-Control':'no-store'},body:''};
  if(path!=='/' && path!=='/optimize')return respond(404,{ok:false,error:'Not found.'});
  if(method!=='POST')return respond(405,{ok:false,error:'Use POST for optimization.'});
  const headers=Object.fromEntries(Object.entries(event.headers??{}).map(([k,v])=>[k.toLowerCase(),v]));
  if(!String(headers['content-type']??'').toLowerCase().startsWith('application/json')){
    return respond(415,{ok:false,error:'Content-Type must be application/json.'});
  }
  try{
    const {scenario,options,yearly}=parseRequest(event);
    if(yearly){
      const result=optimizeYear(scenario,options.anchor,120);
      return respond(200,{ok:true,apiVersion:YEARLY_API_VERSION,modelVersion:YEARLY_MODEL_VERSION,result});
    }
    const result=optimizeScenario(scenario,options);
    return respond(200,{ok:true,apiVersion:API_VERSION,modelVersion:MODEL_VERSION,result});
  }catch(error){
    if(error instanceof RequestError)return respond(error.status,{ok:false,error:error.message});
    // Preserve request safety; internal errors are logged without exposing the scenario.
    console.error('ShadeDebt optimization failed',error instanceof Error?error.message:'Unknown error');
    return respond(500,{ok:false,error:'Optimization service failed. Please retry.'});
  }
}
