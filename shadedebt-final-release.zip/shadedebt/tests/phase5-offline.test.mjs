import { test } from 'vitest';
import assert from 'node:assert/strict';
import { readFileSync,existsSync } from 'node:fs';
const read=path=>readFileSync(path,'utf8');
test('Phase 5 cloud service calls Phase 3 optimizer without reimplementing shade physics',()=>{
  const backend=read('lambda/handler.ts');
  assert.match(backend,/import \{ optimizeScenario/);
  assert.match(backend,/assertScenario\(/);
  assert.doesNotMatch(backend,/Math\.tan\(/);
});
test('compute endpoint validates bounded requests and exposes no IAM credentials',()=>{
  const backend=read('lambda/handler.ts');
  assert.match(backend,/MAX_BODY_BYTES/);assert.match(backend,/MAX_TOTAL_POINTS/);
  assert.match(backend,/RequestError\(413/);assert.match(backend,/DEFAULT_OPTIONS/);
  assert.doesNotMatch(backend,/AWS_ACCESS_KEY_ID/);
});
test('frontend cloud path preserves local worker fallback, cancellation and explicit apply',()=>{
  const ui=read('src/components/ShadeLab.tsx');
  assert.match(ui,/optimizeInCloud\(/);assert.match(ui,/runLocalSearch\(/);assert.match(ui,/cloudAbortRef.current\?\.abort/);
  assert.match(ui,/Apply placement/);assert.match(ui,/Search cancelled/);
});
test('AWS deployment uses restricted concurrency and two Function URL public permissions',()=>{
  const template=read('infra/shadedebt-lambda.yaml');
  assert.match(template,/ReservedConcurrentExecutions: 2/);
  assert.match(template,/lambda:InvokeFunctionUrl/);assert.match(template,/lambda:InvokeFunction/);
  assert.match(template,/InvokedViaFunctionUrl: true/);
  assert.match(template,/AllowOrigins/);
});
test('private Kaggle catalogue remains excluded while licensed public data needs an explicit import',()=>{
  assert.match(read('vite.config.ts'),/apply: 'serve'/);
  assert.match(read('.gitignore'),/local-data\//);
  assert.ok(existsSync('scripts/import_osm_delhi.py'));
  assert.match(read('src/data/localCatalogue.ts'),/data\/delhi-stops\.json/);
  assert.deepEqual(JSON.parse(read('src/data/stops.json')),[]);
});
