import {describe,it,expect} from 'vitest';
import {yearlyDates,optimizeYear} from '../src/engine/yearly';
import {sampleDraft,toScenario} from '../src/engine/editor';
describe('yearly candidate search',()=>{
 it('produces twelve months and clamps Feb 29',()=>{
  const d=yearlyDates('2028-02-29');expect(d).toHaveLength(12);expect(d[0]).toBe('2028-02-29');expect(d[1]).toBe('2028-03-29');
  expect(yearlyDates('2026-01-31')[1]).toBe('2026-02-28');
 });
 it('scores identical monthly suns across valid candidate positions',()=>{
  const d=sampleDraft();d.comparisonMode='replace';d.proposal.shape='custom';
  const r=optimizeYear(toScenario(d),[d.proposal.x,d.proposal.y],40);
  expect(r.dates).toHaveLength(12);expect(r.sampledTimes).toBe(60);expect(r.tested).toBeGreaterThan(0);
  if(r.best&&r.current)expect(r.best.averageCoverage).toBeGreaterThanOrEqual(r.current.averageCoverage-1e-8);
 });
 it('rejects unsupported building model',()=>{const d=sampleDraft();d.building.enabled=true;expect(()=>optimizeYear(toScenario(d),[3,0],30)).toThrow();});
});
