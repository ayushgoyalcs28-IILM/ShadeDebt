import { describe, expect, it, vi, afterEach } from 'vitest';
import { optimizeInCloud, CloudOptimizationError, CLOUD_API_VERSION } from '../src/cloud/optimizer';
import { sampleDraft,toScenario } from '../src/engine/editor';
import { optimizeScenario } from '../src/engine/optimizer';
const params=()=>{const draft=sampleDraft();draft.date='2026-05-15';return {scenario:toScenario(draft),options:{anchor:[draft.proposal.x,draft.proposal.y] as const}};};
afterEach(()=>vi.unstubAllGlobals());
describe('Phase 5 frontend cloud transport',()=>{
  it('sends the versioned scenario and accepts the validated result',async()=>{
    const {scenario,options}=params();const result=optimizeScenario(scenario,options);
    const fetchMock=vi.fn(async(_url:string,init:RequestInit)=>{
      const request=JSON.parse(String(init.body));expect(request.apiVersion).toBe(CLOUD_API_VERSION);
      expect(request.scenario).toEqual(scenario);
      return {ok:true,status:200,json:async()=>({ok:true,modelVersion:'phase3-translation-grid-v1',result})};
    });
    vi.stubGlobal('fetch',fetchMock);
    expect(await optimizeInCloud('https://example.test/',scenario,options)).toEqual(result);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
  it('marks server errors as local-fallback eligible',async()=>{
    const {scenario,options}=params();vi.stubGlobal('fetch',vi.fn(async()=>({ok:false,status:503,json:async()=>({error:'Unavailable'})})));
    await expect(optimizeInCloud('https://example.test/',scenario,options)).rejects.toMatchObject({shouldFallback:true});
  });
  it('refuses incompatible server results without falling back silently',async()=>{
    const {scenario,options}=params();vi.stubGlobal('fetch',vi.fn(async()=>({ok:true,status:200,json:async()=>({ok:true,modelVersion:'wrong',result:{}})})));
    await expect(optimizeInCloud('https://example.test/',scenario,options)).rejects.toBeInstanceOf(CloudOptimizationError);
    await expect(optimizeInCloud('https://example.test/',scenario,options)).rejects.toMatchObject({shouldFallback:false});
  });
});
