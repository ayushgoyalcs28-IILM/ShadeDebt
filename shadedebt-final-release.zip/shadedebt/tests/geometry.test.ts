import { describe, expect, it } from 'vitest';
import { circlePolygon, polygonArea, validLatLon } from '../src/engine/geometry';

describe('geometry foundational contract', () => {
  it('computes area of a 8m x 3m waiting zone', () => {
    expect(polygonArea([[0,0],[8,0],[8,3],[0,3]])).toBe(24);
  });
  it('circle discretization approximates the geometric area', () => {
    expect(polygonArea(circlePolygon(2, 96))).toBeCloseTo(Math.PI * 4, 1);
  });
  it('coordinates must lie in valid geographic ranges', () => {
    expect(validLatLon(28.6139,77.209)).toBe(true);
    expect(validLatLon(91,77.209)).toBe(false);
    expect(validLatLon(NaN,77.209)).toBe(false);
  });
});
