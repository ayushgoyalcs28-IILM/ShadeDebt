import {describe,it,expect} from 'vitest';
import {nearestRoadAxis,rotateLocal} from '../src/data/roadAxis';
describe('road orientation',()=>{
 it('follows nearest road segment, orientation modulo 180',()=>{
  const r=nearestRoadAxis(28,77,[{tags:{highway:'residential'},geometry:[{lat:27.9999,lon:77},{lat:28.0001,lon:77}]}]);
  expect(r).not.toBeNull();expect(r!.bearingDeg).toBeCloseTo(0,2);
 });
 it('ignores remote street',()=>expect(nearestRoadAxis(28,77,[{geometry:[{lat:28.02,lon:77},{lat:28.03,lon:77}]}])).toBeNull());
 it('rotates physical centres without changing distance',()=>expect(Math.hypot(...rotateLocal(3,4,38))).toBeCloseTo(5));
});
