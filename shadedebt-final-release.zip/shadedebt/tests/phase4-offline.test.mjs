import { test } from 'vitest';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=process.cwd();const read=p=>readFileSync(resolve(root,p),'utf8');
test('phase 4 retains Phase 3 engine and calculator unmodified',()=>{
 for(const n of ['solar','shadows','simulation','optimizer','overlap','editor','date'])assert.ok(existsSync(resolve(root,`src/engine/${n}.ts`)));
});
test('explorer hands geographic stop ID to existing laboratory, not a new simulation',()=>{
 const app=read('src/App.tsx');
 assert.match(app,/DelhiExplorer/);assert.match(app,/ShadeLab/);assert.match(app,/activeSite\.key/);
 const explorer=read('src/components/DelhiExplorer.tsx');
 assert.match(explorer,/fromStop/);assert.match(explorer,/onOpen\(/);
});
test('production data rights restriction remains',()=>{
 assert.deepEqual(JSON.parse(read('src/data/stops.json')),[]);
 assert.match(read('vite.config.ts'),/apply: 'serve'/);
 assert.match(read('.gitignore'),/local-data\//);
 assert.doesNotMatch(read('src/App.tsx'),/import\s+stopsRaw\s+from/);
});
test('site-specific drafts are isolated and flushed on unmount',()=>{
 const lab=read('src/components/ShadeLab.tsx');
 assert.match(lab,/draftStorageKey\(identity\)/);
 assert.match(lab,/latestSavedDraft\.current/);
 assert.match(lab,/localStorage\.setItem/);
});
test('map limits markers to viewport and uses openly attributed tiles',()=>{
 const source=read('src/components/DelhiMap.tsx');
 assert.match(source,/groupStopsInViewport/);
 assert.match(source,/map\.getBounds/);
 assert.match(source,/openstreetmap\.org\/copyright/);
});
