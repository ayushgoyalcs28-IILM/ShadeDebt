import { describe, expect, it } from 'vitest';
import { todayInDelhi } from '../src/engine/date';
import { sampleDraft } from '../src/engine/editor';

describe('runtime date, Asia/Kolkata',()=>{
  it('uses Delhi calendar dates even when UTC is still the previous day',()=>{
    expect(todayInDelhi(new Date('2026-10-10T19:15:00Z'))).toBe('2026-10-11');
    expect(todayInDelhi(new Date('2026-10-10T18:29:00Z'))).toBe('2026-10-10');
  });
  it('supports leap-day and year-boundary rollover',()=>{
    expect(todayInDelhi(new Date('2024-02-28T19:00:00Z'))).toBe('2024-02-29');
    expect(todayInDelhi(new Date('2026-12-31T18:30:00Z'))).toBe('2027-01-01');
  });
  it('new sites default to the actual date in Delhi',()=>expect(sampleDraft().date).toBe(todayInDelhi()));
  it('rejects invalid system dates',()=>expect(()=>todayInDelhi(new Date(NaN))).toThrow());
});
