import {describe,it,expect} from 'vitest';
import {exampleScenario} from '../src/engine/demo';
import {simulateScenario,evaluateSunPosition} from '../src/engine/simulation';
import {rectangle} from '../src/engine/shapes';
import {assertScenario} from '../src/engine/validation';

describe('end-to-end geometric sampling and scenario semantics',()=>{
  it('calculates weighted data from a realistic sun/date for the example',()=>{
    const result=simulateScenario(exampleScenario());
    expect(result.samples).toHaveLength(20);
    expect(result.evaluatedMinutes).toBe(300);
    expect(result.metrics).not.toBeNull();
    expect(result.metrics!.averageBaselineCoverage).toBeGreaterThanOrEqual(0);
    expect(result.metrics!.averageProposedCoverage).toBeLessThanOrEqual(1);
    expect(result.metrics!.addedUsefulShadeM2Hours).toBeGreaterThanOrEqual(-1e-7);
    expect(result.modelVersion).toBe('phase1-geometry-1');
  });
  it('all-night time window produces no fabricated shade score',()=>{
    const scenario=exampleScenario();
    scenario.startTimeIST='00:00';scenario.endTimeIST='02:00';
    const result=simulateScenario(scenario);
    expect(result.metrics).toBeNull();
    expect(result.excludedMinutes).toBe(120);
    expect(result.samples.every(x=>x.status==='below-horizon')).toBe(true);
  });
  it('a partial last interval is correctly sampled',()=>{
    const scenario=exampleScenario();scenario.startTimeIST='13:00';scenario.endTimeIST='13:50';scenario.sampleMinutes=30;
    const result=simulateScenario(scenario);
    expect(result.samples.map(s=>s.durationMinutes)).toEqual([30,20]);
    expect(result.metrics?.evaluatedHours).toBeCloseTo(50/60);
  });
  it('add mode cannot reduce coverage in deterministic geometry',()=>{
    const scenario=exampleScenario();
    const west={altitudeDeg:45,azimuthDeg:270};
    const result=evaluateSunPosition(scenario.site,scenario.proposedCanopies,'add',west);
    expect(result.proposed.shadedAreaM2+1e-8).toBeGreaterThanOrEqual(result.baseline.shadedAreaM2);
  });
  it('replace mode can produce worse shade (engine must not force positive results)',()=>{
    const scenario=exampleScenario();
    scenario.site.baselineCanopies=[{id:'roof',shape:'rectangle',footprint:rectangle(8,3,[0,0]),heightM:3,opaque:true}];
    const out=evaluateSunPosition(scenario.site,[], 'replace',{altitudeDeg:90,azimuthDeg:180});
    expect(out.baseline.coverage).toBeCloseTo(1);
    expect(out.proposed.coverage).toBe(0);
  });
  it('a building already shading the zone contributes to BOTH scenarios',()=>{
    const scenario=exampleScenario();
    scenario.site.baselineCanopies=[];
    scenario.site.buildings=[{id:'building',footprint:rectangle(10,4,[0,0]),heightM:3}];
    const out=evaluateSunPosition(scenario.site,[], 'add',{altitudeDeg:45,azimuthDeg:270});
    expect(out.baseline.shadedAreaM2).toBeGreaterThan(0);
    expect(out.baseline.shadedAreaM2).toBeCloseTo(out.proposed.shadedAreaM2,8);
  });
  it('rejects invalid date, cross-midnight interval, and invalid site',()=>{
    const s=exampleScenario();s.dateISO='2026-02-30';expect(()=>assertScenario(s)).toThrow();
    const t=exampleScenario();t.startTimeIST='18:00';t.endTimeIST='06:00';expect(()=>assertScenario(t)).toThrow();
    const p=exampleScenario();p.site.latitude=100;expect(()=>assertScenario(p)).toThrow();
  });
  it('the deterministic output never changes across runs',()=>{
    const scenario=exampleScenario();
    expect(simulateScenario(scenario)).toEqual(simulateScenario(scenario));
  });
});
