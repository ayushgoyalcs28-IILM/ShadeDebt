import { describe, expect, it } from 'vitest';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import ShadeLab from '../src/components/ShadeLab';
import { readFileSync } from 'node:fs';
import { sampleDraft, outline, toScenario } from '../src/engine/editor';
import { validatePlacement } from '../src/engine/optimizer';
import { simulateScenario } from '../src/engine/simulation';

const renderStudio=()=>renderToStaticMarkup(React.createElement(ShadeLab,{latitude:28.6139,longitude:77.209,name:'Illustrative Delhi',siteKey:'test-studio'}));
describe('Phases 6–7 minimal studio regression contract',()=>{
  it('lands on the simulation rather than a marketing overview',()=>{
    const app=readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');
    expect(app).toContain("useState<'lab'|'explorer'>('lab')");
    const markup=renderStudio();
    expect(markup).toContain('See where the shade lands');
    expect(app).toContain('Choose a location');
    expect(markup).toContain('Live geometric shade simulation');
  });
  it('keeps the primary canopy choice and additional options discoverable',()=>{
    const markup=renderStudio();
    expect(markup).toContain('Circle');
    expect(markup).toContain('Rectangle');
    expect(markup).toContain('More shapes');
    expect(markup).toContain('Edit site measurements');
  });
  it('presents one primary comparison and preserves the cloud optimization action',()=>{
    const markup=renderStudio();
    expect(markup).toContain('Current shelter');
    expect(markup).toContain('With your design');
    expect(markup).toContain('Find best placement');
    expect(markup).toContain('Get assessment');
  });
  it('uses a viable illustrative geometry with a meaningful simulated comparison',()=>{
    const d=sampleDraft();
    const scenario=toScenario(d);
    expect(validatePlacement(scenario,outline(d.proposal)).valid).toBe(true);
    const r=simulateScenario(scenario);
    expect(r.metrics).not.toBeNull();
    expect(r.metrics!.averageBaselineCoverage).toBeGreaterThanOrEqual(0);
    expect(r.metrics!.averageProposedCoverage).toBeLessThanOrEqual(1);
  });
});
