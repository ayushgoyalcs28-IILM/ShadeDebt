import { describe, expect, it } from 'vitest';
import { rectangle } from '../src/engine/shapes';
import { sampleDraft, toScenario } from '../src/engine/editor';
import { simulateScenario } from '../src/engine/simulation';
import { optimizeScenario, validatePlacement } from '../src/engine/optimizer';

const scenario=()=>{const draft=sampleDraft();draft.date='2026-05-15';return toScenario(draft);};
const options={anchor:[2,-.3] as const,coarseStepM:2,fineStepM:.5,refineRadiusM:1,maxEvaluations:250};

describe('bounded placement search / Phase 3',()=>{
  it('returns deterministic valid placements and keeps the original geometry unchanged',()=>{
    const sc=scenario(),before=JSON.stringify(sc);
    const a=optimizeScenario(sc,options),b=optimizeScenario(sc,options);
    expect(a).toEqual(b);
    expect(JSON.stringify(sc)).toBe(before);
    expect(a.best).not.toBeNull();expect(a.evaluatedCandidates).toBeGreaterThan(0);
    const translated=sc.proposedCanopies[0].footprint.map(([x,y])=>[x+a.best!.anchor[0]-options.anchor[0],y+a.best!.anchor[1]-options.anchor[1]] as const);
    expect(validatePlacement(sc,translated).valid).toBe(true);
    expect(a.best!.areaM2).toBeCloseTo(a.current?.areaM2??a.best!.areaM2,5);
  });
  it('never selects a valid candidate worse than the current permitted one',()=>{
    const sc=scenario();sc.site.baselineCanopies=[];
    sc.proposedCanopies=[{...sc.proposedCanopies[0],footprint:rectangle(2,2,[1,0])}];
    const a=optimizeScenario(sc,{...options,anchor:[1,0]});
    expect(a.currentValid).toBe(true);
    expect(a.current).not.toBeNull();
    expect(a.best!.shadeDebtM2Hours).toBeLessThanOrEqual(a.current!.shadeDebtM2Hours+1e-6);
    expect(a.best!.metrics.averageBaselineCoverage).toBeCloseTo(a.current!.metrics.averageBaselineCoverage,8);
  });
  it('rejects roof positions beyond the allowed boundary and inside exclusion zones',()=>{
    const sc=scenario();
    expect(validatePlacement(sc,rectangle(2,2,[11,0])).valid).toBe(false);
    expect(validatePlacement(sc,rectangle(2,2,[0,-5])).valid).toBe(false);
    expect(validatePlacement(sc,rectangle(2,2,[6,0])).valid).toBe(true);
  });
  it('treats building and existing roof footprints as occupied in add mode',()=>{
    const sc=scenario();sc.site.buildings=[{id:'block',footprint:rectangle(2,2,[7,2]),heightM:8}];
    expect(validatePlacement(sc,rectangle(1,1,[7,2])).valid).toBe(false);
    expect(validatePlacement(sc,sc.site.baselineCanopies[0].footprint).valid).toBe(false);
    sc.mode='replace';
    expect(validatePlacement(sc,sc.site.baselineCanopies[0].footprint).valid).toBe(true);
  });
  it('does not make a fake recommendation when all positions are invalid',()=>{
    const sc=scenario();sc.site.allowedConstructionZone=rectangle(1,1,[0,0]);
    const out=optimizeScenario(sc,options);
    expect(out.best).toBeNull();expect(out.evaluatedCandidates).toBe(0);
  });
  it('does not make a recommendation without evaluable sunlight',()=>{
    const sc=scenario();sc.startTimeIST='00:00';sc.endTimeIST='02:00';
    const out=optimizeScenario(sc,options);
    expect(out.best).toBeNull();expect(out.reason).toContain('No evaluable sunlight');
  });
  it('the metrics at the returned best location agree with the unmodified Phase 1 simulation engine',()=>{
    const sc=scenario();sc.site.baselineCanopies=[];
    const candidate=optimizeScenario(sc,{...options,anchor:[2,-.3]});
    expect(candidate.best).not.toBeNull();
    const old=sc.proposedCanopies[0].footprint;
    const [nx,ny]=candidate.best!.anchor;
    sc.proposedCanopies=[{...sc.proposedCanopies[0],footprint:old.map(([x,y])=>[x+nx-2,y+ny+.3] as const)}];
    const reference=simulateScenario(sc).metrics;
    expect(candidate.best!.shadeDebtM2Hours).toBeCloseTo(reference!.proposedShadeDebtM2Hours,7);
    expect(candidate.best!.metrics.shadeDebtReductionM2Hours).toBeCloseTo(reference!.shadeDebtReductionM2Hours,7);
  });
  it('supports a custom canopy polygon without replacing shape with a bounding box',()=>{
    const d=sampleDraft();d.proposal.shape='custom';
    const sc=toScenario(d),out=optimizeScenario(sc,{...options,maxEvaluations:60});
    expect(out.best).not.toBeNull();expect(out.best!.areaM2).toBeCloseTo(5.415,3);
    expect(out.evaluatedCandidates).toBeLessThanOrEqual(60);
  });
  it('does not invent benefits where a solid building already shades the entire waiting area',()=>{
    const sc=scenario();sc.site.baselineCanopies=[];
    sc.site.buildings=[{id:'cover',footprint:rectangle(10,4,[0,0]),heightM:6}];
    const out=optimizeScenario(sc,{...options,maxEvaluations:80});
    expect(out.best).not.toBeNull();
    expect(out.best!.metrics.averageBaselineCoverage).toBeCloseTo(1,7);
    expect(out.best!.metrics.shadeDebtReductionM2Hours).toBeCloseTo(0,7);
    expect(out.reason).toContain('no positive shade benefit');
  });
  it('rejects invalid search arguments before running calculations',()=>{
    expect(()=>optimizeScenario(scenario(),{anchor:[Infinity,0]})).toThrow();
    expect(()=>optimizeScenario(scenario(),{anchor:[2,-.3],coarseStepM:0})).toThrow();
  });
});
