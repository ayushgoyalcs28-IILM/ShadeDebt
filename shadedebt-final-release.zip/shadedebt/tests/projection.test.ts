import {describe,it,expect} from 'vitest';
import {projectSitePoint,screenToSite} from '../src/engine/projection';
import {shadowDisplacement} from '../src/engine/shadows';
describe('physically tied stage camera',()=>{
 it('inverts world coordinates at the roof and at ground level',()=>{
  for(const z of [0,2.8,4.1])for(const p of [[0,0],[3,-2],[-4,3]] as const){
   const q=screenToSite(projectSitePoint(p,z),z);expect(q[0]).toBeCloseTo(p[0],10);expect(q[1]).toBeCloseTo(p[1],10);
  }
 });
 it('rays join one actual roof vertex to its predicted ground shadow',()=>{
  const roof:[number,number]=[-1,2],h=3;
  const sun={altitudeDeg:35,azimuthDeg:270};
  const [dx,dy]=shadowDisplacement(h,sun);
  const start=projectSitePoint(roof,h),end=projectSitePoint([roof[0]+dx,roof[1]+dy],0);
  expect(end[0]).toBeGreaterThan(start[0]); // afternoon sun west, shadow east
  const actual=screenToSite(end,0);expect(actual[0]).toBeCloseTo(roof[0]+dx,10);expect(actual[1]).toBeCloseTo(roof[1]+dy,10);
 });
});
