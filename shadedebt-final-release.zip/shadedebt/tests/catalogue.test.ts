import { describe,it,expect } from 'vitest';
import { parseStopCatalogue,searchStops } from '../src/data/catalogue';
import { groupStopsInViewport } from '../src/data/viewport';
import { fromCustom,fromStop,draftStorageKey,legacyDraftStorageKey } from '../src/data/siteIdentity';

const raw=[
  {id:'A',name:'11 Murti',latitude:28.6089,longitude:77.1901,source:'local'},
  {id:'B',name:'11 Murti',latitude:28.6101,longitude:77.1914,source:'local'},
  {id:'A',name:'duplicate ID',latitude:28.625,longitude:77.22},
  {id:'C',name:'11 Murti',latitude:28.6089,longitude:77.1901},
  {id:'D',name:'Bad coordinate',latitude:100,longitude:77.21},
  {id:'E',name:'Valid',latitude:28.5,longitude:77.2}
];
describe('Phase 4: catalogue adapter and unique site identity',()=>{
  it('preserves same-name stops with different coordinates and deduplicates duplicate IDs/places',()=>{
    const r=parseStopCatalogue(raw);
    expect(r.stops).toHaveLength(3);expect(r.rejected).toBe(1);expect(r.duplicates).toBe(2);
    expect(searchStops(r.stops,'11 murti')).toHaveLength(2);
  });
  it('rejects oversized input and accepts legitimate negative longitude',()=>{
    expect(()=>parseStopCatalogue(Array(25001).fill(raw[0]))).toThrow();
    expect(parseStopCatalogue([{id:'x',name:'Other site',latitude:28,longitude:-77}]).stops).toHaveLength(1);
  });
  it('handles missing name and non-numeric coordinates without poisoning map',()=>{
    expect(()=>parseStopCatalogue([{id:'1',latitude:28,longitude:77}])).toThrow();
    expect(()=>parseStopCatalogue([{id:'1',name:'wrong',latitude:'28',longitude:77}])).toThrow();
  });
  it('stops with identical coordinates but different ID keep independent draft keys',()=>{
    const a=fromStop({id:'1',name:'A',latitude:28.62,longitude:77.21,source:'local'});
    const b=fromStop({id:'2',name:'A',latitude:28.62,longitude:77.21,source:'local'});
    expect(draftStorageKey(a.key)).not.toBe(draftStorageKey(b.key));
    expect(fromCustom('Site',28.62,77.21).key).not.toBe(a.key);
    expect(legacyDraftStorageKey(28.62,77.21)).toContain('phase2.site');
  });
  it('viewport grouping retains every visible record and ignores other locations',()=>{
    const records=parseStopCatalogue(raw).stops;
    const clusters=groupStopsInViewport(records,(lat)=>lat>28.6,(lat,lon)=>[lat*100,lon*100],60);
    expect(clusters.flatMap(c=>c.members)).toHaveLength(2);
    expect(clusters.reduce((s,c)=>s+c.members.length,0)).toBe(2);
    expect(clusters).toHaveLength(1);
  });
  it('search is case-insensitive and cannot return more than the limit',()=>{
    const rows=parseStopCatalogue(raw).stops;
    expect(searchStops(rows,'MURTI',1)).toHaveLength(1);
    expect(searchStops(rows,'m')).toHaveLength(0);
  });
});
