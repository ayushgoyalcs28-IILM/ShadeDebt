import { test } from 'vitest';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const root=process.cwd();
const read=(p)=>readFileSync(resolve(root,p),'utf8');
test('Phase 3 uses Phase 1 physical simulation and clipping, not a new visual scoring formula',()=>{
 const source=read('src/engine/optimizer.ts');
 assert.match(source,/canopyShadow\(/);assert.match(source,/measureShade\(/);
 assert.match(source,/aggregateMetrics\(/);assert.match(source,/assertScenario\(/);
});
test('Search is constrained to site-authored polygons and preserves shape area',()=>{
 const source=read('src/engine/optimizer.ts');
 assert.match(source,/allowedConstructionZone/);assert.match(source,/exclusionZones/);
 assert.match(source,/buildings\.map/);assert.match(source,/baselineCanopies\.map/);
 assert.match(source,/coarseStepM/);assert.match(source,/fineStepM/);
});
test('Worker integration is non-blocking and cancellable',()=>{
 assert.ok(existsSync(resolve(root,'src/workers/optimizer.worker.ts')));
 const ui=read('src/components/ShadeLab.tsx');
 assert.match(ui,/new Worker\(/);assert.match(ui,/worker\.terminate\(\)/);
 assert.match(ui,/Preview position/);assert.match(ui,/Apply placement/);
});
test('Use-current-day requirement is wired into both interfaces with no manual date picker',()=>{
 const ui=read('src/components/ShadeLab.tsx'),preview=read('src/components/EnginePreview.tsx');
 assert.match(ui,/todayInDelhi\(/);assert.doesNotMatch(ui,/type="date"/);
 assert.match(preview,/todayInDelhi/);assert.doesNotMatch(preview,/>15 MAY 2026</);
});
test('Sensitive local stop catalogue is excluded from public app source and hosting',()=>{
 assert.match(read('.gitignore'),/local-data\//);
 assert.match(read('vite.config.ts'),/apply: 'serve'/);
 assert.doesNotMatch(read('src/App.tsx'),/from ['"]\.\/local-data/);
});
