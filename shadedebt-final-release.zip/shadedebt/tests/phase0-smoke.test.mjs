import { test } from 'vitest';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
test('Phase 0 project is structurally complete', () => {
  for (const file of ['package.json','vite.config.ts','tsconfig.json','index.html','src/App.tsx','src/types/domain.ts','scripts/import_gtfs_stops.py','src/data/stops.json','docs/PHASE0_STATUS.md'])
    assert.ok(fs.existsSync(path.join(root, file)), `Missing ${file}`);
});
test('Vite + React and explicit simulation dependencies are declared', () => {
  const deps = JSON.parse(read('package.json')).dependencies;
  for (const name of ['react','react-dom','suncalc','polygon-clipping']) assert.ok(deps[name], `Missing ${name}`);
});
test('No fake stop records are shipped as if measured', () => {
  assert.deepEqual(JSON.parse(read('src/data/stops.json')), []);
  assert.equal(JSON.parse(read('src/data/provenance.json')).source, 'NOT_IMPORTED');
});
test('Offline AWS smoke artifact is a standalone HTML document', () => {
  const html = read('deploy-smoke/index.html');
  assert.match(html, /<!DOCTYPE html>/i);
  assert.match(html, /SHADEDEBT · AWS AMPLIFY CONNECTIVITY CHECK/);
  assert.doesNotMatch(html, /src\/main\.tsx/);
});
