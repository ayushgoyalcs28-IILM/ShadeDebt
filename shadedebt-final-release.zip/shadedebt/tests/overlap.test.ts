import {describe,it,expect} from 'vitest';
import {rectangle} from '../src/engine/shapes';
import {measureShade,multiPolygonArea} from '../src/engine/overlap';
import {aggregateMetrics} from '../src/engine/metrics';

describe('polygon boolean coverage and time integration',()=>{
  const waiting=rectangle(10,10);
  it('empty shade gives exactly zero coverage',()=>{
    expect(measureShade(waiting,[]).coverage).toBe(0);
  });
  it('one 2×2 shade contributes exactly 4m²',()=>{
    expect(measureShade(waiting,[rectangle(2,2)]).shadedAreaM2).toBeCloseTo(4,8);
  });
  it('overlapping roofs counted once via geometric union',()=>{
    expect(measureShade(waiting,[rectangle(2,2),rectangle(2,2,[1,0])]).shadedAreaM2).toBeCloseTo(6,8);
  });
  it('shadows outside the waiting area do not improve the score',()=>{
    expect(measureShade(waiting,[rectangle(2,2,[100,100])]).coverage).toBe(0);
  });
  it('partial overlap clips to waiting zone',()=>{
    const w=rectangle(4,2);
    const s=rectangle(4,2,[2,0]);
    expect(measureShade(w,[s]).shadedAreaM2).toBeCloseTo(4,8);
  });
  it('GeoJSON hole areas subtract correctly',()=>{
    expect(multiPolygonArea([[[[0,0],[4,0],[4,4],[0,4]],[[1,1],[2,1],[2,2],[1,2]]]])).toBeCloseTo(15,8);
  });
  it('weights partial final intervals in square-metre hours',()=>{
    const m=aggregateMetrics(10,[{durationMinutes:60,baselineShadedM2:0,proposedShadedM2:10},{durationMinutes:30,baselineShadedM2:0,proposedShadedM2:0}]);
    expect(m?.evaluatedHours).toBeCloseTo(1.5);
    expect(m?.baselineShadeDebtM2Hours).toBeCloseTo(15);
    expect(m?.proposedShadeDebtM2Hours).toBeCloseTo(5);
    expect(m?.averageProposedCoverage).toBeCloseTo(2/3);
  });
  it('returns null rather than made-up values with no eligible sunlight',()=>{
    expect(aggregateMetrics(24,[])).toBeNull();
  });
  it('reports null relative reduction when baseline shade debt is zero',()=>{
    expect(aggregateMetrics(4,[{durationMinutes:60,baselineShadedM2:4,proposedShadedM2:4}])?.shadeDebtReductionFraction).toBeNull();
  });
});
