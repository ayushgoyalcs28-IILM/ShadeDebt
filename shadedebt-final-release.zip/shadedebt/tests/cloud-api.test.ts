import { describe, expect, it } from 'vitest';
import { handler, API_VERSION, MODEL_VERSION } from '../lambda/handler';
import { sampleDraft, toScenario } from '../src/engine/editor';
import { optimizeScenario } from '../src/engine/optimizer';

const data=()=>{
  const draft=sampleDraft();draft.date='2026-05-15';
  const scenario=toScenario(draft);
  const options={anchor:[draft.proposal.x,draft.proposal.y] as const,coarseStepM:1,fineStepM:.25,refineRadiusM:.75,maxEvaluations:750};
  return {apiVersion:API_VERSION,scenario,options};
};
const call=async(body:unknown,method='POST',path='/optimize')=>handler({rawPath:path,requestContext:{http:{method}},headers:{'content-type':'application/json'},body:JSON.stringify(body)});

describe('Phase 5 Lambda API',()=>{
  it('exposes a low-cost versioned health endpoint without user data',async()=>{
    const r=await handler({rawPath:'/health',requestContext:{http:{method:'GET'}}});
    expect(r.statusCode).toBe(200);expect(JSON.parse(r.body).modelVersion).toBe(MODEL_VERSION);
  });
  it('runs the exact shared optimizer and returns identical metrics',async()=>{
    const request=data(),reference=optimizeScenario(request.scenario,request.options);
    const response=await call(request);
    expect(response.statusCode).toBe(200);
    const json=JSON.parse(response.body);
    expect(json.apiVersion).toBe(API_VERSION);
    expect(json.result).toEqual(reference);
  });
  it('does not mutate the caller request model',async()=>{
    const input=data(),copy=JSON.stringify(input);
    await call(input);expect(JSON.stringify(input)).toBe(copy);
  });
  it('rejects malformed, oversized, or wrong content-type requests',async()=>{
    expect((await handler({rawPath:'/optimize',requestContext:{http:{method:'POST'}},headers:{'content-type':'application/json'},body:'{oops'})).statusCode).toBe(400);
    expect((await handler({rawPath:'/optimize',requestContext:{http:{method:'POST'}},headers:{'content-type':'application/json'},body:' '.repeat(65537)})).statusCode).toBe(413);
    expect((await handler({rawPath:'/optimize',requestContext:{http:{method:'POST'}},headers:{'content-type':'text/plain'},body:'{}'})).statusCode).toBe(415);
  });
  it('rejects invalid geometry and attacker-controlled search settings',async()=>{
    const invalid=data();invalid.scenario.site.latitude=999;
    expect((await call(invalid)).statusCode).toBe(422);
    const largeBudget={...data(),options:{...data().options,maxEvaluations:2000}};
    expect((await call(largeBudget)).statusCode).toBe(422);
  });
  it('caps maliciously large construction envelopes before attempting the grid search',async()=>{
    const value=data();value.scenario.site.allowedConstructionZone=[[-200,-200],[200,-200],[200,200],[-200,200]];
    const res=await call(value);expect(res.statusCode).toBe(422);
  });
  it('does not allow more than one proposed roof',async()=>{
    const value=data();value.scenario.proposedCanopies.push({...value.scenario.proposedCanopies[0],id:'second'});
    expect((await call(value)).statusCode).toBe(422);
  });
  it('rejects unsupported methods and paths without attempting optimization',async()=>{
    expect((await call(data(),'PUT')).statusCode).toBe(405);
    expect((await call(data(),'POST','/wrong')).statusCode).toBe(404);
  });
  it('accepts a base64-encoded Lambda request body',async()=>{
    const value=data();const r=await handler({rawPath:'/optimize',requestContext:{http:{method:'POST'}},headers:{'content-type':'application/json'},body:Buffer.from(JSON.stringify(value)).toString('base64'),isBase64Encoded:true});
    expect(r.statusCode).toBe(200);
  });
});
