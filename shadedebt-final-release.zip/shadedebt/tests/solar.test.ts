import { describe,it,expect } from 'vitest';
import { istInstant,istFromClock,sunPosition } from '../src/engine/solar';

describe('Delhi date handling and independent sun benchmarks',()=>{
  it('midnight IST is previous day 18:30 UTC; not host-timezone dependent',()=>{
    expect(istFromClock('2026-05-15','00:00').toISOString()).toBe('2026-05-14T18:30:00.000Z');
    expect(istFromClock('2026-05-15','16:00').toISOString()).toBe('2026-05-15T10:30:00.000Z');
  });
  it('handles fractional minute offsets and end of day',()=>{
    expect(istInstant('2026-05-15',7.5).toISOString()).toBe('2026-05-14T18:37:30.000Z');
    expect(istInstant('2026-05-15',1440).toISOString()).toBe('2026-05-15T18:30:00.000Z');
  });
  it('rejects invalid civil dates',()=>{
    expect(()=>istInstant('2026-02-30',600)).toThrow();
  });
  it('matches independently computed Swiss Ephemeris benchmarks for Delhi to 1.5°',()=>{
    // Reference: independent Swiss Ephemeris calculations for 28.6139N, 77.209E, 15 May 2026.
    // These are deliberately loose integration-regression tolerances, not field validation.
    const noon=sunPosition(istFromClock('2026-05-15','12:00'),28.6139,77.209);
    const afternoon=sunPosition(istFromClock('2026-05-15','16:00'),28.6139,77.209);
    expect(noon.altitudeDeg).toBeGreaterThan(78);
    expect(noon.altitudeDeg).toBeLessThan(81);
    expect(noon.azimuthDeg).toBeGreaterThan(155);
    expect(noon.azimuthDeg).toBeLessThan(159);
    expect(Math.abs(afternoon.altitudeDeg-38.64)).toBeLessThan(1.5);
    expect(Math.abs(afternoon.azimuthDeg-272.12)).toBeLessThan(1.5);
  });
  it('uses north-clockwise azimuth (v2) rather than v1 radians convention',()=>{
    const p=sunPosition(istFromClock('2026-05-15','16:00'),28.6139,77.209);
    expect(p.azimuthDeg).toBeGreaterThan(260);
    expect(p.azimuthDeg).toBeLessThan(285);
  });
});
