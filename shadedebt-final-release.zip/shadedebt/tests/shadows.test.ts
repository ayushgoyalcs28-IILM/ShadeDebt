import {describe,it,expect} from 'vitest';
import {polygonArea} from '../src/engine/geometry';
import {rectangle,circle,triangle,trapezoid,hexagon,custom,transformPolygon} from '../src/engine/shapes';
import {assertPolygon,assertConvexPolygon} from '../src/engine/validation';
import {canopyShadow,buildingShadow,shadowDisplacement,MIN_SOLAR_ALTITUDE_DEG} from '../src/engine/shadows';

const eastSun={altitudeDeg:45,azimuthDeg:90};
const westSun={altitudeDeg:45,azimuthDeg:270};

describe('shape constructors and validation',()=>{
  it('creates six supported horizontal silhouettes with positive area',()=>{
    for(const poly of [rectangle(4,2),circle(2),triangle(3,3),trapezoid(2,4,3),hexagon(3),custom([[0,0],[2,0],[1,1]])]) {
      assertPolygon(poly);
      expect(polygonArea(poly)).toBeGreaterThan(0);
    }
  });
  it('rotation and translation preserve area',()=>{
    expect(polygonArea(transformPolygon(rectangle(4,2),7,-3,60))).toBeCloseTo(8,8);
  });
  it('blocks bow ties, repeated vertices, NaN and concave building outlines',()=>{
    expect(()=>assertPolygon([[0,0],[2,2],[0,2],[2,0]])).toThrow();
    expect(()=>assertPolygon([[0,0],[2,0],[2,0],[0,2]])).toThrow();
    expect(()=>assertPolygon([[0,0],[Infinity,0],[0,2]])).toThrow();
    expect(()=>assertConvexPolygon([[0,0],[3,0],[3,3],[1,1],[0,3]],'b')).toThrow();
  });
});

describe('correct solar shadow direction and swept solid volumes',()=>{
  it('a western sun produces an eastward shadow of height/tan(altitude)',()=>{
    const [x,y]=shadowDisplacement(3,westSun);
    expect(x).toBeCloseTo(3,8);
    expect(y).toBeCloseTo(0,8);
    expect(shadowDisplacement(3,eastSun)[0]).toBeCloseTo(-3,8);
  });
  it('an opaque flat canopy shadow is translated without an area change',()=>{
    const original=rectangle(4,2);
    const shadow=canopyShadow({id:'c',footprint:original,shape:'rectangle',heightM:3,opaque:true},westSun);
    expect(polygonArea(shadow)).toBeCloseTo(polygonArea(original),8);
    expect(shadow[0][0]-original[0][0]).toBeCloseTo(3,8);
  });
  it('a 2m high solid rectangular building casts a swept polygon including its walls',()=>{
    const building={id:'b',footprint:rectangle(2,2),heightM:2};
    const projected=buildingShadow(building,westSun);
    // Bounds x=-1 .. +3, y=-1 .. +1; area=8, NOT a translated 4m² roof.
    expect(polygonArea(projected)).toBeCloseTo(8,8);
    expect(Math.min(...projected.map(p=>p[0]))).toBeCloseTo(-1,8);
    expect(Math.max(...projected.map(p=>p[0]))).toBeCloseTo(3,8);
  });
  it('zero-height direct projection disallowed by site validation but mathematical function behaves',()=>{
    expect(shadowDisplacement(0,westSun)[0]).toBe(0);
  });
  it('near-horizon angles are rejected instead of allowing an unbounded shadow',()=>{
    expect(()=>shadowDisplacement(3,{altitudeDeg:MIN_SOLAR_ALTITUDE_DEG-0.01,azimuthDeg:270})).toThrow();
    expect(()=>shadowDisplacement(3,{altitudeDeg:-10,azimuthDeg:270})).toThrow();
  });
});
