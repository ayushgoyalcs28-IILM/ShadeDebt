import { describe, it, expect } from 'vitest';
import { polygonArea } from '../src/engine/geometry';
import { rectangle } from '../src/engine/shapes';
import { sampleDraft, outline, footprintArea, switchRoofShape, moveCustomVertex, toScenario, toScreen, fromScreen } from '../src/engine/editor';
import { simulateScenario } from '../src/engine/simulation';

describe('Phase 2: authoring model and Phase 1 integration', () => {
  it('creates concept draft and generates a valid Phase 1 scenario', () => {
    const draft=sampleDraft(28.6139,77.2090,'Delhi sample');
    const scenario=toScenario(draft);
    expect(scenario.site.latitude).toBe(28.6139);
    expect(scenario.site.waitingArea).toHaveLength(4);
    expect(scenario.site.measurementMode).toBe('concept');
    expect(scenario.proposedCanopies).toHaveLength(1);
    expect(scenario.mode).toBe('add');
  });
  it('supports all six flat roof shapes with positive finite footprint area', () => {
    const d=sampleDraft();
    for(const shape of ['rectangle','circle','triangle','trapezoid','hexagon','custom'] as const){
      const design={...d.proposal,shape};
      const polygon=outline(design);
      expect(polygonArea(polygon)).toBeGreaterThan(.1);
      expect(polygon.every(p=>p.every(Number.isFinite))).toBe(true);
    }
  });
  it('circular roof area agrees with pi*r² to 0.2%', () => {
    const d=sampleDraft();d.proposal.shape='circle';d.proposal.width=4;
    expect(footprintArea(d.proposal)/ (Math.PI*4)).toBeCloseTo(1,2);
  });
  it('locks equivalent canopy footprint area across all six shape presets',()=>{
    const draft=sampleDraft();draft.proposal.shape='rectangle';
    const expected=footprintArea(draft.proposal);
    for(const shape of ['circle','triangle','trapezoid','hexagon','custom','rectangle'] as const){
      const modified=switchRoofShape(draft.proposal,shape,true);
      expect(footprintArea(modified)).toBeCloseTo(expected,7);
      expect(modified.height).toBe(draft.proposal.height);
      expect(modified.rotation).toBe(draft.proposal.rotation);
      expect(footprintArea(draft.proposal)).toBe(expected);
    }
  });
  it('screen/world transforms preserve physical x-east/y-north positions', () => {
    for(const p of [[-7,2],[4,-3],[0,0]] as const){
      const got=fromScreen(toScreen(p));
      expect(got[0]).toBeCloseTo(p[0],10);
      expect(got[1]).toBeCloseTo(p[1],10);
    }
  });
  it('rotation changes roof outline but not footprint area', () => {
    const d=sampleDraft();const before=footprintArea(d.proposal);
    d.proposal.rotation=83;
    expect(footprintArea(d.proposal)).toBeCloseTo(before,8);
  });
  it('rejects self-intersecting custom edits without altering the original draft', () => {
    const draft=sampleDraft();draft.proposal.shape='custom';
    const original=JSON.stringify(draft.proposal.vertices);
    expect(()=>moveCustomVertex(draft.proposal,1,[-1.8,1.3])).toThrow();
    expect(JSON.stringify(draft.proposal.vertices)).toBe(original);
  });
  it('accepts a valid custom-vertex modification', () => {
    const draft=sampleDraft();draft.proposal.shape='custom';
    const moved=moveCustomVertex(draft.proposal,0,[-1.3,-.65]);
    expect(moved.vertices[0]).toEqual([-1.3,-.65]);
    expect(draft.proposal.vertices[0]).not.toEqual(moved.vertices[0]);
  });
  it('building geometry is included only when enabled', () => {
    const draft=sampleDraft();
    expect(toScenario(draft).site.buildings).toHaveLength(0);
    draft.building.enabled=true;
    expect(toScenario(draft).site.buildings).toHaveLength(1);
  });
  it('absence of existing roof yields zero baseline canopy objects', () => {
    const d=sampleDraft();d.includeExisting=false;
    expect(toScenario(d).site.baselineCanopies).toHaveLength(0);
  });
  it('supports add and replace without mutating original configuration', () => {
    const d=sampleDraft();const add=toScenario(d);
    d.comparisonMode='replace';const replace=toScenario(d);
    expect(add.site.baselineCanopies).toHaveLength(1);
    expect(replace.site.baselineCanopies).toHaveLength(1);
    expect(add.mode).toBe('add');expect(replace.mode).toBe('replace');
  });
  it('actual Phase 1 simulation receives complete Phase 2 scenario and returns coverage metrics', () => {
    const result=simulateScenario(toScenario(sampleDraft()));
    expect(result.metrics).not.toBeNull();
    expect(result.metrics!.averageProposedCoverage).toBeGreaterThanOrEqual(result.metrics!.averageBaselineCoverage-1e-8);
    expect(result.metrics!.shadeDebtReductionM2Hours).toBeGreaterThanOrEqual(-1e-6);
  });
  it('site plan construction envelope and road exclusion do not overlap', () => {
    const d=sampleDraft(), scenario=toScenario(d);
    expect(polygonArea(scenario.site.allowedConstructionZone)).toBeGreaterThan(0);
    expect(scenario.site.exclusionZones).toHaveLength(1);
    const allowed=rectangle(22,12,[0,1.8]);
    expect(scenario.site.allowedConstructionZone).toEqual(allowed);
  });
});
