import {test} from 'vitest';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const base=resolve(import.meta.dirname,'..');
const read=p=>readFileSync(resolve(base,p),'utf8');
test('phase1 engine modules remain present and unmodified',()=>{
  for(const name of ['solar','shadows','simulation','validation','metrics','overlap','geometry','shapes'])assert.ok(existsSync(resolve(base,`src/engine/${name}.ts`)));
});
test('phase2 editor adds authoring model, six shapes and site conversion',()=>{
  const code=read('src/engine/editor.ts');
  for(const name of ['rectangle','circle','triangle','trapezoid','hexagon','custom','toScenario','moveCustomVertex'])assert.match(code,new RegExp(name));
});
test('local dataset cannot be imported directly into production app',()=>{
  assert.deepEqual(JSON.parse(read('src/data/stops.json')),[]);
  const app=read('src/App.tsx');
  assert.doesNotMatch(app,/import\s+stopsRaw\s+from/);
  assert.match(read('vite.config.ts'),/apply: 'serve'/);
  assert.match(read('.gitignore'),/local-data\//);
});
test('site editor preserves direct-beam scientific warnings',()=>{
  const lab=read('src/components/ShadeLab.tsx');
  assert.match(lab,/Direct-beam|direct-beam/);
  assert.match(lab,/sunPosition/);
  assert.match(lab,/simulateScenario/);
  assert.match(lab,/shadowDisplacement/);
  assert.match(lab,/before/);
  assert.match(lab,/after/);
});
