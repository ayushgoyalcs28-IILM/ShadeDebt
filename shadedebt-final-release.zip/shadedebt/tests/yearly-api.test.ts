import {describe,it,expect} from 'vitest';
import {handler,YEARLY_API_VERSION,API_VERSION} from '../lambda/handler';
import {sampleDraft,toScenario} from '../src/engine/editor';
const request=(apiVersion:string,anchor:[number,number])=>{
 const draft=sampleDraft();draft.building.enabled=false;draft.constraints.noBuild.enabled=false;draft.comparisonMode='replace';draft.proposal.shape='custom';
 return {rawPath:'/',requestContext:{http:{method:'POST',path:'/'}},headers:{'content-type':'application/json'},body:JSON.stringify({apiVersion,scenario:toScenario(draft),options:{anchor}})};
};
describe('versioned cloud annual optimization',()=>{
 it('accepts annual request with shared engine and twelve dates',async()=>{
  const response=await handler(request(YEARLY_API_VERSION,[3,-.3]));const data=JSON.parse(response.body);
  expect(response.statusCode).toBe(200);expect(data.modelVersion).toBe('yearly-placement-v1');expect(data.result.dates).toHaveLength(12);expect(data.result.sampledTimes).toBe(60);
 });
 it('continues to support the legacy daily endpoint',async()=>{
  const response=await handler(request(API_VERSION,[3,-.3]));
  expect(response.statusCode).toBe(200);expect(JSON.parse(response.body).modelVersion).toBe('phase3-translation-grid-v1');
 });
 it('rejects impossible annual search coordinates',async()=>{
  const response=await handler(request(YEARLY_API_VERSION,[10001,0]));expect(response.statusCode).toBe(422);
 });
});
