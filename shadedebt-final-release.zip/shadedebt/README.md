# ShadeDebt — Phase 5 AWS Optimization

**Environmental Hacks 2026 · Heat & Water track**

ShadeDebt is a site-aware shade intervention laboratory for comparing proposed flat, opaque canopy designs over a defined public waiting area. It models solar position, direct-beam shadows and unshaded area-time (ShadeDebt). It does **not** predict air temperature, health outcomes or structural safety.

## Development status

| Phase | Status |
|---|---|
| 0 | React/TypeScript foundation and AWS static-hosting smoke test |
| 1 | Solar and shadow engine, polygon intersections and metrics |
| 2 | Interactive site builder, six roof shapes, moving shadows, before/after assessment |
| 3 | Constrained placement search, optional preview/apply, today's Delhi date |
| **4** | **Delhi Explorer, search, map, per-stop isolated drafts** |
| **5** | **AWS Lambda integration and Amplify deployment tooling delivered; live AWS deployment requires your account** |
| 6–7 | Formal reports, end-to-end design/UX review and production QA — not yet completed |
| 8 | Hackathon demonstration and submission — not yet completed |

## Install and verify

```sh
npm install
npm run check
npm test
npm run smoke:offline
npm run build
npm run dev
```

Node.js 20.19+ recommended. Generate and commit your `package-lock.json` for reproducible AWS builds.

Open **Delhi Explorer** to choose a stop or manually enter a custom location. Selecting a stop passes its name and coordinates into the existing Shade Laboratory; it does not supply real shelter dimensions. Different stop identities keep separate drafts in browser local storage.

## Data licensing boundary

The Kaggle-derived 6,880-stop cleaned catalogue was provided for **local development**. Its entire database redistribution authorization remains unresolved. It is deliberately **excluded from this source ZIP and production output**. For local testing, keep your existing private `local-data/stops.json` or restore it from the separately supplied local-data archive. The Vite development-only middleware serves it at `/__shadedebt_local_stops.json`.

Public builds have an **Import stops JSON** input for a user-supplied authorized catalogue, plus a fully functional Custom Site mode. The OpenStreetMap background uses attributed public map tiles, subject to the tile service usage policy.

## Phase 5 release

The frontend can send a bounded optimization request to AWS Lambda, using the **same** Phase 3 deterministic geometry engine as the browser Worker. The backend has a versioned HTTP contract and input safeguards. If AWS fails, the app labels an automatic local Worker fallback. The original drag/edit/preview/apply interaction is preserved.

See [Phase 5 deployment and acceptance](docs/PHASE5_HANDOFF.md) for local tests, the Lambda ZIP build, the exact AWS Console/CloudFormation deployment path, the production frontend Amplify ZIP build, cloud smoke tests, and the ODbL-attributed optional public stop feed.

No live AWS Lambda deployment is included in the source ZIP. Only an authenticated AWS session can provision it.

## Documentation

- [Phase 4 build and acceptance](docs/PHASE4_HANDOFF.md)
- [Phase 3 optimizer](docs/PHASE3_OPTIMIZER.md)
- [Phase 2 physical model](docs/PHASE2_MODEL.md)
- [Phase 1 engine](docs/PHASE1_ENGINE.md)
- [AWS deployment runbook](docs/DEPLOYMENT.md)

**Scientific invariant:** Local ground geometry uses metres east/north; geographical coordinates only provide solar-position location. User-input geometries are not represented as verified surveys.
