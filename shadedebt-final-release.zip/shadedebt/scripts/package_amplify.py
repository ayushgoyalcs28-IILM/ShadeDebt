#!/usr/bin/env python3
"""Make an Amplify manual-deploy ZIP whose index.html is at the archive root."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
base=Path('dist');target=Path('build/shadedebt-amplify.zip')
if not (base/'index.html').is_file():raise SystemExit('No dist/index.html: run npm run build first')
target.parent.mkdir(parents=True,exist_ok=True)
with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(base.rglob('*')):
        if p.is_file() and p != base/'lambda/lambda.zip':z.write(p,p.relative_to(base).as_posix())
with ZipFile(target) as z:
    assert 'index.html' in z.namelist() and z.testzip() is None
print(f'Validated Amplify manual deployment ZIP: {target} ({target.stat().st_size:,} bytes)')
