#!/usr/bin/env python3
"""Create a ZIP with index.html at root as Amplify drag-and-drop requires."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root = Path(__file__).resolve().parent.parent
out = root.parent / 'shadedebt-amplify-smoke.zip'
with ZipFile(out, 'w', compression=ZIP_DEFLATED) as z:
    z.write(root/'deploy-smoke'/'index.html', 'index.html')
    z.write(root/'deploy-smoke'/'_headers', '_headers')
print(out)
