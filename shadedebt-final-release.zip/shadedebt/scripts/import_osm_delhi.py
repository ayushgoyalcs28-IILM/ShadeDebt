#!/usr/bin/env python3
"""Opt-in build-time import of OSM bus stop locations for *public* distribution.
Data copyright OpenStreetMap contributors, licensed ODbL 1.0.
Does not use the private Kaggle-derived catalogue.
Usage: python3 scripts/import_osm_delhi.py [overpass-export.json]
Without an argument, fetches a bounded Overpass node export once.
"""
import json,sys,os,urllib.request,urllib.parse
from pathlib import Path
ENDPOINTS=[os.environ.get('SHADEDEBT_OVERPASS_ENDPOINT','https://overpass-api.de/api/interpreter'),'https://overpass.nchc.org.tw/api/interpreter']
# Delhi & immediate NCR region, OSM-tagged stops only. Historical accuracy not guaranteed.
QUERY='''[out:json][timeout:55];(
 node["highway"="bus_stop"](28.35,76.80,29.02,77.55);
 node["public_transport"="platform"]["bus"="yes"](28.35,76.80,29.02,77.55);
);out body;'''
def process(data):
    stops=[];seen=set();seen_loc=set()
    for el in data.get('elements',[]):
        if el.get('type')!='node':continue
        tags=el.get('tags') or {}
        name=str(tags.get('name') or tags.get('name:en') or '').strip()
        lat,lon=el.get('lat'),el.get('lon');ident=el.get('id')
        if not (name and isinstance(lat,(int,float)) and isinstance(lon,(int,float)) and isinstance(ident,int)):continue
        if not (28.35<=lat<=29.02 and 76.8<=lon<=77.55):continue
        k=(lat,lon,name.lower());nid=f'osm-node-{ident}'
        if nid in seen or k in seen_loc:continue
        seen.add(nid);seen_loc.add(k)
        stops.append({'id':nid,'name':name[:160],'latitude':lat,'longitude':lon,'source':'OpenStreetMap contributors · ODbL 1.0'})
    stops.sort(key=lambda s:(s['name'].lower(),s['id']))
    return stops
if len(sys.argv)>1:
    payload=json.loads(Path(sys.argv[1]).read_text())
else:
    errors=[];payload=None
    for endpoint in dict.fromkeys(ENDPOINTS):
        try:
            data=urllib.parse.urlencode({'data':QUERY}).encode('utf-8')
            req=urllib.request.Request(endpoint,data=data,headers={'Content-Type':'application/x-www-form-urlencoded','User-Agent':'ShadeDebt-Hackathon-DataImporter/1.1 (OSM attribution in public build)'})
            with urllib.request.urlopen(req,timeout=65) as res:payload=json.load(res)
            break
        except Exception as exc:
            errors.append(str(exc))
    if payload is None:raise SystemExit('OSM import unsuccessful (no records installed): '+'; '.join(errors))
stops=process(payload)
if not stops:raise SystemExit('No OSM bus stop records returned. Refusing to publish an empty catalogue.')
if len(stops)>20000:raise SystemExit('Too many records')
p=Path('public/data/delhi-stops.json');p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(json.dumps(stops,ensure_ascii=False,separators=(',',':'))+'\n')
Path('public/data/LICENSE-DATA.txt').write_text('Bus-stop location data: © OpenStreetMap contributors, available under Open Database License (ODbL) 1.0.\nSource: https://www.openstreetmap.org/copyright\nLicense: https://opendatacommons.org/licenses/odbl/1-0/\nDerived by filtering named, bus-related OSM nodes in the Delhi/NCR region. The transformed catalogue is distributed under ODbL 1.0. No shelter survey or active-service status is implied.\n')
print(f'Wrote {len(stops)} OSM-derived locations to {p}. Attribution/ODbL: public/data/LICENSE-DATA.txt')
