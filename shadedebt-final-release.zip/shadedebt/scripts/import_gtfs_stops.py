#!/usr/bin/env python3
"""Import legitimate GTFS stops.txt from a ZIP archive or directory.

Example:
 python3 scripts/import_gtfs_stops.py /path/to/GTFS.zip --source official-otd

This tool never manufactures bus stops. Reuse and attribution terms remain
subject to the originating dataset's license and publication conditions.
"""
import argparse
import csv
import datetime as dt
import io
import json
import math
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / 'src' / 'data'

def parse_rows(text: str, source: str) -> list[dict]:
    reader = csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    required = {'stop_id', 'stop_name', 'stop_lat', 'stop_lon'}
    missing = required - set(reader.fieldnames or [])
    if missing:
        raise ValueError(f'Missing GTFS columns: {sorted(missing)}')
    result: list[dict] = []
    seen: set[str] = set()
    for row in reader:
        identifier = (row['stop_id'] or '').strip()
        name = (row['stop_name'] or '').strip()
        if not identifier or not name or identifier in seen:
            continue
        try:
            lat, lon = float(row['stop_lat']), float(row['stop_lon'])
        except (TypeError, ValueError):
            continue
        if not all(math.isfinite(n) for n in (lat, lon)) or not (-90 <= lat <= 90 and -180 <= lon <= 180):
            continue
        # Do not remove outlying Delhi NCR stops merely because they are outside Delhi NCT.
        result.append({'id': identifier, 'name': name, 'latitude': lat, 'longitude': lon, 'source': source})
        seen.add(identifier)
    return sorted(result, key=lambda s: (s['name'].lower(), s['id']))

def read_gtfs_stops(input_path: pathlib.Path) -> str:
    if input_path.is_dir():
        paths = list(input_path.rglob('stops.txt'))
        if not paths: raise ValueError('Directory contains no stops.txt')
        return paths[0].read_text(encoding='utf-8-sig')
    if input_path.suffix.lower() == '.txt':
        return input_path.read_text(encoding='utf-8-sig')
    with zipfile.ZipFile(input_path) as archive:
        matches = [n for n in archive.namelist() if pathlib.PurePosixPath(n).name.lower() == 'stops.txt']
        if not matches: raise ValueError('ZIP archive contains no stops.txt')
        return archive.read(matches[0]).decode('utf-8-sig')

def run(path: pathlib.Path, source: str, source_url: str) -> int:
    stops = parse_rows(read_gtfs_stops(path), source)
    if not stops:
        raise ValueError('No valid stop records; existing outputs left unchanged')
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT/'stops.json').write_text(json.dumps(stops, separators=(',', ':'), ensure_ascii=False)+'\n', encoding='utf-8')
    meta = {'source': source, 'sourceUrl': source_url, 'publishedUpdate': '2024-06-20' if source == 'official-otd' else None, 'importedAt': dt.datetime.now(dt.timezone.utc).isoformat(), 'count': len(stops), 'notice': 'Coordinates are sourced. Stop geometry and shelter condition are not included.'}
    (OUT/'provenance.json').write_text(json.dumps(meta, indent=2)+'\n', encoding='utf-8')
    print(f'Imported {len(stops)} valid stops from {path}. Source: {source}.')
    return len(stops)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('path', type=pathlib.Path, help='Path to GTFS zip, directory or stops.txt')
    parser.add_argument('--source', default='official-otd', help='Data provenance label')
    parser.add_argument('--source-url', default='https://otd.delhi.gov.in/data/static/')
    a = parser.parse_args()
    try:
        run(a.path, a.source, a.source_url)
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        print(f'GTFS import failed: {exc}', file=sys.stderr)
        sys.exit(1)
