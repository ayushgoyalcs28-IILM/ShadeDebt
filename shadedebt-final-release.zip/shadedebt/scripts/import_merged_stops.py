#!/usr/bin/env python3
"""Convert user-supplied merged Delhi transit CSV ZIP into a de-duplicated stop catalogue.

Works with this dataset's single-CSV format, NOT the official GTFS importer.
Only exactly identical coordinate pairs with the same name are merged.
No data-derived location is represented as a verified physical shelter.
Usage:
    python3 scripts/import_merged_stops.py '/path/to/archive (1).zip' --output-dir local-data
"""
import argparse
import csv
import datetime as dt
import io
import json
import math
from pathlib import Path
import zipfile

REQUIRED = {'stop_id', 'stop_name', 'stop_lat', 'stop_lon'}
SOURCE = 'kaggle-user-upload-unverified'


def build(input_zip: Path):
    with zipfile.ZipFile(input_zip) as z:
        candidates = [i for i in z.infolist() if i.filename.endswith('.csv') and not i.is_dir()]
        if len(candidates) != 1:
            raise ValueError('Expected exactly one CSV in the ZIP')
        blob = z.read(candidates[0]).decode('utf-8-sig')
        member_timestamp = candidates[0].date_time

    reader = csv.DictReader(io.StringIO(blob))
    missing = REQUIRED - set(reader.fieldnames or [])
    if missing:
        raise ValueError(f'Missing required columns: {sorted(missing)}')
    by_id = {}
    raw_rows = 0
    for row in reader:
        raw_rows += 1
        identifier, name = row['stop_id'].strip(), row['stop_name'].strip()
        if not identifier or not name:
            raise ValueError(f'Empty stop identifier/name at CSV record {raw_rows}')
        try:
            lat, lon = float(row['stop_lat']), float(row['stop_lon'])
        except (ValueError, TypeError):
            raise ValueError(f'Invalid coordinate at CSV record {raw_rows}')
        if not (math.isfinite(lat) and math.isfinite(lon) and 6 <= lat <= 38 and 68 <= lon <= 98):
            raise ValueError(f'Out-of-region/invalid coordinate at CSV record {raw_rows}')
        v = (name, lat, lon)
        previous = by_id.setdefault(identifier, v)
        if previous != v:
            raise ValueError(f'Conflicting attributes for stop_id {identifier}')

    # Latitude/longitude are a local selection point, NOT precise surveyed roof coordinates.
    grouped = {}
    for identifier, (name, lat, lon) in by_id.items():
        key = (lat, lon)
        entry = grouped.setdefault(key, {'name': name, 'lat': lat, 'lon': lon, 'ids': []})
        if entry['name'] != name:
            raise ValueError(f'Different names at exact same coordinates {key}; manual review required')
        entry['ids'].append(identifier)

    records = []
    for entry in grouped.values():
        ids = sorted(entry['ids'], key=lambda s: (len(s), s))
        records.append({
            'id': 'kaggle-' + ids[0],
            'name': entry['name'],
            'latitude': entry['lat'],
            'longitude': entry['lon'],
            'source': SOURCE,
            'sourceStopIds': ids,
        })
    records.sort(key=lambda x: (x['name'].casefold(), x['latitude'], x['longitude'], x['id']))
    metadata = {
        'source': SOURCE,
        'sourceUrl': None,
        'publicationDate': None,
        'archiveFile': input_zip.name,
        'csvFile': candidates[0].filename,
        'archiveMemberModifiedDate': f'{member_timestamp[0]:04}-{member_timestamp[1]:02}-{member_timestamp[2]:02}',
        'archiveDateIsNotDatasetPublicationDate': True,
        'importedAtUTC': dt.datetime.now(dt.timezone.utc).isoformat(),
        'rawRows': raw_rows,
        'uniqueStopIds': len(by_id),
        'uniqueLocations': len(records),
        'collapsedSameCoordinateAliases': len(by_id) - len(records),
        'notice': ('Kaggle dataset URL, original producer, license and currency have not been verified. '
                   'Locations are not verified operational bus shelters. '
                   'No shelter dimensions, orientation or building geometry supplied. '
                   'Do not publish this catalogue until reuse permission is checked.'),
    }
    return records, metadata


def run(path: Path, output_dir: Path):
    records, metadata = build(path)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / 'stops.json').write_text(json.dumps(records, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
    (output_dir / 'provenance.json').write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'Parsed {metadata["rawRows"]:,} rows, {metadata["uniqueStopIds"]:,} stop IDs, and {metadata["uniqueLocations"]:,} location records')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('zip_path', type=Path)
    parser.add_argument('--output-dir', type=Path, default=Path('local-data'))
    args = parser.parse_args()
    run(args.zip_path, args.output_dir)
