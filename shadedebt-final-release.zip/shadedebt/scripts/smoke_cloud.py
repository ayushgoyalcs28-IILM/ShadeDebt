#!/usr/bin/env python3
"""AWS-side proof: real HTTP health, deterministic optimization, input rejection."""
import json,os,urllib.request,urllib.error
URL=os.getenv('SHADEDEBT_API_URL','').strip()
if not URL.startswith('https://'):raise SystemExit('Set SHADEDEBT_API_URL to deployed HTTPS Lambda Function URL')
URL=URL.rstrip('/')
def get(url):
    req=urllib.request.Request(url,headers={'Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=40) as response:return response.status,json.load(response)
def post(data):
    req=urllib.request.Request(URL+'/',data=json.dumps(data).encode(),headers={'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=45) as response:return response.status,json.load(response)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        print(f"HTTP ERROR STATUS: {exc.code}")
        print(f"CONTENT TYPE: {exc.headers.get('Content-Type')}")
        print(f"RESPONSE BODY: {raw[:2000]!r}")
        try:
            return exc.code, json.loads(raw)
        except ValueError:
            return exc.code, {"raw_error": raw[:2000]}
status,health=get(URL+'/health')
assert status==200 and health.get('modelVersion')=='phase3-translation-grid-v1',health
print('PASS health:',health['service'],health['modelVersion'])
rect=lambda x1,y1,x2,y2:[[x1,y1],[x2,y1],[x2,y2],[x1,y2]]
scenario={'id':'cloud-smoke','site':{'schemaVersion':1,'name':'Non-identifying synthetic test site',
'latitude':28.6139,'longitude':77.2090,'measurementMode':'concept',
'waitingArea':rect(-4,-1.5,4,1.5),
'baselineCanopies':[], 'buildings':[],
'allowedConstructionZone':rect(-10,-3,10,7),
'exclusionZones':[rect(-10,-8,10,-4)]},
'mode':'add','proposedCanopies':[{'id':'test-roof','shape':'rectangle','footprint':rect(-1,2,1,4),'heightM':3,'opaque':True}],
'dateISO':'2026-05-15','startTimeIST':'12:00','endTimeIST':'17:00','sampleMinutes':15}
options={'anchor':[0,3],'coarseStepM':1,'fineStepM':0.25,'refineRadiusM':0.75,'maxEvaluations':750}
request={'apiVersion':'shadedebt-optimize-v1','scenario':scenario,'options':options}
status,body=post(request)
assert status==200 and body.get('ok') is True and body['result']['evaluatedCandidates']>0,body
print('PASS optimizer:',body['result']['evaluatedCandidates'],'candidates; best ShadeDebt',body['result']['best']['shadeDebtM2Hours'])
# The latest product's differentiator: AWS yearly study on identical date/time samples.
yearly=json.loads(json.dumps(scenario))
yearly['mode']='replace'
yearly_request={'apiVersion':'shadedebt-optimize-year-v1','scenario':yearly,'options':{'anchor':[0,3]}}
status,year_body=post(yearly_request)
assert status==200 and year_body.get('ok') is True and year_body.get('modelVersion')=='yearly-placement-v1',(status,year_body)
assert len(year_body['result']['dates'])==12 and year_body['result']['sampledTimes']==60,year_body
assert year_body['result']['best'] is not None and year_body['result']['tested']>0,year_body
print('PASS annual AWS study:',year_body['result']['tested'],'positions across',year_body['result']['sampledTimes'],'sun positions')

scenario['site']['latitude']=999
status,body=post(request)
assert status==422 and body.get('ok') is False,(status,body)
print('PASS invalid geometry rejected HTTP 422')
print('Cloud smoke succeeded. Check production browser CORS and the actual recommendation workflow separately.')
