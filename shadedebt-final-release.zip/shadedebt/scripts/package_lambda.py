#!/usr/bin/env python3
"""Package the bundled Lambda ESM file at the required ZIP root."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path('build/lambda');js=root/'index.mjs';out=root/'lambda.zip'
if not js.exists():raise SystemExit('Build the bundled index.mjs before packaging')
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=9) as z:z.write(js,'index.mjs')
with ZipFile(out) as z:
    assert z.testzip() is None and z.namelist()==['index.mjs']
print(f'Validated Lambda archive: {out} ({out.stat().st_size:,} bytes)')
