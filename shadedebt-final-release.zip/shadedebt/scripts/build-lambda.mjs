/** Produces an AWS-uploadable, dependency-bundled Node 22 Lambda ZIP.
 * Run after npm install. No IAM credentials are required to build this artifact.
 */
import { build } from 'esbuild';
import { execFileSync } from 'node:child_process';
import { mkdirSync, existsSync } from 'node:fs';
const folder='build/lambda';
mkdirSync(folder,{recursive:true});
await build({entryPoints:['lambda/handler.ts'],outfile:`${folder}/index.mjs`,bundle:true,platform:'node',format:'esm',target:'node22',minify:false,sourcemap:false,logLevel:'info',legalComments:'inline'});
execFileSync('python3',['scripts/package_lambda.py'],{stdio:'inherit'});
if(!existsSync(`${folder}/lambda.zip`))throw new Error('Lambda archive missing');
