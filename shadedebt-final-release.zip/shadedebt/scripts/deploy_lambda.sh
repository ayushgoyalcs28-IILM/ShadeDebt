#!/usr/bin/env bash
# Optional scripted alternative to deploying via AWS Console.
set -euo pipefail
: "${SHADEDEBT_UPLOAD_BUCKET:?Set SHADEDEBT_UPLOAD_BUCKET to a private S3 bucket you control}"
: "${SHADEDEBT_AMPLIFY_ORIGIN:?Set SHADEDEBT_AMPLIFY_ORIGIN, e.g. https://main.xxxxx.amplifyapp.com}"
AWS_REGION="${AWS_REGION:-ap-south-1}"
STACK_NAME="${SHADEDEBT_STACK_NAME:-shadedebt-phase5}"
if [[ ! "$SHADEDEBT_AMPLIFY_ORIGIN" =~ ^https://[^/]+$ ]]; then echo 'Origin must be exact HTTPS origin without trailing slash'; exit 2; fi
npm run build:lambda
HASH=$(python3 -c 'import hashlib; print(hashlib.sha256(open("build/lambda/lambda.zip","rb").read()).hexdigest()[:12])')
OBJECT_KEY="shadedebt/lambda-$HASH.zip"
aws s3 cp build/lambda/lambda.zip "s3://$SHADEDEBT_UPLOAD_BUCKET/$OBJECT_KEY" --region "$AWS_REGION"
aws cloudformation deploy --stack-name "$STACK_NAME" --template-file infra/shadedebt-lambda.yaml \
  --region "$AWS_REGION" --capabilities CAPABILITY_IAM \
  --parameter-overrides "DeploymentBucket=$SHADEDEBT_UPLOAD_BUCKET" "DeploymentKey=$OBJECT_KEY" "AllowedOrigin=$SHADEDEBT_AMPLIFY_ORIGIN"
aws cloudformation describe-stacks --region "$AWS_REGION" --stack-name "$STACK_NAME" --query 'Stacks[0].Outputs' --output table
